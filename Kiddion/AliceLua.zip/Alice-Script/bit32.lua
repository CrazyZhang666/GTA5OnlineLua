return {
	["band"] = function(num_i, bit_i)
		return num_i & bit_i
	end, 
	["bor"] = function(num_i, bit_i)
		return num_i | bit_i
	end, 
	["bxor"] = function(num_i, bit_i)
		return num_i ~ bit_i
	end, 
	["bnot"] = function(num_i)
		return ~num_i
	end, 
	["lshift"] = function(num_i, bit_i)
		return num_i << bit_i
	end, 
	["rshift"] = function(num_i, bit_i)
		return num_i >> bit_i
	end
}