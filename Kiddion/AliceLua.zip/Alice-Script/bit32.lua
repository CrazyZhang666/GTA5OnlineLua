return {
	["lshift"] = function(num_i, bit_i)
		return math.floor(num_i << bit_i)
	end, 
	["rshift"] = function(num_i, bit_i)
		return math.floor(num_i >> bit_i)
	end
}