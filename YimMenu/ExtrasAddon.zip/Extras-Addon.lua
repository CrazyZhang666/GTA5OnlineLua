local json = require('json')

--[[


___________         __                        
\_   _____/__  ____/  |_____________    ______
 |    __)_\  \/  /\   __\_  __ \__  \  /  ___/
 |        \>    <  |  |  |  | \// __ \_\___ \ 
/_______  /__/\_ \ |__|  |__|  (____  /____  >
        \/      \/                  \/     \/ 
     _____       .___  .___                   
    /  _  \    __| _/__| _/____   ____        
   /  /_\  \  / __ |/ __ |/  _ \ /    \       
  /    |    \/ /_/ / /_/ (  <_> )   |  \      
  \____|__  /\____ \____ |\____/|___|  /      
          \/      \/    \/           \/       

    Extras Addon for YimMenu v1.68
        Addon Version: 1.0.3
        
        Credits:  Yimura, L7Neg, 
    Loled69, Alestarov, gir489returns, 
      TheKuter, RazorGamerX, USBMenus & More!

]]--

local addonVersion = "1.0.3"

griefPlayerTab = gui.get_tab("")
dropsPlayerTab = gui.get_tab("") -- For Selected Player Options

-- Function to create a text element
local function createText(tab, text)
    tab:add_text(text)
end

function sleep(seconds)
    local start = os.clock()
    while os.clock() - start < seconds do
        -- Yield the CPU to avoid high CPU usage during the delay
        coroutine.yield()
    end
end

function delete_entity(ent) --discord@rostal315
    if ENTITY.DOES_ENTITY_EXIST(ent) then
        ENTITY.DETACH_ENTITY(ent, true, true)
        ENTITY.SET_ENTITY_VISIBLE(ent, false, false)
        NETWORK.NETWORK_SET_ENTITY_ONLY_EXISTS_FOR_PARTICIPANTS(ent, true)
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ent, 0.0, 0.0, -1000.0, false, false, false)
        ENTITY.SET_ENTITY_COLLISION(ent, false, false)
        ENTITY.SET_ENTITY_AS_MISSION_ENTITY(ent, true, true)
        ENTITY.SET_ENTITY_AS_NO_LONGER_NEEDED(ent)
        ENTITY.DELETE_ENTITY(ent)
    end
end

function toolTip(tab, text, seperate)
    seperate = seperate or false
    if tab == "" then
        if seperate then --waiting approval
            ImGui.SameLine()
            ImGui.TextDisabled("(?)")
        end
        if ImGui.IsItemHovered() then
            ImGui.BeginTooltip()
      ImGui.Text(text)
            ImGui.EndTooltip()
        end
    else
        tab:add_imgui(function()
            if seperate then
                ImGui.SameLine()
                ImGui.TextDisabled("(?)")
            end
            if ImGui.IsItemHovered() then
                ImGui.BeginTooltip()
                ImGui.Text(text)
                ImGui.EndTooltip()
            end
        end)
    end
end

function newText(tab, text, size)
    size = size or 1
    tab:add_imgui(function()
        ImGui.SetWindowFontScale(size)
        ImGui.Text(text)
        ImGui.SetWindowFontScale(1)
    end)
end

function RequestControl(entity)
    local tick = 0
 
    local netID = NETWORK.NETWORK_GET_NETWORK_ID_FROM_ENTITY(entity)
 
    NETWORK.SET_NETWORK_ID_CAN_MIGRATE(netID, true)
    NETWORK.NETWORK_HAS_CONTROL_OF_NETWORK_ID(netID)
    while not NETWORK.NETWORK_HAS_CONTROL_OF_ENTITY(entity) and tick < 50 do
        NETWORK.NETWORK_REQUEST_CONTROL_OF_ENTITY(entity)
        tick = tick + 1
    end
 
    return NETWORK.NETWORK_HAS_CONTROL_OF_ENTITY(entity)
end

function request_control(entity)
    if not NETWORK.NETWORK_HAS_CONTROL_OF_ENTITY(entity) then
        local netId = NETWORK.NETWORK_GET_NETWORK_ID_FROM_ENTITY(entity)
        NETWORK.SET_NETWORK_ID_CAN_MIGRATE(netId, true)
        NETWORK.NETWORK_REQUEST_CONTROL_OF_ENTITY(entity)
    end
    return NETWORK.NETWORK_HAS_CONTROL_OF_ENTITY(entity)
end

function SessionChanger(session)
    globals.set_int(1575032, session)
        if session == -1 then
            globals.set_int(1574589 + 2, -1)
        end
        sleep(0.5)
        globals.set_int(1574589, 1)
        sleep(0.5)
        globals.set_int(1574589, 0)
end

-- Extras Menu Addon for YimMenu 1.68 by DeadlineEm
local KAOS = gui.get_tab("Extras Addon")
require("Extras-data")
newText(KAOS, "欢迎来到 Extras Addon v"..addonVersion.." 在继续使用菜单选项之前，请阅读以下信息.", 1)
KAOS:add_separator()
createText(KAOS, "其中一些（如果不是大多数）选项被视为基于恢复的选项，使用它们的风险由您自己承担!")
KAOS:add_separator()
createText(KAOS, "此菜单是多个菜单功能的混搭，有些已更改，有些则未更改。 它的创建意图是")
createText(KAOS, "对于您能想象到的一切，都有尽可能多的选择，但要允许完整的 mod freedom")
createText(KAOS, "无需编译您自己的 YimMenu 版本，但仍然能够在")
createText(KAOS, "一个小的下拉列表选项卡，不需要多个 Lua 脚本来执行此操作。 这个项目是开源的，我")
createText(KAOS, "鼓励大家和我一起创造这个，借出你的想法，提交公关，进行讨论，让我们做")
createText(KAOS, "YimMenu下一代!")
KAOS:add_separator()
createText(KAOS, "感谢: Yimura, L7Neg, Loled69, TeaTimeTea, CSYON, Adventure Box, gir489returns, abuazizv,")
createText(KAOS, "Alestarov, RazorGamerX, USBMenus, ShinyWasabi和UC社区")
KAOS:add_separator()
createText(KAOS, "感谢我所有的测试人员，感谢您抽出宝贵时间。 感谢以上所有脚本和")
createText(KAOS, "对于您对我的评论的意见，我已经做了大量的阅读、滚动、测试和学习")
createText(KAOS, "由 - DeadlineEm 和 USBMenus 提供")

-- Player Options Tab
local Pla = KAOS:add_tab("玩家选项")


-- Movement Tab with Slider for Movement Speed
local Mvmt = Pla:add_tab("运动")

runSpeed = 1
Mvmt:add_imgui(function()
    runSpeed, used = ImGui.SliderInt("运行速度", runSpeed, 1, 10)
    out = "速度设置为 "..tostring(runSpeed).."x"
    if used then
        PLAYER.SET_RUN_SPRINT_MULTIPLIER_FOR_PLAYER(PLAYER.PLAYER_ID(), runSpeed/7)
        gui.show_message('运行速度修改!', out)
    end
    toolTip("", "提高您的步行/跑步速度")
end)

swimSpeed = 1
Mvmt:add_imgui(function()
    swimSpeed, used = ImGui.SliderInt("游泳速度", swimSpeed, 1, 10)
    out = "速度设置为 "..tostring(swimSpeed).."x"
    if used then
        PLAYER.SET_SWIM_MULTIPLIER_FOR_PLAYER(PLAYER.PLAYER_ID(), swimSpeed/7)
        gui.show_message('修改后的游泳速度!', out)
    end
    toolTip("", "提高你的游泳速度")
end)

-- Fun Random Things
local Fun = Pla:add_tab("粒子/PTFX效果")
Fun:add_text("PTFX")
local fireworkLoop3 = Fun:add_checkbox("烟花（开/关）")

function load_fireworks()
    STREAMING.REQUEST_NAMED_PTFX_ASSET("proj_indep_firework")
    
    if not STREAMING.HAS_NAMED_PTFX_ASSET_LOADED("proj_indep_firework") then
        return false
    end


    return true
end

function random_color()
    return math.random(0, 255), math.random(0, 255), math.random(0, 255)
end

script.register_looped("FireworkLoop3", function()
    if fireworkLoop3:is_enabled() == true then
        if load_fireworks() then
            local localPlayerId = PLAYER.PLAYER_ID()
                local player_coords = ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(localPlayerId), true)

                -- Get random color values
                local colorR, colorG, colorB = random_color()
                test = player_coords.z - 1
                GRAPHICS.USE_PARTICLE_FX_ASSET("proj_indep_firework")
                GRAPHICS.SET_PARTICLE_FX_NON_LOOPED_COLOUR(colorR, colorG, colorB)
                GRAPHICS.START_NETWORKED_PARTICLE_FX_NON_LOOPED_AT_COORD("scr_indep_firework_grd_burst", player_coords.x, player_coords.y, test, 0, 0, 0, 1, false, false, false, false)
            sleep(0.2)
        end
    end
end)
toolTip(Fun, "在玩家脚下切换烟花粒子效果")
Fun:add_sameline()
local smokeLoop = Fun:add_checkbox("烟雾（开/关）")
function load_smoke()

    STREAMING.REQUEST_NAMED_PTFX_ASSET("scr_sum2_hal")
    
    if not STREAMING.HAS_NAMED_PTFX_ASSET_LOADED("scr_sum2_hal") then
        return false
    end

    return true
end

function random_color()
    return math.random(0, 255), math.random(0, 255), math.random(0, 255)
end

script.register_looped("SmokeLoop", function()
    if smokeLoop:is_enabled() == true then
        if load_smoke() then
            local localPlayerId = PLAYER.PLAYER_ID()
                local player_coords = ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(localPlayerId), true)

                -- Get random color values
                local colorR, colorG, colorB = random_color()
                test = player_coords.z - 2.0
                GRAPHICS.USE_PARTICLE_FX_ASSET("scr_sum2_hal")
                GRAPHICS.SET_PARTICLE_FX_NON_LOOPED_COLOUR(colorR, colorG, colorB)
                GRAPHICS.START_NETWORKED_PARTICLE_FX_NON_LOOPED_AT_COORD("scr_sum2_hal_rider_death_blue", player_coords.x, player_coords.y, test, 0, 0, 0, 1, false, false, false, false)
            sleep(0.2)
        end
    end
end)
toolTip(Fun, "切换玩家脚下的烟雾粒子效果")
Fun:add_sameline()
local flameLoop = Fun:add_checkbox("火焰（开/关）)")
function load_flame()

    STREAMING.REQUEST_NAMED_PTFX_ASSET("scr_bike_adversary")
    
    if not STREAMING.HAS_NAMED_PTFX_ASSET_LOADED("scr_bike_adversary") then
        return false
    end

    return true
end

function random_color()
    return math.random(0, 255), math.random(0, 255), math.random(0, 255)
end

script.register_looped("FlameLoop", function()
    if flameLoop:is_enabled() == true then
        if load_flame() then
            local localPlayerId = PLAYER.PLAYER_ID()
                local player_coords = ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(localPlayerId), true)

                -- Get random color values
                local colorR, colorG, colorB = random_color()
                test = player_coords.z - 1
                GRAPHICS.USE_PARTICLE_FX_ASSET("scr_bike_adversary")
                GRAPHICS.SET_PARTICLE_FX_NON_LOOPED_COLOUR(colorR, colorG, colorB)
                GRAPHICS.START_NETWORKED_PARTICLE_FX_NON_LOOPED_AT_COORD("scr_adversary_foot_flames", player_coords.x, player_coords.y, test, 0, 0, 0, 5, false, false, false, false)
            sleep(0.2)
        end
    end
end)
toolTip(Fun, "切换玩家脚下的火焰“幽灵骑士”粒子效果")
Fun:add_separator()
shootCB = Fun:add_checkbox("枪 PTFX（钞票)")

script.register_looped("particles", function(shoot)
    if shootCB:is_enabled() then
        if PED.IS_PED_SHOOTING(PLAYER.PLAYER_PED_ID()) then
            local weapon = WEAPON.GET_CURRENT_PED_WEAPON_ENTITY_INDEX(PLAYER.PLAYER_PED_ID(), 0)
            local boneId = ENTITY.GET_ENTITY_BONE_INDEX_BY_NAME(weapon, "gun_muzzle")
            GRAPHICS.USE_PARTICLE_FX_ASSET("scr_rcbarry2")
            GRAPHICS.START_NETWORKED_PARTICLE_FX_NON_LOOPED_ON_PED_BONE("muz_clown", weapon, 0.0, 0.0, 0.0, 90, 0, 0, boneId, 0.8, false, false, false)
        end
    end
end)
toolTip(Fun, "在武器发射时切换武器上的小丑粒子效果")
Fun:add_sameline()
shootCB2 = Fun:add_checkbox("枪械特效中的血液效果)")

script.register_looped("particles2", function(shootlol)
    if shootCB2:is_enabled() then
        if PED.IS_PED_SHOOTING(PLAYER.PLAYER_PED_ID()) then
            local weapon = WEAPON.GET_CURRENT_PED_WEAPON_ENTITY_INDEX(PLAYER.PLAYER_PED_ID(), 0)
            local boneId = ENTITY.GET_ENTITY_BONE_INDEX_BY_NAME(weapon, "gun_muzzle")

            GRAPHICS.USE_PARTICLE_FX_ASSET("scr_michael2")
            GRAPHICS.START_NETWORKED_PARTICLE_FX_NON_LOOPED_ON_PED_BONE("scr_mich2_blood_stab", weapon, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, boneId, 2.5, false, false, false)
        end
    end
end)
toolTip(Fun, "在武器发射时切换武器上的血粒子效果")
Fun:add_sameline()
vehCB = Fun:add_checkbox("后轮火焰")

script.register_looped("particles3", function(wheelOne)
    if vehCB:is_enabled() then
        local effect = "scr_bike_adversary"
        while not STREAMING.HAS_NAMED_PTFX_ASSET_LOADED(effect) do
            STREAMING.REQUEST_NAMED_PTFX_ASSET(effect)
            wheelOne:yield()
        end
            --local weapon = WEAPON.GET_CURRENT_PED_WEAPON_ENTITY_INDEX(PLAYER.PLAYER_PED_ID(), 0)
        local vehicle = PED.GET_VEHICLE_PED_IS_IN(PLAYER.PLAYER_PED_ID(), true)
        if ENTITY.IS_ENTITY_A_VEHICLE(vehicle) then
            local class = VEHICLE.GET_VEHICLE_CLASS(vehicle)
            if class == 8 then
                local boneId = ENTITY.GET_ENTITY_BONE_INDEX_BY_NAME(vehicle, "wheel_lr") -- Rear Motorcycle Wheel
                GRAPHICS.USE_PARTICLE_FX_ASSET(effect)
                GRAPHICS.START_PARTICLE_FX_NON_LOOPED_ON_ENTITY_BONE("scr_adversary_foot_flames", vehicle, 0.0, 0.0, 0.0, 0, 0, 0, boneId, 2, false, false, false)
            else
                local boneIdOne = ENTITY.GET_ENTITY_BONE_INDEX_BY_NAME(vehicle, "wheel_lr") -- left rear wheel
                local boneIdTwo = ENTITY.GET_ENTITY_BONE_INDEX_BY_NAME(vehicle, "wheel_rr") -- right rear wheel
                GRAPHICS.USE_PARTICLE_FX_ASSET(effect)
                GRAPHICS.START_PARTICLE_FX_NON_LOOPED_ON_ENTITY_BONE("scr_adversary_foot_flames", vehicle, 0.0, 0.0, 0.0, 0, 0, 0, boneIdOne, 2, false, false, false)
                GRAPHICS.USE_PARTICLE_FX_ASSET(effect)
                GRAPHICS.START_PARTICLE_FX_NON_LOOPED_ON_ENTITY_BONE("scr_adversary_foot_flames", vehicle, 0.0, 0.0, 0.0, 0, 0, 0, boneIdTwo, 2, false, false, false)
            end 
        end
    end
end)
toolTip(Fun, "切换车辆后轮上的火粒子效果")

local effectNames = { "外星人撞击", "小丑出现", "蓝色火花", "外星人解体", "火热颗粒" }
local effects <const> = {
    {"scr_rcbarry1", "scr_alien_impact_bul", 1.0, 50},
    {"scr_rcbarry2", "scr_clown_appears", 0.3, 500},
    {"core", "ent_dst_elec_fire_sp", 1.0, 100},
    {"scr_rcbarry1", "scr_alien_disintegrate", 0.1, 400},
    {"scr_rcbarry1", "scr_alien_teleport", 0.1, 400}
}

function newTimer()
    local self = {
        start = os.clock(), -- Start time in seconds
        m_enabled = false,
    }

    local function reset()
        self.start = os.clock()
        self.m_enabled = true
    end

    local function elapsed()
        return (os.clock() - self.start) * 1000 -- Convert seconds to milliseconds
    end

    local function disable() self.m_enabled = false end
    local function isEnabled() return self.m_enabled end

    return {
        isEnabled = isEnabled,
        reset = reset,
        elapsed = elapsed,
        disable = disable,
    }
end


local selectedOpt = 1
local lastEffect <const> = newTimer()

tirePTFX = Fun:add_checkbox("轮胎PTFX")
Fun:add_sameline()
Fun:add_imgui(function()
    selectedOpt, selected = ImGui.Combo("效果", selectedOpt, effectNames, #effectNames)
end)

script.register_looped("tireptfx", function(tire) 
    local effect = effects[selectedOpt + 1]
    local vehicle = PED.GET_VEHICLE_PED_IS_IN(PLAYER.PLAYER_PED_ID(), false)
    if tirePTFX:is_enabled() then

        if ENTITY.DOES_ENTITY_EXIST(vehicle) and not ENTITY.IS_ENTITY_DEAD(vehicle, false) and
        VEHICLE.IS_VEHICLE_DRIVEABLE(vehicle, false) and lastEffect.elapsed() > effect[4] then
            request_fx_asset(effect[1])
            for _, boneName in pairs({"wheel_lf", "wheel_lr", "wheel_rf", "wheel_rr"}) do
                local bone = ENTITY.GET_ENTITY_BONE_INDEX_BY_NAME(vehicle, boneName)
                
                GRAPHICS.USE_PARTICLE_FX_ASSET(effect[1])
                GRAPHICS.START_PARTICLE_FX_NON_LOOPED_ON_ENTITY_BONE(
                    effect[2],
                    vehicle,
                    0.0, 0.0, 0.0,
                    0.0, 0.0, 0.0,
                    bone,
                    effect[3],
                    false, false, false
                )
            end
            lastEffect.reset()
        end
    end
end)
toolTip(Fun, "显示轮胎上的颗粒效果")

Fun:add_separator()
Fun:add_text("改变移动方式")
drunkLoop = false
acidTrip = false
drunkDriving = false
Fun:add_imgui(function()
    drunkLoop, enabled = ImGui.Checkbox("使我喝醉", drunkLoop, true)
    ImGui.SameLine()
    ImGui.TextDisabled("(?)")
    if ImGui.IsItemHovered() then
        ImGui.BeginTooltip()
        ImGui.Text("让你的角色醉醺醺地四处走动.")
        ImGui.EndTooltip()
    end
    ImGui.SameLine()
    acidTrip, enabled = ImGui.Checkbox("显示醉酒的视觉特效", acidTrip, true)
    ImGui.SameLine()
    ImGui.TextDisabled("(?)")
    if ImGui.IsItemHovered() then
        ImGui.BeginTooltip()
        ImGui.Text("显示醉酒的视觉效果（只有在“使我醉酒”激活时).")
        ImGui.EndTooltip()
    end
    ImGui.SameLine()
    drunkDriving, enabled = ImGui.Checkbox("酒后驾车", drunkDriving, true)
    ImGui.SameLine()
    ImGui.TextDisabled("(?)")
    if ImGui.IsItemHovered() then
        ImGui.BeginTooltip()
        ImGui.Text("模拟醉酒驾驶（只有在‘使我醉酒’激活时）")
        ImGui.EndTooltip()
    end
    local ped = PLAYER.PLAYER_PED_ID()
    if drunkLoop then
        script.run_in_fiber(function()
            while not STREAMING.HAS_CLIP_SET_LOADED("move_m@drunk@verydrunk") do
                STREAMING.REQUEST_CLIP_SET("move_m@drunk@verydrunk")
                coroutine.yield()
            end
            PED.SET_PED_MOVEMENT_CLIPSET(ped, "move_m@drunk@verydrunk", 1.0)
        end)
            gui.show_message("损伤:", "你现在喝醉了!")
    else
        PED.RESET_PED_MOVEMENT_CLIPSET(ped, 0.0)
    end
        -- Apply drunk visual effects if the checkbox is enabled
    if acidTrip then
        script.run_in_fiber(function()
            if not drunkLoop then
                gui.show_warning("损伤:", "在使用此效果之前激活“让我喝醉”。")
                acidTrip = false
            else
            -- Apply acid trip visual effects
            -- Adjust these effects based on your preferences and available native functions
            GRAPHICS.SET_TIMECYCLE_MODIFIER("Drunk") -- Apply drunk timecycle modifier (you can change this to an acid trip modifier or stoned modifier)
            GRAPHICS.SET_TIMECYCLE_MODIFIER_STRENGTH(1.3) -- Adjust strength of distortion
            -- Add additional visual effects here (e.g., screen distortions, color shifts, etc.)
            -- You may need to experiment with different native functions to achieve the desired effect
            end
        end)
    else
        GRAPHICS.CLEAR_TIMECYCLE_MODIFIER()
    end
end)
script.register_looped("drunk driving", function(script)
    script:yield()
    -- Enable drunk driving if the checkbox is enabled
    if drunkDriving then
        if not drunkLoop then
            gui.show_warning("损伤:", "在使用此效果之前激活“让我喝醉”.")
            drunkDriving = false
        else
            local vehicle = PED.GET_VEHICLE_PED_IS_IN(PLAYER.PLAYER_PED_ID(), false)
            if vehicle ~= 0 then
                -- Apply random steering inputs
                local randomSteering = math.random(-1, 1) -- Random value between -1 and 1
                VEHICLE.SET_VEHICLE_STEER_BIAS(vehicle, randomSteering)
                VEHICLE.SET_VEHICLE_STEERING_BIAS_SCALAR(vehicle, 100)
                VEHICLE.SET_VEHICLE_HANDLING_OVERRIDE(vehicle, MISC.GET_HASH_KEY(vehicle))
                sleep(0.2)
                -- Reduce vehicle control
            end
        end
    end
end)
Fun:add_button("消除损伤", function()
    if drunkLoop then
        local ped = PLAYER.PLAYER_PED_ID()
        PED.RESET_PED_MOVEMENT_CLIPSET(ped, 0.0)
        drunkLoop = false
        gui.show_message("消除损伤", "您不再受损。删除了视觉和运动效果.")
        -- Reset acid trip visual effects when removing drunk movement
    end
    if acidTrip then
        GRAPHICS.CLEAR_TIMECYCLE_MODIFIER()
        acidTrip = false
    end
end)
toolTip(Fun, "消除所有损伤.")

    
-- Stat Editor - Alestarov_Menu // Reset Stats Option
local Stats = Pla:add_tab("等级")
Stats:add_text("更改级别")
Stats:add_button("随机化 RP", function()
    script.run_in_fiber(function (script)
        MPX = PI
        PI = stats.get_int("MPPLY_LAST_MP_CHAR")
        if PI == 0 then
            MPX = "MP0_"
        else
            MPX = "MP1_"
        end
        local randomizeRP = math.random(1, 1787576850) -- 1 Rp to 1787576850 Rp (lvl 1 to 8000)
        STATS.STAT_SET_INT(joaat(MPX .. "CHAR_SET_RP_GIFT_ADMIN"), randomizeRP, true)
        gui.show_message("等级", "您的 RP 已被随机分配到 "..randomizeRP..", 更改战局并应用 RP")
        sleep(1)
        SessionChanger(0)
    end)
end)
toolTip(Stats, "随机化您的 RP/级别")
Stats:add_sameline()
Stats:add_button("Lvl 1", function()
    script.run_in_fiber(function (script)
        MPX = PI
        PI = stats.get_int("MPPLY_LAST_MP_CHAR")
        if PI == 0 then
            MPX = "MP0_"
        else
            MPX = "MP1_"
        end
        local rpLevel = 1 -- Level 1 -- https://www.unknowncheats.me/forum/2458458-post691.html
        STATS.STAT_SET_INT(joaat(MPX .. "CHAR_SET_RP_GIFT_ADMIN"), rpLevel, true)
        gui.show_message("等级", "您的级别设置为 1，更改战局并应用 RP")
        sleep(1)
        SessionChanger(0)
    end)
end)
toolTip(Stats, "将等级设置为 1")
Stats:add_sameline()
Stats:add_button("Lvl 100", function()
    script.run_in_fiber(function (script)
        MPX = PI
        PI = stats.get_int("MPPLY_LAST_MP_CHAR")
        if PI == 0 then
            MPX = "MP0_"
        else
            MPX = "MP1_"
        end
        local rpLevel = 1584350 -- Level 100 -- https://www.unknowncheats.me/forum/2458458-post691.html
        STATS.STAT_SET_INT(joaat(MPX .. "CHAR_SET_RP_GIFT_ADMIN"), rpLevel, true)
        gui.show_message("等级", "您的等级设置为 100，更改会话并应用 RP")
        sleep(1)
        SessionChanger(0)
    end)
end)
toolTip(Stats, "将等级设置为 100")
Stats:add_sameline()
Stats:add_button("Lvl 420", function()
    script.run_in_fiber(function (script)
        MPX = PI
        PI = stats.get_int("MPPLY_LAST_MP_CHAR")
        if PI == 0 then
            MPX = "MP0_"
        else
            MPX = "MP1_"
        end
        local rpLevel = 13288350 -- Level 420 -- https://www.unknowncheats.me/forum/2458458-post691.html
        STATS.STAT_SET_INT(joaat(MPX .. "CHAR_SET_RP_GIFT_ADMIN"), rpLevel, true)
        gui.show_message("等级", "您的等级设置为 420，更改会话并应用 RP")
        sleep(1)
        SessionChanger(0)
    end)
end)
toolTip(Stats, "将等级设置为 420")
Stats:add_sameline()
Stats:add_button("Lvl 1337", function()
    script.run_in_fiber(function (script)
        MPX = PI
        PI = stats.get_int("MPPLY_LAST_MP_CHAR")
        if PI == 0 then
            MPX = "MP0_"
        else
            MPX = "MP1_"
        end
        local rpLevel = 75185850 -- Level 1337 -- https://www.unknowncheats.me/forum/2458458-post691.html
        STATS.STAT_SET_INT(joaat(MPX .. "CHAR_SET_RP_GIFT_ADMIN"), rpLevel, true)
        gui.show_message("等级", "您的等级设置为 1337，更改会话并应用 RP")
        sleep(1)
        SessionChanger(0)
    end)
end)
toolTip(Stats, "将等级设置为 1337")
Stats:add_sameline()
Stats:add_button("Lvl 8000", function()
    script.run_in_fiber(function (script)
        MPX = PI
        PI = stats.get_int("MPPLY_LAST_MP_CHAR")
        if PI == 0 then
            MPX = "MP0_"
        else
            MPX = "MP1_"
        end
        local rpLevel = 1787576850 -- Level 8000 -- https://www.unknowncheats.me/forum/2458458-post691.html
        STATS.STAT_SET_INT(joaat(MPX .. "CHAR_SET_RP_GIFT_ADMIN"), rpLevel, true)
        gui.show_message("等级", "您的等级设置为 8000，更改会话并应用 RP")
        sleep(1)
        SessionChanger(0)
    end)
end)
toolTip(Stats, "将等级设置为 8000")
Stats:add_separator()
Stats:add_text("收入统计")
Stats:add_button("重置收入/支出统计数据", function()
    script.run_in_fiber(function (script)
        MPX = PI
        PI = stats.get_int("MPPLY_LAST_MP_CHAR")
        if PI == 0 then
            MPX = "MP0_"
        else
            MPX = "MP1_"
        end
        STATS.STAT_SET_INT(joaat("MPPLY_TOTAL_EVC"), 0, true)
        STATS.STAT_SET_INT(joaat("MPPLY_TOTAL_SVC"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "MONEY_EARN_BETTING"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "MONEY_EARN_JOBS"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "MONEY_EARN_SHARED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "MONEY_SPENT_SHARED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "MONEY_EARN_JOBSHARED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "MONEY_EARN_SELLING_VEH"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "MONEY_SPENT_WEAPON_ARMOR"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "MONEY_SPENT_VEH_MAINTENANCE"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "MONEY_SPENT_STYLE_ENT"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "MONEY_SPENT_PROPERTY_UTIL"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "MONEY_SPENT_JOB_ACTIVITY"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "MONEY_SPENT_BETTING"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "MONEY_EARN_VEHICLE_EXPORT"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "MONEY_SPENT_VEHICLE_EXPORT"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "MONEY_EARN_CLUB_DANCING"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "CASINO_CHIPS_WON_GD"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "CASINO_CHIPS_WONTIM"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "CASINO_GMBLNG_GD"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "CASINO_BAN_TIME"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "CASINO_CHIPS_PURTIM"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "CASINO_CHIPS_PUR_GD"), 0, true)
        if PI == 0 then
            gui.show_message("统计", "玩家 1 的收入统计数据已重置为 0，更改了要应用的会话.")
        else
            gui.show_message("统计", "玩家 2 的收入统计数据已重置为 0，更改了要应用的会话.")
        end
        sleep(1)
        SessionChanger(0)
    end)
end)
toolTip(Stats, "将您的劳动收入、总收入、赌场筹码收入等重置为 0")
Stats:add_sameline()
Stats:add_button("银行转账到钱包", function()
    NETSHOPPING.NET_GAMESERVER_TRANSFER_BANK_TO_WALLET(stats.get_character_index(), MONEY.NETWORK_GET_VC_BANK_BALANCE(stats.get_character_index()))
end)
toolTip(Stats, "把你所有的钱都从银行里拿出来")
Stats:add_sameline()
Stats:add_button("钱包到银行", function()
    NETSHOPPING.NET_GAMESERVER_TRANSFER_WALLET_TO_BANK(stats.get_character_index(), MONEY.NETWORK_GET_VC_WALLET_BALANCE(stats.get_character_index()))
end)
toolTip(Stats, "把你所有的钱都存入银行")
Stats:add_separator()
Stats:add_text("角色技能")
Stats:add_button("最大所有技能", function()
    script.run_in_fiber(function (script)
        MPX = PI
        PI = stats.get_int("MPPLY_LAST_MP_CHAR")
        if PI == 0 then
            MPX = "MP0_"
        else
            MPX = "MP1_"
        end
        STATS.STAT_SET_INT(joaat(MPX .. "SCRIPT_INCREASE_DRIV"), 1000, true)
        STATS.STAT_SET_INT(joaat(MPX .. "SCRIPT_INCREASE_FLY"), 1000, true)
        STATS.STAT_SET_INT(joaat(MPX .. "SCRIPT_INCREASE_LUNG"), 1000, true)
        STATS.STAT_SET_INT(joaat(MPX .. "SCRIPT_INCREASE_SHO"), 1000, true)
        STATS.STAT_SET_INT(joaat(MPX .. "SCRIPT_INCREASE_STAM"), 1000, true)
        STATS.STAT_SET_INT(joaat(MPX .. "SCRIPT_INCREASE_STL"), 1000, true)
        STATS.STAT_SET_INT(joaat(MPX .. "SCRIPT_INCREASE_STRN"), 1000, true)
        gui.show_message("统计", "你的角色技能（驾驶、飞行等）已经达到极限。更改要应用的会话.")
        sleep(1)
        SessionChanger(0)
    end)
end)
toolTip(Stats, "最大化你的角色技能（驾驶、飞行、耐力等）")
Stats:add_sameline()
Stats:add_button("重置所有技能", function()
    script.run_in_fiber(function (script)
        MPX = PI
        PI = stats.get_int("MPPLY_LAST_MP_CHAR")
        if PI == 0 then
            MPX = "MP0_"
        else
            MPX = "MP1_"
        end
        STATS.STAT_SET_INT(joaat(MPX .. "SCRIPT_INCREASE_DRIV"), -1000, true)
        STATS.STAT_SET_INT(joaat(MPX .. "SCRIPT_INCREASE_FLY"), -1000, true)
        STATS.STAT_SET_INT(joaat(MPX .. "SCRIPT_INCREASE_LUNG"), -1000, true)
        STATS.STAT_SET_INT(joaat(MPX .. "SCRIPT_INCREASE_SHO"), -1000, true)
        STATS.STAT_SET_INT(joaat(MPX .. "SCRIPT_INCREASE_STAM"), -1000, true)
        STATS.STAT_SET_INT(joaat(MPX .. "SCRIPT_INCREASE_STL"), -1000, true)
        STATS.STAT_SET_INT(joaat(MPX .. "SCRIPT_INCREASE_STRN"), -1000, true)
        gui.show_message("统计", "你的角色技能（驾驶、飞行等）已归零。更改要应用的会话.")
        sleep(1)
        SessionChanger(0)
    end)
end)
toolTip(Stats, "将技能重置为最小值.")
Stats:add_separator()
Stats:add_text("解 锁")
function unlock_packed_bools(from, to)
    for i = from, to do
        stats.set_packed_stat_bool(i, true)
    end
end

local current_objectives_global = 2359296
local weekly_words_global = 2737646
local objectives_state_global = 1574743

Stats:add_button("全部解锁", function() --Original script by ShinyWasabi
    script.run_in_fiber(function (script)
        local is_player_male = (ENTITY.GET_ENTITY_MODEL(PLAYER.PLAYER_PED_ID()) == joaat('mp_m_freemode_01'))
        unlock_packed_bools(110, 113) --Red Check Pajamas, Green Check Pajamas, Black Check Pajamas, I Heart LC T-shirt
        unlock_packed_bools(115, 115) --Roosevelt
        unlock_packed_bools(124, 124) --Sanctus
        unlock_packed_bools(129, 129) --Albany Hermes
        unlock_packed_bools(135, 137) --Vapid Clique, Buzzard Attack Chopper, Insurgent Pick-Up
        unlock_packed_bools(3593, 3599) --'Statue Of Happiness' T-shirt, 'Pisswasser' Beer Hat, 'Benedict' Beer Hat, 'J Lager' Beer Hat, 'Patriot' Beer Hat, 'Blarneys' Beer Hat, 'Supa Wet' Beer Hat
        unlock_packed_bools(3604, 3605) --Liberator, Sovereign
        unlock_packed_bools(3608, 3609) --'Elitas' T-shirt, High Flyer Parachute Bag
        unlock_packed_bools(3616, 3616) --Please Stop Me Mask
        unlock_packed_bools(3750, 3750) --Stocking
        unlock_packed_bools(3765, 3769) --Elite Challenges
        unlock_packed_bools(3770, 3781) --'Death Defying' T-shirt, 'For Hire' T-shirt, 'Live a Little' T-shirt, 'Asshole' T-shirt, 'Can't Touch This' T-shirt, 'Decorated' T-shirt, 'Psycho Killer' T-shirt, 'One Man Army' T-shirt, 'Shot Caller' T-shirt, 'Showroom' T-shirt, 'Elite Challenge' T-Shirt, 'Elite Lousy' T-Shirt
        unlock_packed_bools(3783, 3802) --Fake Dix White T-Shirt, Fake Dix Gold T-Shirt, Fake Didier Sachs T-Shirt, Fake Enema T-Shirt, Fake Le Chien No2 T-Shirt, Fake Le Chien Crew T-Shirt, Fake Santo Capra T-Shirt, Fake Vapid T-Shirt, Fake Perseus T-Shirt, Fake Sessanta Nove T-Shirt, 'Vinewood Zombie' T-shirt, 'Meltdown' T-shirt, 'I Married My Dad' T-shirt, 'Die Already 4' T-shirt, 'The Shoulder Of Orion II' T-shirt, 'Nelson In Naples' T-shirt, 'The Many Wives of Alfredo Smith' T-shirt, 'An American Divorce' T-shirt, 'The Loneliest Robot' T-shirt, 'Capolavoro' T-shirt
        unlock_packed_bools(4247, 4269) --'Magnetics Script' Hat, 'Magnetics Block' Hat, 'Low Santos' Hat, 'Boars' Hat, 'Benny's' Hat, 'Westside' Hat, 'Eastside' Hat, 'Strawberry' Hat, 'S.A.' Hat, 'Davis' Hat, 'Vinewood Zombie' T-shirt, 'Knife After Dark' T-shirt, 'The Simian' T-shirt, 'Zombie Liberals In The Midwest' T-shirt, 'Twilight Knife' T-shirt, 'Butchery and Other Hobbies' T-shirt, 'Cheerleader Massacre 3' T-shirt, 'Cannibal Clown' T-shirt, 'Hot Serial Killer Stepmom' T-shirt, 'Splatter And Shot' T-shirt, 'Meathook For Mommy' T-shirt, 'Psycho Swingers' T-shirt, 'Vampires On The Beach' T-shirt
        unlock_packed_bools(4300, 4327) --Brown Corpse Bride Bobblehead, White Corpse Bride Bobblehead, Pink Corpse Bride Bobblehead, White Mask Slasher Bobblehead, Red Mask Slasher Bobblehead, Yellow Mask Slasher Bobblehead, Blue Zombie Bobblehead, Green Zombie Bobblehead, Pale Zombie Bobblehead, Possessed Urchin Bobblehead, Demonic Urchin Bobblehead, Gruesome Urchin Bobblehead, Tuxedo Frank Bobblehead, Purple Suit Frank Bobblehead, Stripped Suit Frank Bobblehead, Black Mummy Bobblehead, White Mummy Bobblehead, Brown Mummy Bobblehead, Pale Werewolf Bobblehead, Dark Werewolf Bobblehead, Gray Werewolf Bobblehead, Fleshy Vampire Bobblehead, Bloody Vampire Bobblehead, B&W Vampire Bobblehead, Halloween Loop 1, Halloween Loop 2, Franken Stange, Lurcher
        unlock_packed_bools(4333, 4335) --Nice Cap, Naughty Cap, Abominable Snowman
        unlock_packed_bools(7467, 7495) --'Accountant' T-shirt, 'Bahama Mamas' T-shirt, 'Drone' T-shirt, 'Grotti' T-shirt, 'Golf' T-shirt, 'Maisonette' T-shirt, 'Manopause' T-shirt, 'Marlowe' T-shirt, 'Meltdown' T-shirt, 'Pacific Bluffs' T-shirt, 'Prolaps' T-shirt, 'Tennis' T-shirt, 'Toe Shoes' T-shirt, 'Crest' T-shirt, 'Vanilla Unicorn' T-shirt, Pastel Blue Pajamas, Pastel Yellow Pajamas, Pastel Pink Pajamas, Pastel Green Pajamas, Vibrant Check Pajamas, Blue Check Pajamas, Red Swirl Motif Pajamas, White Graphic Pajamas, Blue Swirl Pajamas, Yellow Swirl Pajamas, Red Swirl Pajamas, Navy Pinstripe Pajamas, Bold Pinstripe Pajamas, Orange Pinstripe Pajamas
        unlock_packed_bools(7515, 7528) --Pastel Blue Smoking Jacket, Pastel Yellow Smoking Jacket, Pastel Pink Smoking Jacket, Pastel Green Smoking Jacket, Vibrant Check Smoking Jacket, Blue Check Smoking Jacket, Red Swirl Motif Smoking Jacket, White Graphic Smoking Jacket, Blue Swirl Smoking Jacket, Yellow Swirl Smoking Jacket, Red Swirl Smoking Jacket, Navy Pinstripe Smoking Jacket, Bold Pinstripe Smoking Jacket, Orange Pinstripe Smoking Jacket
        unlock_packed_bools(7551, 7551) --DCTL T-Shirt
        unlock_packed_bools(7595, 7601) --White Jock Cranley Suit, Red Jock Cranley Suit, Blue Jock Cranley Suit, Black Jock Cranley Suit, Pink Jock Cranley Suit, Gold Jock Cranley Suit, Silver Jock Cranley Suit
        unlock_packed_bools(9362, 9385) --Western Brand White T-Shirt, Western Brand Black T-Shirt, Western Logo White T-Shirt, Western Logo Black T-Shirt, Steel Horse Solid Logo T-Shirt, Steel Horse Logo T-Shirt, Steel Horse Brand White T-Shirt, Steel Horse Brand Black T-Shirt, Nagasaki White T-Shirt, Nagasaki White and Red T-Shirt, Nagasaki Black T-Shirt, Purple Helmets Black T-Shirt, Principe Black T-Shirt, Black Steel Horse Hoodie, Steel Horse Brand White T-Shirt, Western Black Hoodie, Western Logo White T-Shirt, Nagasaki White Hoodie, Nagasaki White and Red Hoodie, Nagasaki Black Hoodie, Purple Helmets Black Hoodie, Principe Logo, Crosswalk T-Shirt, R* Crosswalk T-Shirt
        unlock_packed_bools(9426, 9440) --Base5 T-Shirt, Bitch'n' Dog Food T-Shirt, BOBO T-Shirt, Bounce FM T-Shirt, Crocs Bar T-Shirt, Emotion 98.3 T-Shirt, Fever 105 T-Shirt, Flash T-Shirt, Homies Sharp T-Shirt, K-DST T-Shirt, KJAH Radio T-Shirt, K-ROSE T-Shirt, Victory Fist T-Shirt, Vinyl Countdown T-Shirt, Vivisection T-Shirt
        unlock_packed_bools(9443, 9443) --Unicorn
        unlock_packed_bools(9461, 9481) --Ballistic Equipment, LS UR T-Shirt, Non-Stop-Pop FM T-Shirt, Radio Los Santos T-Shirt, Los Santos Rock Radio T-Shirt, Blonded Los Santos 97.8 FM T-Shirt, West Coast Talk Radio T-Shirt, Radio Mirror Park T-Shirt, Rebel Radio T-Shirt, Channel X T-Shirt, Vinewood Boulevard Radio T-Shirt, FlyLo FM T-Shirt, Space 103.2 T-Shirt, West Coast Classics T-Shirt, East Los FM T-Shirt, The Lab T-Shirt, The Lowdown 91.1 T-Shirt, WorldWide FM T-Shirt, Soulwax FM T-Shirt, Blue Ark T-Shirt, Blaine County Radio T-Shirt
        unlock_packed_bools(15381, 15382) --APC SAM Battery, Ballistic Equipment
        unlock_packed_bools(15388, 15423) --Black Ammu-Nation Cap, Black Ammu-Nation Hoodie, Black Ammu-Nation T-Shirt, Black Coil Cap, Black Coil T-Shirt, Black Hawk & Little Hoodie, Black Hawk & Little Logo T-Shirt, Black Hawk & Little T-Shirt, Black Shrewsbury Hoodie, Black Vom Feuer Cap, Black Warstock Hoodie, Green Vom Feuer T-Shirt, Red Hawk & Little Cap, Warstock Cap, White Ammu-Nation T-Shirt, White Coil Hoodie, White Coil T-Shirt, White Hawk & Little Hoodie, White Hawk & Little T-Shirt, White Shrewsbury T-Shirt, White Shrewsbury Cap, White Shrewsbury Hoodie, White Shrewsbury Logo T-Shirt, White Vom Feuer Cap, White Vom Feuer Hoodie, Wine Coil Cap, Yellow Vom Feuer Logo T-Shirt, Yellow Vom Feuer T-Shirt, Yellow Warstock T-Shirt, Blue R* Class of '98, Red R* Class of '98, Noise Rockstar Logo T-Shirt, Noise T-Shirt, Razor T-Shirt, Black Rockstar Camo, White Rockstar Camo
        unlock_packed_bools(15425, 15439) --Knuckleduster Pocket T-Shirt, Rockstar Logo Blacked Out T-Shirt, Rockstar Logo White Out T-Shirt, Half-track 20mm Quad Autocannon, Weaponized Tampa Dual Remote Minigun, Weaponized Tampa Rear-Firing Mortar, Weaponized Tampa Front Missile Launchers, Dune FAV 40mm Grenade Launcher, Dune FAV 7.62mm Minigun, Insurgent Pick-Up Custom .50 Cal Minigun, Insurgent Pick-Up Custom Heavy Armor Plating, Technical Custom 7.62mm Minigun, Technical Custom Ram-bar, Technical Custom Brute-bar, Technical Custom Heavy Chassis Armor
        unlock_packed_bools(15447, 15474) --Oppressor Missiles, Fractal Livery Set, Digital Livery Set, Geometric Livery Set, Nature Reserve Livery, Naval Battle Livery, Anti-Aircraft Trailer Dual 20mm Flak, Anti-Aircraft Trailer Homing Missile Battery, Mobile Operations Center Rear Turrets, Incendiary Rounds, Hollow Point Rounds, Armor Piercing Rounds, Full Metal Jacket Rounds, Explosive Rounds, Pistol Mk II Mounted Scope, Pistol Mk II Compensator, SMG Mk II Holographic Sight, SMG Mk II Heavy Barrel, Heavy Sniper Mk II Night Vision Scope, Heavy Sniper Mk II Thermal Scope, Heavy Sniper Mk II Heavy Barrel, Combat MG Mk II Holographic Sight, Combat MG Mk II Heavy Barrel, Assault Rifle Mk II Holographic Sight, Assault Rifle Mk II Heavy Barrel, Carbine Rifle Mk II Holographic Sight, Carbine Rifle Mk II Heavy Barrel, Proximity Mines
        unlock_packed_bools(15491, 15499) --Weaponized Tampa Heavy Chassis Armor, Brushstroke Camo Mk II Weapon Livery, Skull Mk II Weapon Livery, Sessanta Nove Mk II Weapon Livery, Perseus Mk II Weapon Livery, Leopard Mk II Weapon Livery, Zebra Mk II Weapon Livery, Geometric Mk II Weapon Livery, Boom! Mk II Weapon Livery
        unlock_packed_bools(15552, 15560) --Bronze Greatest Dancer Trophy, Bronze Number One Nightclub Trophy, Bronze Battler Trophy, Silver Greatest Dancer Trophy, Silver Number One Nightclub Trophy, Silver Battler Trophy, Gold Greatest Dancer Trophy, Gold Number One Nightclub Trophy, Gold Battler Trophy
        unlock_packed_bools(18099, 18099) --The Forest
        unlock_packed_bools(18121, 18125) --Green Wireframe Bodysuit, Orange Wireframe Bodysuit, Blue Wireframe Bodysuit, Pink Wireframe Bodysuit, Yellow Wireframe Bodysuit
        unlock_packed_bools(18134, 18137) --Hideous Krampus Mask, Fearsome Krampus Mask, Odious Krampus Mask, Heinous Krampus Mask
        unlock_packed_bools(22124, 22132) --Maisonette Los Santos T-Shirt, Studio Los Santos T-Shirt, Galaxy T-Shirt, Gefängnis T-Shirt, Omega T-Shirt, Technologie T-Shirt, Paradise T-Shirt, The Palace T-Shirt, Tony's Fun House T-Shirt
        unlock_packed_bools(22137, 22139) --Nightclub Hotspot Trophy
        unlock_packed_bools(24963, 25000) --Apocalypse Cerberus, Future Shock Cerberus, Apocalypse Brutus, Nightmare Cerberus, Apocalypse ZR380, Future Shock Brutus, Impaler, Bolt Burger Hunger T-Shirt, Apocalypse Sasquatch - Livery set, Rat-Truck, Glendale, Slamvan, Dominator, Issi Classic, Spacesuit Alien T-Shirt set, Gargoyle, Future Shock Deathbike - Light Armor w/ Shield, Blue Lights, Electric Blue Lights, Mint Green Lights, Lime Green Lights, Yellow Lights, Golden Shower Lights, Orange Lights, Red Lights, Pony Pink Lights, Hot Pink Lights, Purple Lights, Blacklight Lights, Taxi Custom, Dozer, Clown Van, Trashmaster, Barracks Semi, Mixer, Space Docker, Tractor, Nebula Bodysuit set
        unlock_packed_bools(25002, 25002) --Up-n-Atomizer
        unlock_packed_bools(25005, 25006) --Epsilon Robes, Kifflom T-Shirt
        unlock_packed_bools(25008, 25009) --The Rookie
        unlock_packed_bools(25018, 25099) --Black & White Bones Festive Sweater, Slasher Festive Sweater, Black & Red Bones Festive Sweater, Red Bones Festive Sweater, Burger Shot Festive Sweater, Red Bleeder Festive Sweater, Blue Bleeder Festive Sweater, Blue Cluckin' Festive Sweater, Green Cluckin' Festive Sweater, Blue Slaying Festive Sweater, Green Slaying Festive Sweater, Hail Santa Festive Sweater, Merry Sprunkmas Festive Sweater, Ice Cold Sprunk Festive Sweater, Albany T-Shirt, Albany Vintage T-Shirt, Annis T-Shirt, Benefactor T-Shirt, BF T-Shirt, Bollokan T-Shirt, Bravado T-Shirt, Brute T-Shirt, Buckingham T-Shirt, Canis T-Shirt, Chariot T-Shirt, Cheval T-Shirt, Classique T-Shirt, Coil T-Shirt, Declasse T-Shirt, Dewbauchee T-Shirt, Dilettante T-Shirt, Dinka T-Shirt, Dundreary T-Shirt, Emperor T-Shirt, Enus T-Shirt, Fathom T-Shirt, Gallivanter T-Shirt, Grotti T-Shirt, Hijak T-Shirt, HVY T-Shirt, Imponte T-Shirt, Invetero T-Shirt, Jobuilt T-Shirt, Karin T-Shirt, Lampadati T-Shirt, Maibatsu T-Shirt, Mamba T-Shirt, Mammoth T-Shirt, MTL T-Shirt, Obey T-Shirt, Ocelot T-Shirt, Overflod T-Shirt, Pegassi T-Shirt, Pfister T-Shirt, Progen T-Shirt, Rune T-Shirt, Schyster T-Shirt, Shitzu T-Shirt, Truffade T-Shirt, Ubermacht T-Shirt, Vapid T-Shirt, Vulcar T-Shirt, Weeny T-Shirt, Willard T-Shirt, Albany Nostalgia T-Shirt, Albany USA T-Shirt, Albany Dealership T-Shirt, Annis JPN T-Shirt, BF Surfer T-Shirt, Bollokan Prairie T-Shirt, Bravado Stylized T-Shirt, Brute Impregnable T-Shirt, Brute Heavy Duty T-Shirt, Buckingham Luxe T-Shirt, Canis USA T-Shirt, Canis American Legend T-Shirt, Canis Wolf T-Shirt, Cheval Marshall T-Shirt, Coil USA T-Shirt, Coil Raiden T-Shirt, Declasse Logo T-Shirt, Declasse Girl T-Shirt
        unlock_packed_bools(25101, 25109) --Nightmare Brutus, Apocalypse Scarab, Future Shock Scarab, Nightmare Scarab, Future Shock ZR380, Nightmare ZR380, Apocalypse Imperator, Future Shock Imperator, Nightmare Imperator
        unlock_packed_bools(25111, 25134) --Future Shock Deathbike - Reinforced Armor w/ Shield, Future Shock Deathbike - Heavy Armor w/ Shield, Future Shock Sasquatch - Livery set, Nightmare Sasquatch - Livery set, Apocalypse Cerberus - Livery set, Future Shock Cerberus - Livery set, All variants of Sasquatch - Light Armor, All variants of Sasquatch - Reinforced Armor, All variants of Sasquatch - Heavy Armor, Nightmare Cerberus - Livery set, Apocalypse Bruiser - Livery set, Future Shock Bruiser - Livery set, Nightmare Bruiser - Livery set, Apocalypse Slamvan - Livery set, All variants of Cerberus - Body Spikes, Future Shock Slamvan - Livery set, All variants of Cerberus - Light Armor, All variants of Cerberus - Reinforced Armor, All variants of Cerberus - Heavy Armor, Nightmare Slamvan - Livery set, Apocalypse Brutus - Livery set, Future Shock Brutus - Livery set, Nightmare Brutus - Livery set, Apocalypse Scarab - Livery set
        unlock_packed_bools(25136, 25179) --All variants of Bruiser - Body Spikes, Future Shock Scarab - Livery set, Nightmare Scarab - Livery set, All variants of Bruiser - Light Armor, All variants of Bruiser - Reinforced Armor, All variants of Bruiser - Heavy Armor, Apocalypse Dominator - Livery set, Future Shock Dominator - Livery set, Nightmare Dominator - Livery set, Apocalypse Impaler - Livery set, Future Shock Impaler - Livery set, Nightmare Impaler - Livery set, All variants of Slamvan - Body Spikes, Apocalypse Imperator - Livery set, Future Shock Imperator - Livery set, All variants of Slamvan - Light Armor, All variants of Slamvan - Reinforced Armor, All variants of Slamvan - Heavy Armor, Nightmare Imperator - Livery set, Apocalypse ZR380 - Livery set, Future Shock ZR380 - Livery set, Nightmare ZR380 - Livery set, Apocalypse Issi - Livery set, Future Shock Issi - Livery set, All variants of Brutus - Light Armor, All variants of Brutus - Reinforced Armor, All variants of Brutus - Heavy Armor, Nightmare Issi - Livery set, Apocalypse Deathbike - Livery set, Future Shock Deathbike - Livery set, Nightmare Deathbike - Livery set, All variants of Sasquatch - Heavy Armored Front, Apocalypse Scarab - Body Spikes set, Future Shock Scarab - Body Spikes set, Nightmare Scarab - Body Spikes set, All variants of Sasquatch - Heavy Armored Hood, All variants of Sasquatch - Mohawk Exhausts, All variants of Scarab - Light Armor, All variants of Scarab - Reinforced Armor, All variants of Scarab - Heavy Armor, All variants of Sasquatch - Dual Mohawk Exhausts, Apocalypse & Nightmare Sasquatch - Rear Spears Left, Optics Headset Mask set, All variants of Dominator - Body Spikes
        unlock_packed_bools(25181, 25237) --Apocalypse & Nightmare Sasquatch - Rear Spears Right, Apocalypse & Nightmare Sasquatch - Skull Cross, All variants of Dominator - Light Armor, All variants of Dominator - Reinforced Armor, All variants of Dominator - Heavy Armor, Apocalypse & Nightmare Sasquatch - Ram Skull Cross, Apocalypse & Nightmare Sasquatch - Blonde Doll Cross, All variants of Impaler - Body Spikes, Apocalypse & Nightmare Sasquatch - Brunette Doll Cross, Apocalypse & Nightmare Cerberus - Bastioned Ram-bars, All variants of Impaler - Light Armor, All variants of Impaler - Reinforced Armor, All variants of Impaler - Heavy Armor, All variants of Cerberus - Bolstered Hood Cage, All variants of Cerberus - Reinforced Riot Hood, All variants of Cerberus - Juggernaut Hood, Apocalypse & Nightmare Cerberus - War Spearheads, All variants of Imperator - Body Spikes, Apocalypse & Nightmare Cerberus - War Spear Kit, Apocalypse & Nightmare Cerberus - Nade Spearheads, Apocalypse & Nightmare Cerberus - Nade Spear Kit, All variants of Imperator - Light Armor, All variants of Imperator - Reinforced Armor, All variants of Imperator - Heavy Armor, Apocalypse & Nightmare Cerberus - Skull Spearheads, Apocalypse & Nightmare Cerberus - Skull Spear Kit, Apocalypse & Nightmare Cerberus - Arrow Spearheads, Apocalypse & Nightmare Cerberus - Arrow Spear Kit, All variants of ZR380 - Body Spikes, Apocalypse & Nightmare Cerberus - Tridents, Apocalypse & Nightmare Cerberus - Wasteland Ritual, All variants of ZR380 - Light Armor, All variants of ZR380 - Reinforced Armor, All variants of ZR380 - Heavy Armor, Future Shock Cerberus - Panel Detail, Future Shock Cerberus - Crane Pipes, All variants of Issi - Body Spikes, Future Shock Cerberus - Hedgehog, Future Shock Cerberus - Hedgehog MK2, Future Shock Bruiser - Heavy Plated Armored Grille / Apocalypse & Nightmare Bruiser - Diamond Heavy Armor Grille, All variants of Issi - Light Armor, All variants of Issi - Reinforced Armor, All variants of Issi - Heavy Armor, All variants of Bruiser - Twin Oval Exhaust, Cluckin' Bell Mask, All variants of Bruiser - Long Triple Rear Exhausts, All variants of Bruiser - Front & Rear Triple Exhausts, All variants of Deathbike - Light Armor, All variants of Deathbike - Reinforced Armor, All variants of Deathbike - Heavy Armor, Kinetic Mines, Apocalypse Bruiser - Skull & Cross / Nightmare Bruiser - Painted Skull & Cross, Spike Mines, Slick Mines, Sticky Mines, EMP Mines, RC Bandito
        unlock_packed_bools(25244, 25400) --Robot Bodysuit set, Hero Bodysuit set, Shapes Bodysuit set, Contours Bodysuit set, Martian Bodysuit set, Reptile Bodysuit set, Galaxy Bodysuit set, Space Creature Suits, Space Cyclops Suits, Space Horror Suits, Retro Spacesuits, Astronaut Suits, Space Traveler Suits, Character Suits: Pogo Space Monkey, Character Suits: Republican Space Ranger, Death Bird Mask set, Stalker Mask set, Raider Mask set, Marauder Mask set, Paco the Taco Mask, Burger Shot Mask, Space Rangers T-Shirt set, Space Ranger Logo T-Shirt set, Phases T-Shirt set, Rocket Splash T-Shirt set, Two Moons T-Shirt set, Freedom Isn't Free T-Shirt set, Apocalyptic Raider Top set, Apocalyptic Leather Feather Top set, Apocalyptic Mercenary Vest set, Benedict Light Beer Hoodie, Taco Bomb Hoodie, Cluckin' Bell Logo Bomb Hoodie, Patriot Beer Hoodie, Pisswasser Hoodie, Burger Shot Hoodie, Corn Dog Hoodie, Donut Hoodie, Lucky Plucker Hoodie, Logger Light Hoodie, Pizza Hoodie, Fries Hoodie, Mushrooms Hoodie, Redwood Hoodie, eCola Infectious Hoodie, Cluckin' Bell Logo Hoodie, Lemons Hoodie, Tacos Hoodie, Burger Shot Pattern Sweater, Burger Shot Logo Sweater, Burger Shot Sweater, Sprunk Sweater set, Wigwam Sweater, Taco Bomb Chili Sweater, Taco Bomb Sweater set, Cluckin' Bell Logo Bomb Sweater, Blue Cluckin' Bell Sweater, Black Cluckin' Bell Sweater, eCola Sweater set, MeTV Sweater set, Heat Sweater set, Degenatron Sweater, Pisswasser Sweater set, Bolt Burger Sweater, Lucky Plucker Logo Bomb Sweater, Lucky Plucker Sweater, Burger Shot Hockey Shirt set, Cluckin' Bell Hockey Shirt set, Wigwam Hockey Shirt, Redwood Hockey Shirt, Bean Machine Hockey Shirt, Red eCola Hockey Shirt, Black eCola Hockey Shirt, Phat Chips Hockey Shirt set, Sprunk Hockey Shirt set, Sprunk Classic Hockey Shirt, Burger Shot Black T-Shirt, Burger Shot Logo T-Shirt, Cluckin' Bell Logo T-Shirt, Cluckin' Bell Black T-Shirt, Cluckin' Bell Filled Logo T-Shirt, eCola Black T-Shirt, Lucky Plucker T-Shirt, Pisswasser T-Shirt, Sprunk T-Shirt, Taco Bomb Chili T-Shirt, Taco Bomb Black T-Shirt, Up-n-Atom Hamburgers T-Shirt, Up-n-Atom Logo T-Shirt, Wigwam T-Shirt, Degenatron ROYGBIV T-Shirt, CNT T-Shirt, Qub3d T-Shirt, Righteous Slaughter T-Shirt, Space Monkey Full T-Shirt, Space Monkey Pixel T-Shirt, Space Monkey Enemy T-Shirt, Burger Shot Bleeder T-Shirt, Heat Rises T-Shirt, Space Monkey Logo T-Shirt, Space Monkey Suit T-Shirt, Space Monkey Face T-Shirt, Space Monkey Mosaic T-Shirt, Bolt Burger Logo T-Shirt, Exsorbeo 720 T-Shirt, Heat Ball Logo T-Shirt set, Heat Logo T-Shirt set, Heat Pop Art Logo T-Shirt set, MeTV Logo T-Shirt set, MeTV 90s T-Shirt set, Burger Shot Target T-Shirt, eCola Infectious T-Shirt, Up-n-Atom White T-Shirt, Jock Cranley Patriot T-Shirt, CCC TV T-Shirt, Degenatron Logo T-Shirt, eCola White T-Shirt, eCola Pass It On T-Shirt, Tw@ T-Shirt, Chain Pants set, Chain Shorts set, Leather Stitch Pants set, Raider Pants set, Light Ups Shoes set, Flaming Skull Boots set, Skull Harness Boots set, Plated Boots set, Burger Shot Food Cap set, Apocalypse Bruiser - Double Cross Ram Skull / Nightmare Bruiser - Painted Ram Skull & Cross, Burger Shot Logo Cap, Burger Shot Bullseye Cap, Cluckin' Bell Logo Cap set, Apocalypse Bruiser - Cross & Skull Large Blade Kit / Nightmare Bruiser - Painted Skull Large Blade Kit, Cluckin' Bell Logos Cap, Hotdogs Cap set, Taco Bomb Cap set, Apocalypse Bruiser - Ram Skull Nade Kit / Nightmare Bruiser - Painted Ram Skull Nade Kit, Apocalypse Bruiser - Ram Skull Medieval Kit / Nightmare Bruiser - Painted Skull Medieval Kit, Lucky Plucker Cap set, Lucky Plucker Logos Cap set, Apocalypse Bruiser - Ram Skull Medieval Madness / Nightmare Bruiser - Painted Skull Medieval Madness, Apocalypse Bruiser - Barrels & Junk, Pisswasser Cap set, Apocalypse Bruiser - Skeleton Cage, Future Shock Bruiser - Light Cover, Future Shock Bruiser - Spare Tire, Taco Canvas Hat, Burger Shot Canvas Hat, Cluckin' Bell Canvas Hat, Hotdogs Canvas Hat, Shunt Boost, Boost Upgrade 20%, Boost Upgrade 60%, Boost Upgrade 100%, Jump Upgrade 20%, Jump Upgrade 60%, Jump Upgrade 100%
        unlock_packed_bools(25405, 25405) --Festive tint (Up-n-Atomizer)
        unlock_packed_bools(25407, 25511) --Future Shock Bruiser - Crates, Nightmare Bruiser - Large Burger, Nightmare Bruiser - Large Doughnuts, Nightmare Bruiser - Large eCola Cans, All variants of Slamvan - Rear Bumper Reinforced Armor, All variants of Slamvan - Rear Bumper Heavy Armor, Apocalypse Slamvan - Basic Spears, Apocalypse Slamvan - Battle Cross, Apocalypse Slamvan - War Cross, Apocalypse Slamvan - Battle Spears, Apocalypse Slamvan - War Spears, Nightmare Slamvan - Knife Spears, Nightmare Slamvan - Fork & Knife, Apocalypse & Nightmare Brutus - Gassed Up Bar, Apocalypse & Nightmare Brutus - Roadblock, Apocalypse & Nightmare Brutus - Junk Trunk, Apocalypse & Nightmare Brutus - Fire Spitters, Apocalypse & Nightmare Brutus - Hell Chambers, Apocalypse & Nightmare Brutus - Heavy Armored Arches, Apocalypse & Nightmare Brutus - Toothy, Apocalypse & Nightmare Brutus - Armored Spares, Apocalypse & Nightmare Brutus - Armored Supplies, Apocalypse & Nightmare Brutus - Eternally Chained, Apocalypse & Nightmare Brutus - Speared, Future Shock Scarab - Primary Full Armor, All variants of Scarab - Secondary Full Armor, All variants of Scarab - Carbon Full Armor, Future Shock Scarab - Heavy Duty Cooling / Apocalypse & Nightmare Scarab - Air Filtration Vents & Long Range Equipment, Apocalypse & Nightmare Scarab - Rusty Full Armor, Apocalypse & Nightmare Scarab - Rear War Poles, Apocalypse & Nightmare Scarab - Rear Spears, Apocalypse & Nightmare Scarab - Skull Cross, Apocalypse & Nightmare Scarab - Skull Cross w/ War Poles, Apocalypse & Nightmare Scarab - Skull Cross w/ Spears, Apocalypse & Nightmare Scarab - Load'a War Poles, Apocalypse & Nightmare Scarab - Load'a Spears, Apocalypse & Nightmare Scarab - Scarab Mega Cover set, Apocalypse & Nightmare Scarab - Armored Mega Cover set, Apocalypse & Nightmare Scarab - Cage, Apocalypse & Nightmare Scarab - Plated Cage, Future Shock Scarab - Livery Armor, Future Shock Scarab - Primary Full Armor, Future Shock Scarab - Livery Full Armor, Future Shock Scarab - Carbon Full Armor, Future Shock Scarab - Matte Full Armor, Future Shock Scarab - Futuristic Panel Armor, Future Shock Scarab - Plated Livery Full Armor, All variants of Dominator - Triple Front Exhausts, All variants of Dominator - Horn Exhausts, All variants of Dominator - Triple Rear Exhausts, Apocalypse & Nightmare Dominator - Rear Pointing War Poles, Apocalypse & Nightmare Dominator - Front Facing Axes, Apocalypse & Nightmare Dominator - Front Facing Spears, Apocalypse & Nightmare Dominator - Unholy Cross, Apocalypse & Nightmare Dominator - Brutal Unholy Cross, Apocalypse & Nightmare Dominator - Bunch of War Poles, Apocalypse & Nightmare Dominator - Front Pointing War Poles, Apocalypse & Nightmare Dominator - Skull Hood, Apocalypse & Nightmare Impaler - Got Pole?, Apocalypse & Nightmare Impaler - Getting Medieval, Apocalypse & Nightmare Impaler - Wasteland Peacock, Apocalypse & Nightmare Impaler - Shish-Kebbabed, Apocalypse & Nightmare Impaler - It's A Stick Up, Apocalypse & Nightmare Impaler - The Dark Ages, Apocalypse & Nightmare Impaler - Dolly Spearton, Apocalypse & Nightmare Impaler - War Poles, All variants of Imperator - Shakotan Exhaust, Apocalypse & Nightmare Imperator - Whole Lotta Pole, Apocalypse & Nightmare Imperator - Getting Medieval, Apocalypse & Nightmare Imperator - It's A Stick Up, Apocalypse & Nightmare Imperator - Boom On A Spear, Apocalypse & Nightmare Imperator - Village Justice, Apocalypse & Nightmare Imperator - Wasteland Peacock, Apocalypse & Nightmare Imperator - Shish-Kebbabed, Apocalypse & Nightmare Imperator - Junk Pipes, Apocalypse & Nightmare Imperator - Mega Zorst, Apocalypse & Nightmare Imperator - Ride 'Em Cowboy, Apocalypse & Nightmare Imperator - Cannibal Totem, All variants of ZR380 - Side Exhausts, All variants of ZR380 - Spike Exhausts, Apocalypse & Nightmare ZR380 - Mismatch, Future Shock ZR380 - Ray Gun Exhausts, Future Shock ZR380 - Sprint Car Wing, Future Shock ZR380 - Armor Plating Mk. 3, Future Shock ZR380 - Rear Phantom Covers, All variants of Issi - Heavy Duty Ram Bar, Apocalypse & Nightmare Issi - Spear, Apocalypse & Nightmare Issi - Left War Poles, Apocalypse & Nightmare Issi - Dolly Spearton, Apocalypse & Nightmare Issi - Right War Poles, Apocalypse & Nightmare Issi - Skull Cross, Apocalypse & Nightmare Issi - Dolly Spearton Set, Apocalypse & Nightmare Issi - Dual War Poles, Apocalypse & Nightmare Issi - Dolly Spearton W/ War Pole, Apocalypse & Nightmare Issi - Skull Cross W/ Spear, Apocalypse & Nightmare Issi - Skull Cross W/ War Pole, Apocalypse & Nightmare Issi - Skull Cross W/ Dolly, Apocalypse & Nightmare Issi - Left Spear, Apocalypse & Nightmare Issi - Right Spear, Apocalypse & Nightmare Issi - Left Skull Axe, Apocalypse & Nightmare Issi - Right Axe, Apocalypse & Nightmare Issi - Dual Spears, Apocalypse & Nightmare Issi - Spear & Axe, Apocalypse & Nightmare Issi - Axe & Spear, Apocalypse & Nightmare Issi - Dual Axes
        unlock_packed_bools(25516, 25516) --RC Tank
        unlock_packed_bools(25520, 25531) --Metal Detector
        unlock_packed_bools(26811, 26964) --Action Figures, Playing Cards
        unlock_packed_bools(28099, 28148) --Signal Jammers
        unlock_packed_bools(28222, 28222) --Pixtro and Akedo T-Shirts
        unlock_packed_bools(26968, 27088) --Impotent Rage Outfit, High Roller, Tiger Scuba, Sprunk Racing Suit, Neon Bodysuit, Extreme Strike Vest, The Chimera (Outfit), White Racing Suit, The Reconnaissance (Outfit), Blue Jock Cranley Suit, Italian Biker Suit, The Hazard (Outfit), Mid Strike Vest, Splinter Gorka Suit, The Gunfighter (Outfit), Black Plate Carrier*, Hunter Leather Fur Jacket, Chamois Plate Carrier*, Black Heavy Utility Vest, The Puff (Outfit), Ox Blood Patched Cut, Color Geo PRB Leather, Blue Tactical Blouson, Orange Big Cat*, Color Geo Sweater, Vivid Gradient Puffer, Color Diamond Sweater, Classic SN Print Sweater, Power Motocross, The Buzz (Outfit), Pegassi Racing Jacket, Woodland Camo Parka, Le Chien Print Sweater, The Pincer (Outfit), Vibrant Gradient Shortsleeve, Urban Gradient Shortsleeve, White Chevron SC Track, Slalom Motocross, Blue Savanna Shortsleeve, Green Didier Sachs Field, Candy Motocross, Tutti Frutti Pattern Sweater, The Vespucci (Outfit), Contrast Camo Service Shirt, Tropical Pattern Sweater, Black Service Shirt, SecuroServ 1 (Outfit), Black Sports Blagueurs Hoodie, Gold Shiny T-Shirt, OJ Shortsleeve, Primary Squash Hoodie, Purple Camo Bigness Hoodie, Bold Abstract Bigness Hoodie, Pink SN Hoodie, Red Boating Blazer, Multicolor Leaves Shortsleeve, Neon Leaves Güffy Hoodie, Black Dotted Shortsleeve, Drive Motocross, Red Patterned Shortsleeve, Steel Horse Satin Jacket, Orange Squash Hoodie, Regal Loose Shirt, White Güffy Hoodie, Stealth Utility Vest, Red Floral Sweater, Black & Red Bigness Jersey, The Slick (Outfit), Splat Squash Sweater, Tan Hooded Jacket, Brushstroke Combat Shirt, White & Red Bigness Jersey, Black Combat Top, Lime Longline Hoodie, Red Bold Check, Bold Camo Sand Castle Sweater, Red Combat Shirt, Red Mist XI Dark, Cyan Manor Sweater, Flecktarn Sleeveless Shirt, Forest Camo Battle Vest, LS Jardineros Dark, Liberty Cocks Dark, Angelica T-Shirt, Hinterland Ship Sweater, Wine Sleeveless Shirt, Cobble Sleeveless, Black Dense Logo Sweater*, White Flying Bravo Hoodie, Cat T-Shirt*, Color Geo T-Shirt, Bold Abstract Bigness T-Shirt, Neon Leaves Güffy T-Shirt, Black Baggy Hoodie, White Manor Zigzag T-Shirt, Double P Baseball Shirt, Aqua Camo Rolled Tee, Dark Woodland T-Shirt, White Bigness T-Shirt, Black No Retreat Tank, White Benny's T-Shirt, Red Smuggler Tank, Angels of Death Vivid Tee, Blue Hit & Run Tank, Waves T-Shirt*, Beige Turtleneck, Hinterland Nugget T-Shirt, Mustard Güffy Tank, Nagasaki White and Red Hoodie, Grotti Tee, Western Logo Black Tee, Butchery and other Hobbies, Black Ammu-Nation Hoodie*, Fake Santo Capra T-Shirt, Death Defying T-Shirt, Bahama Mamas, Showroom T-Shirt, LS UR Tee, J Lager Beer Hat, Unicorn, Gingerbread
        unlock_packed_bools(27109, 27115) --The Diamond Classic T-Shirt, The Diamond Vintage T-Shirt, Red The Diamond LS T-Shirt, Blue The Diamond Resort LS T-Shirt, Red The Diamond Resort T-Shirt, Blue D Casino T-Shirt, Red The Diamond Classic T-Shirt,
        unlock_packed_bools(27120, 27145) --White The Diamond Hoodie, Black The Diamond Hoodie, Ash The Diamond Hoodie, Gray The Diamond Hoodie, Red The Diamond Hoodie, Orange The Diamond Hoodie, Blue The Diamond Hoodie, Black The Diamond Silk Robe, White The Diamond Cap, Black The Diamond Cap, White LS Diamond Cap, Black LS Diamond Cap, Red The Diamond Cap, Orange The Diamond Cap, Blue LS Diamond Cap, Green The Diamond Cap, Orange LS Diamond Cap, Purple The Diamond Cap, Pink LS Diamond Cap, White The Diamond LS Tee*, Black The Diamond LS Tee, Black The Diamond Resort LS Tee, White The Diamond Resort Tee, Black The Diamond Resort Tee, Black LS Diamond Tee, Black D Casino Tee,
        unlock_packed_bools(27184, 27213) --Invade and Persuade Enemies T-Shirt, Invade and Persuade Oil T-Shirt, Invade and Persuade Tour T-Shirt, Invade and Persuade Green T-Shirt, Invade and Persuade RON T-Shirt, Street Crimes Hoods T-Shirt, Street Crimes Punks T-Shirt, Street Crimes Yokels T-Shirt, Street Crimes Bikers T-Shirt, Street Crimes Action T-Shirt, Street Crimes Boxart T-Shirt, Street Crimes Logo T-Shirt, Claim What's Yours T-Shirt, Choose Your Side T-Shirt, Street Crimes Color Gangs T-Shirt, Street Crimes Red Gangs T-Shirt, White Street Crimes Icons T-Shirt, Black Street Crimes Icons T-Shirt, Invade and Persuade Logo T-Shirt, Mission I T-Shirt, Mission II T-Shirt, Mission IV T-Shirt, Mission III T-Shirt, Invade and Persuade Boxart T-Shirt, Invade and Persuade Invader T-Shirt, Invade and Persuade Suck T-Shirt, Invade and Persuade Jets T-Shirt, Invade and Persuade Gold T-Shirt, Invade and Persuade Hero T-Shirt, Invade and Persuade Barrels T-Shirt
        unlock_packed_bools(27247, 27247) --Madam Nazar (Arcade Trophy)
        unlock_packed_bools(28158, 28158) --Navy Revolver,
        unlock_packed_bools(28171, 28191) --Green Reindeer Lights Bodysuit, Ho-Ho-Ho Sweater, Traditional Festive Lights Bodysuit, Yellow Reindeer Lights Bodysuit, Neon Festive Lights Bodysuit, Plushie Grindy T-Shirt, Plushie Saki T-Shirt , Plushie Humpy T-Shirt, Plushie Smoker T-Shirt, Plushie Poopie T-Shirt, Plushie Muffy T-Shirt, Plushie Wasabi Kitty T-Shirt, Plushie Princess T-Shirt, Plushie Master T-Shirt, Pixel Pete's T-Shirt, Wonderama T-Shirt, Warehouse T-Shirt, Eight Bit T-Shirt, Insert Coin T-Shirt, Videogeddon T-Shirt, Nazar Speaks T-Shirt
        unlock_packed_bools(28197, 28222) --Badlands Revenge II Gunshot T-Shirt, Badlands Revenge II Eagle T-Shirt, Badlands Revenge II Pixtro T-Shirt, Badlands Revenge II Romance T-Shirt, Badlands Revenge II Bear T-Shirt, Badlands Revenge II Help Me T-Shirt & Badlands Revenge II Retro T-Shirt, Race and Chase Decor T-Shirt, Race and Chase Vehicles T-Shirt, Race and Chase Finish T-Shirt, Crotch Rockets T-Shirt, Street Legal T-Shirt & Get Truckin' T-Shirt, Wizard's Ruin Loot T-Shirt, The Wizard's Ruin Rescue T-Shirt, The Wizard's Ruin Vow T-Shirt, Thog Mighty Sword T-Shirt, Thog T-Shirt & Thog Bod T-Shirt, Space Monkey 3 T-Shirt, Space Monkey Space Crafts T-Shirt, Space Monkey Pixel T-Shirt, Space Monkey Boss Fights T-Shirt, Radioactive Space Monkey T-Shirt & Space Monkey Art T-Shirt, Monkey's Paradise T-Shirt, Retro Defender of the Faith T-Shirt, Penetrator T-Shirt, Defender of the Faith T-Shirt, Love Professor His T-Shirt & Love Professor Hers T-Shirt, Love Professor Nemesis T-Shirt, Love Professor Friendzoned T-Shirt, Love Professor Secrets T-Shirt & Love Professor Score T-Shirt, Shiny Wasabi Kitty Claw T-Shirt, Pixtro T-Shirt, Akedo T-Shirt & Arcade Trophy T-Shirt
        unlock_packed_bools(28224, 28227) --White Dog With Cone T-Shirt, Yellow Dog With Cone T-Shirt, Dog With Cone Slip-Ons & Dog With Cone Chain, Refuse Collectors Outfit, Undertakers Outfit, Valet Outfit
        unlock_packed_bools(28229, 28229) --Prison Guards Outfits
        unlock_packed_bools(28230, 28249) --FIB Suits, Scubba Gear, Gruppe Sechs Gear, Bugstars Uniforms, Maintenance Outfit, Yung Ancestors Outfit, Firefighter Outfit, Orderly Armor Outfit, Upscale Armor Outfit, Evening Armor Outfit, Reinforced: Padded Combat Outfit, Reinforced: Bulk Combat Outfit, Reinforced: Compact Combat Outfit, Balaclava Crook Outfit, Classic Crook Outfit, High-end Crook Outfit, Infiltration: Upgraded Tech Outfit, Infiltration: Advanced Tech Outfit, Infiltration: Modernized Tech Outfit, Degenatron Glitch T-Shirt
        unlock_packed_bools(28254, 28255) --Get Metal T-Shirt / Axe of Fury T-Shirt, 11 11 T-Shirt / Axe of Fury T-Shirt,
        unlock_packed_bools(30230, 30251) --Movie Props, Space Interloper Outfit
        unlock_packed_bools(30254, 30295) --King Of QUB3D T-Shirt, Qubism T-Shirt, God Of QUB3D T-Shirt, QUB3D Boxart T-Shirt, Qub3d Qub3s T-Shirt, Yacht Captain Outfit, BCTR Aged T-Shirt, BCTR T-Shirt, Cultstoppers Aged T-Shirt, Cultstoppers T-Shirt, Daily Globe Aged T-Shirt, Daily Globe T-Shirt, Eyefind Aged T-Shirt, Eyefind T-Shirt, Facade Aged T-Shirt, Facade T-Shirt, Fruit Aged T-Shirt, Fruit T-Shirt, LSHH Aged T-Shirt, LSHH T-Shirt, MyRoom Aged T-Shirt, MyRoom T-Shirt, Rebel Aged T-Shirt, Rebel T-Shirt, Six Figure Aged T-Shirt, Six Figure T-Shirt, Trash Or Treasure Aged T-Shirt, Trash Or Treasure T-Shirt, Tw@ Logo Aged T-Shirt, Tw@ Logo T-Shirt, Vapers Den Aged T-Shirt, Vapers Den T-Shirt, WingIt Aged T-Shirt, WingIt T-Shirt, ZiT Aged T-Shirt, ZiT T-Shirt, Green Dot Tech Mask, Orange Dot Tech Mask, Blue Dot Tech Mask, Pink Dot Tech Mask, Lemon Sports Track Pants, Lemon Sports Track Top,
        unlock_packed_bools(30524, 30557) --Grotti Aged T-Shirt, Lampadati Aged T-Shirt, Ocelot Aged T-Shirt, Overflod Aged T-Shirt, Pegassi Aged T-Shirt, Pfister Aged T-Shirt, Vapid Aged T-Shirt, Weeny Aged T-Shirt, Blue The Diamond Resort LS Aged T-Shirt, KJAH Radio Aged T-Shirt, K-Rose Aged T-Shirt, Emotion 98.3 Aged T-Shirt, KDST Aged T-Shirt, Bounce FM Aged T-Shirt, Fake Vapid Aged T-Shirt, I Married My Dad Aged T-Shirt, ToeShoes Aged T-Shirt, Vanilla Unicorn Aged T-Shirt, Steel Horse Solid Logo Aged T-Shirt, Black Western Logo Aged T-Shirt, White Nagasaki Aged T-Shirt, Black Principe Aged T-Shirt, Noise Aged T-Shirt, Noise Rockstar Logo Aged T-Shirt, Razor Aged T-Shirt, White Rockstar Camo Aged T-Shirt, LSUR Aged T-Shirt, Rebel Radio Aged T-Shirt, Channel X Aged T-Shirt, Albany Vintage Aged T-Shirt, Benefactor Aged T-Shirt, Bravado Aged T-Shirt, Declasse Aged T-Shirt, Dinka Aged T-Shirt
        unlock_packed_bools(30563, 30693) --Panther Varsity Jacket Closed, Panther Tour Jacket, Broker Prolaps Basketball Top, Panic Prolaps Basketball Top, Gussét Frog T-Shirt, Warped Still Slipping T-Shirt, Yellow Still Slipping T-Shirt, Black Rockstar T-Shirt, Black Exsorbeo 720 Logo T-Shirt, Manor PRBG T-Shirt, Manor Tie-dye T-Shirt, Open Wheel Sponsor T-Shirt, Rockstar Yellow Pattern T-Shirt, Rockstar Gray Pattern T-Shirt, Rockstar Rolling T-Shirt, Santo Capra Patterns Sweater, Rockstar Studio Colors Sweater, Bigness Jackal Sweater, Bigness Tie-dye Sweater, Bigness Faces Sweater, Broker Prolaps Basketball Shorts, Panic Prolaps Basketball Shorts, Exsorbeo 720 Sports Shorts, Bigness Tie-dye Sports Pants, Enus Yeti Forwards Cap, 720 Forwards Cap, Exsorbeo 720 Forwards Cap, Güffy Double Logo Forwards Cap, Rockstar Forwards Cap, Blue Bangles (L), Red Bangles (L), Pink Bangles (L), Yellow Bangles (L), Orange Bangles (L), Green Bangles (L), Red & Blue Bangles (L), Yellow & Orange Bangles (L), Green & Pink Bangles (L), Rainbow Bangles (L), Sunset Bangles (L), Tropical Bangles (L), Blue & Pink Glow Shades, Red Glow Shades, Orange Glow Shades, Yellow Glow Shades, Green Glow Shades, Blue Glow Shades, Pink Glow Shades, Blue & Magenta Glow Shades, Purple & Yellow Glow Shades, Blue & Yellow Glow Shades, Pink & Yellow Glow Shades, Red & Yellow Glow Shades, Blue Glow Necklace, Red Glow Necklace, Pink Glow Necklace, Yellow Glow Necklace, Orange Glow Necklace, Green Glow Necklace, Festival Glow Necklace, Carnival Glow Necklace, Tropical Glow Necklace, Hot Glow Necklace, Neon Glow Necklace, Party Glow Necklace, Sunset Glow Necklace, Radiant Glow Necklace, Sunrise Glow Necklace, Session Glow Necklace, Combat Shotgun, Perico Pistol, White Keinemusik T-Shirt, Blue Keinemusik T-Shirt, Moodymann T-Shirt, Palms Trax T-Shirt, Midnight Tint Oversize Shades, Sunset Tint Oversize Shades, Black Tint Oversize Shades, Blue Tint Oversize Shades, Gold Tint Oversize Shades, Green Tint Oversize Shades, Orange Tint Oversize Shades, Red Tint Oversize Shades, Pink Tint Oversize Shades, Yellow Tint Oversize Shades, Lemon Tint Oversize Shades, Gold Rimmed Oversize Shades, White Checked Round Shades, Pink Checked Round Shades, Yellow Checked Round Shades, Red Checked Round Shades, White Round Shades, Black Round Shades, Pink Tinted Round Shades, Blue Tinted Round Shades, Green Checked Round Shades, Blue Checked Round Shades, Orange Checked Round Shades, Green Tinted Round Shades, Brown Square Shades, Yellow Square Shades, Black Square Shades, Tortoiseshell Square Shades, Green Square Shades, Red Square Shades, Pink Tinted Square Shades, Blue Tinted Square Shades, White Square Shades, Pink Square Shades, All White Square Shades, Mono Square Shades, Green Calavera Mask, Navy Calavera Mask, Cherry Calavera Mask, Orange Calavera Mask, Purple Calavera Mask, Dark Blue Calavera Mask, Lavender Calavera Mask, Yellow Calavera Mask, Pink Calavera Mask, Neon Stitch Emissive Mask, Vibrant Stitch Emissive Mask, Pink Stitch Emissive Mask, Blue Stitch Emissive Mask, Neon Skull Emissive Mask, Vibrant Skull Emissive Mask, Pink Skull Emissive Mask, Orange Skull Emissive Mask, Dark X-Ray Emissive Mask, Bright X-Ray Emissive Mask, Purple X-Ray Emissive Mask
        unlock_packed_bools(30699, 30704) --Palms Trax LS T-Shirt, Moodymann Whatupdoe T-Shirt, Moodymann Big D T-Shirt, Keinemusik Cayo Perico T-Shirt, Still Slipping Blarneys T-Shirt, Still Slipping Friend T-Shirt
        unlock_packed_bools(31708, 31714) --CircoLoco Records - Blue EP, CircoLoco Records - Green EP, CircoLoco Records - Violet EP, CircoLoco Records - Black EP, Moodymann - Kenny's Backyard Boogie, NEZ - You Wanna?, NEZ ft. Schoolboy Q - Let's Get It
        unlock_packed_bools(31736, 31736) --The Frontier Outfit
        unlock_packed_bools(31755, 31755) --Auto Shop Race 'n Chase
        unlock_packed_bools(31760, 31764) --Faces of Death T-Shirt, Straight to Video T-Shirt, Monkey See Monkey Die T-Shirt, Trained to Kill T-Shirt, The Director T-Shirt
        unlock_packed_bools(31766, 31777) --Sprunk Forwards Cap, eCola Forwards Cap, Black Banshee T-Shirt, Blue Banshee T-Shirt, LS Customs T-Shirt, Rockstar Games Typeface T-Shirt, Wasted! T-Shirt, Baseball Bat T-Shirt, Knuckleduster T-Shirt, Rampage T-Shirt, Penitentiary Coveralls, LS Customs Coveralls
        unlock_packed_bools(31779, 31793) --The Ringleader Outfit, The Knuckles Outfit, The Breaker Outfit, The Dealer Outfit, Bearsy, Banshee Hoodie, eCola Varsity, Sprunk Varsity, LS Customs Varsity, LS Customs Tour Jacket, eCola Bodysuit, Sprunk Bodysuit, Sprunk Chute Bag, eCola Chute Bag, Halloween Chute Bag
        unlock_packed_bools(31805, 31808) --The Old Hand Outfit, The Overworked Outfit, The Longshoreman Outfit, The Underpaid Outfit
        unlock_packed_bools(31810, 31824) --Annis ZR350, Pfister Comet S2, Dinka Jester RR, Emperor Vectre, Ubermacht Cypher, Pfister Growler, Karin Calico GTF, Annis Remus, Vapid Dominator ASP, Karin Futo GTX, Dinka RT3000, Vulcar Warrener HKR, Karin Sultan RS Classic, Vapid Dominator GTT, Karin Previon
        unlock_packed_bools(31826, 31858) --Emperor Forwards Cap / Emperor Backwards Cap, Beige Knit Sneakers, Gray Emperor Classic Hoodie, Pursuit Series (Gameplay), Cyan Check Sleeveless Puffer, Dinka SPL (Wheel Mod), Blue Hayes Retro Racing, White Emperor Motors T-Shirt, Quick Fix (Gameplay), Cyan Check Puffer, Euros - Speed Trail (Livery), Never Barcode Print Hoodie, Hayes Modern Racing, Diversion (Gameplay), Gray Leather Bomber, Futo GTX - Chokusen Dorifuto (Livery), Karin Forwards Cap / Karin Backwards Cap, Cream Knit Sneakers, Private Takeover (Gameplay), Yellow Pfister Hoodie, Retro Turbofan (Wheel Mod), Red Check Sleeveless Puffer, White Hayes Retro Racing, Setup (Gameplay), Navy Emperor Motors T-Shirt, RT3000 - Stance Andreas (Livery), Red Check Puffer, Never Triangle Print Hoodie, Wingman (Gameplay), LTD Modern Racing, Jester RR - 10 Minute Car (Livery), Green Crowex Pro Racing Suit, Mustard Tan Leather Bomber
        unlock_packed_bools(31860, 31863) --Omnis Forwards Cap / Omnis Backwards Cap, Conical Turbofan (Wheel Mod), Black Knit Sneakers, Green Emperor Classic Hoodie
        unlock_packed_bools(31865, 31868) --Green Geo Sleeveless Puffer, ZR350 - Atomic Drift Team (Livery), White Globe Oil Retro Racing, Yellow Annis Rally T-Shirt
        unlock_packed_bools(31870, 31928) --Green Geo Puffer, Warrener HKR - Classic Vulcar (Livery), Life ZigZag Print Hoodie, Blue Dinka Modern Racing, Gray Benefactor Racing Suit, Orange Tan Leather Bomber, Ice Storm (Wheel Mod), Annis Forwards Cap / Annis Backwards Cap, Gray & Purple Knit Sneakers, Black Crowex Pro Racing Suit, Gray Pfister Hoodie, Calico GTF - Fukaru Rally (Livery), Black Geo Sleeveless Puffer, Green Crowex Retro Racing, Blue Xero Gas Racing Suit, Blue Annis Noise T-Shirt, Remus - Blue Lightning (Livery), Black Geo Puffer, Life Static Print Hoodie, Dark Benefactor Racing Suit, Red Dinka Modern Racing, Super Turbine (Wheel Mod), Chestnut Tan Leather Bomber, Vapid Forwards Cap / Vapid Backwards Cap, Red Xero Gas Racing Suit, Gray & Magenta Knit Sneakers, Dominator GTT - Oldschool Oval (Livery), Black Vapid Ellie Hoodie, Cream Bigness Sleeveless Puffer, Wildstyle Racing Suit, Red Globe Oil Retro Racing, Tailgater S - Crevis Race (Livery), Light Dinka T-Shirt, Cream Bigness Puffer, Modern Mesh (Wheel Mod), Never Crosshair Print Hoodie, Euros - Drift Tribe (Livery), Yellow Vapid Modern Racing, Dark Tan Leather Bomber, Forged Star (Wheel Mod), Light Dinka Forwards Cap / Light Dinka Backwards Cap, Futo GTX - Drift King (Livery), Gray & Aqua Knit Sneakers, Gray Karin Hoodie, Showflake (Wheel Mod), Purple Bigness Sleeveless Puffer, RT3000 - Atomic Motorsport (Livery), Black Crowex Retro Racing, Black Annis Noise T-Shirt, Giga Mesh (Wheel Mod), Purple Bigness Puffer, Jester RR - Yogarishima (Livery), Hiding Print Hoodie, Ubermacht Modern Racing, Mesh Meister (Wheel Mod), Ox Blood Leather Bomber, ZR350 - Kisama Chevrons (Livery), Dark Dinka Forwards Cap / Dark Dinka Backwards Cap, White & Pink Knit Sneakers
        unlock_packed_bools(31930, 31933) --Navy Vapid Ellie Hoodie, Warrener HKR - Classic Vulcar Alt (Livery), Green Aztec Sleeveless Puffer, Calico GTF - Disruption Rally (Livery)
        unlock_packed_bools(31935, 31938) --Blue Atomic Retro Racing, Remus - Annis Tech (Livery), Dark Dinka T-Shirt, Dominator GTT - Resto Mod Racer (Livery)
        unlock_packed_bools(31940, 31943) --Green Aztec Puffer, Tailgater S - Redwood (Livery), Life Binary Print Hoodie, Euros - King Scorpion (Livery)
        unlock_packed_bools(31945, 31948) --White Güffy Modern Racing, Futo GTX - Tandem Battle (Livery), Dark Nut Leather Bomber, RT3000 - Dinka Performance (Livery)
        unlock_packed_bools(31950, 31953) --White Güffy Forwards Cap / White Güffy Backwards Cap, Jester RR - Fuque (Livery), Gray & Yellow Knit Sneakers, ZR350 - Winning is Winning (Livery)
        unlock_packed_bools(31955, 31956) --Navy Karin Hoodie, Warrener HKR - Redwood Racing (Livery)
        unlock_packed_bools(31957, 31958) --Black Aztec Sleeveless Puffer, Calico GTF - Redwood Rally (Livery)
        unlock_packed_bools(31960, 31963) --Yellow Atomic Retro Racing, Remus - Atomic Motorsport (Livery), Light Vapid Ellie T-Shirt, Dominator GTT - Flame On (Livery)
        unlock_packed_bools(31965, 31968) --Black Aztec Puffer, Tailgater S - Disruption Logistics (Livery), Lucky Penny Print Hoodie, Euros - Sprunk Light (Livery)
        unlock_packed_bools(31970, 31973) --Black Güffy Modern Racing, Futo GTX - Itasha Drift (Livery), Navy Blue Leather Bomber, RT3000 - Shiny Wasabi Kitty (Livery)
        unlock_packed_bools(31975, 31978) --Black Güffy Forwards Cap / Black Güffy Backwards Cap, Jester RR - Xero Gas Rally (Livery), Grayscale Knit Sneakers, ZR350 - Annis Racing Tribal (Livery)
        unlock_packed_bools(31980, 31983) --Light Obey Hoodie, Warrener HKR - Vulcar Turbo (Livery), Cream Splinter Sleeveless Puffer, Calico GTF - Prolaps Rally (Livery)
        unlock_packed_bools(31985, 31988) --Blue Redwood Retro Racing, Remus - Shiny Wasabi Kitty (Livery), Dark Vapid Ellie T-Shirt, Dominator GTT - The Patriot (Livery)
        unlock_packed_bools(31990, 31993) --Cream Splinter Puffer, Tailgater S - Colored Camo Livery (Livery), Light Dinka Modern Racing, Euros - Candybox Gold (Livery)
        unlock_packed_bools(31995, 31998) --Dark Green Leather Bomber, Futo GTX - Stance Andreas (Livery), Hellion Forwards Cap / Hellion Backwards Cap, RT3000 - Total Fire (Livery)
        unlock_packed_bools(32000, 32003) --Gray & Cyan Knit Sneakers, Jester RR - Split Siberia (Livery), Black Ubermacht Hoodie, ZR350 - Annis Racing Tribal Alt (Livery)
        unlock_packed_bools(32005, 32008) --Dark Splinter Sleeveless Puffer, Warrener HKR - Vulcar Turbo Alt (Livery), White Logo Ruiner T-Shirt, Calico GTF - Xero Gas Rally (Livery)
        unlock_packed_bools(32010, 32013) --Dark Splinter Puffer, Remus - Fukaru Motorsport (Livery), Dark Dinka Modern Racing, Dominator GTT - 70s Street Machine (Livery)
        unlock_packed_bools(32015, 32018) --White Leather Bomber, Tailgater S - Army Camo Solid (Livery), Lampadati Forwards Cap / Lampadati Backwards Cap, Lilac Knit Sneakers
        unlock_packed_bools(32020, 32023) --Dark Obey Hoodie, Green Latin Sleeveless Puffer, Gray Vapid Truck T-Shirt, Green Latin Puffer
        unlock_packed_bools(32025, 32028) --Blue Bravado Modern Racing, Red Leather Bomber, White Knit Sneakers, Red Ubermacht Hoodie
        unlock_packed_bools(32030, 32033) --Black Latin Sleeveless Puffer, White Obey Omnis T-Shirt, Black Latin Puffer, Black Bravado Modern Racing
        unlock_packed_bools(32035, 32038) --Ice Knit Sneakers, Blue Annis Noise Hoodie, Orange Camo Sleeveless Puffer, Light Blue Vapid Truck T-Shirt
        unlock_packed_bools(32040, 32043) --Orange Camo Puffer, Imponte Modern Racing, Aqua Sole Knit Sneakers, Green Emperor Modern Hoodie
        unlock_packed_bools(32045, 32048) --Aqua Camo Sleeveless Puffer, Black Vapid USA T-Shirt, Aqua Camo Puffer, Xero Modern Racing
        unlock_packed_bools(32050, 32053) --Smoky Knit Sneakers, Gray Annis Noise Hoodie, Gradient Sleeveless Puffer, Red Obey Omnis T-Shirt
        unlock_packed_bools(32055, 32058) --Gradient Puffer, White & Gold Knit Sneakers, Dark Emperor Modern Hoodie, Red Logo Ruiner T-Shirt
        unlock_packed_bools(32060, 32063) --Orange Knit Sneakers, Light Dinka Hoodie, Blue Bravado Gauntlet T-Shirt, Pink Vibrant Knit Sneakers
        unlock_packed_bools(32065, 32074) --Gold Lampadati Hoodie, Black Bravado Gauntlet T-Shirt, Lime Highlight Knit Sneakers, Dark Dinka Hoodie, Pfister Pocket T-Shirt, Purple Fade Knit Sneakers, Karin 90s T-Shirt, Teal Knit Sneakers, Black & Lime Knit Sneakers, Cyan Fade Knit Sneakers
        unlock_packed_bools(32084, 32084) --Red Highlight Knit Sneakers
        unlock_packed_bools(32094, 32094) --Broker Forwards Cap / Broker Backwards Cap
        unlock_packed_bools(32104, 32104) --Annis Hellion 4x4 T-Shirt
        unlock_packed_bools(32114, 32114) --Pink Gradient Sleeveless Puffer
        unlock_packed_bools(32124, 32124) --Fade Broker Modern Racing
        unlock_packed_bools(32134, 32134) --Tricolor Lampadati Hoodie
        unlock_packed_bools(32144, 32144) --Mono Leather Bomber
        unlock_packed_bools(32154, 32154) --Pink Gradient Puffer
        unlock_packed_bools(32164, 32164) --Red Redwood Retro Racing
        unlock_packed_bools(32174, 32174) --Crash Out Print Hoodie
        unlock_packed_bools(32224, 32224) --Tuned For Speed Racing Suit
        unlock_packed_bools(32319, 32323) --police5 trade price
        unlock_packed_bools(34262, 34361) --LD Organics
        unlock_packed_bools(32273, 32273) --White Born x Raised T-Shirt
        unlock_packed_bools(32275, 32275) --Circoloco T-Shirt
        unlock_packed_bools(32287, 32287) --Dr. Dre
        unlock_packed_bools(32295, 32311) --Orange Goldfish, Purple Goldfish, Bronze Goldfish, Clownfish, Juvenile Gull, Sooty Gull, Black-headed Gull, Herring Gull, Brown Sea Lion, Dark Sea Lion, Spotted Sea Lion, Gray Sea Lion, Green Festive T-Shirt, Red Festive T-Shirt, Orange DJ Pooh T-Shirt, White WCC DJ Pooh T-Shirt, Blue WCC DJ Pooh T-Shirt
        unlock_packed_bools(32315, 32316) --Navy Coveralls, Gray Coveralls, Marathon Hoodie
        unlock_packed_bools(32366, 32366) --Declasse Draugur (Trade Price)
        unlock_packed_bools(34372, 34375) --Horror Pumpkin, Dinka Kanjo SJ (Trade Price), Dinka Postlude (Trade Price), White LD Organics T-Shirt
        unlock_packed_bools(34378, 34411) --Junk Energy Chute Bag, Junk Energy Chute, Pumpkin T-Shirt, Pacific Standard Varsity, Pacific Standard Sweater, Cliffford Varsity, Cliffford Hoodie, The Diamond Casino Varsity, The Diamond Strike Vest, Strickler Hat, Sinsimito Cuban Shirt, CLO_E1M_O_MUM, Manor Geo Forwards Cap, Apricot Perseus Forwards Cap, Still Slipping Tie-dye Forwards Cap, Lemon Festive Beer Hat, Bigness Hand-drawn Dome, Grimy Stitched, Pale Stitched, Gray Cracked Puppet, Blushed Cracked Puppet, Green Emissive Lady Liberty, President, Gold Beat Off Earphones, White Spiked Gauntlet (L), Manor Geo Hoodie, Pumpkin Hoodie, LS Smoking Jacket, Hand-Drawn Biker Bomber, Have You Seen Me? Sweater, Still Slipping Tie-dye T-Shirt, Manor Geo Track Pants, Apricot Perseus Track Pants, Sasquatch
        unlock_packed_bools(34415, 34510) --Green Vintage Frank, Brown Vintage Frank, Gray Vintage Frank, Pale Vintage Mummy, Green Vintage Mummy, Weathered Vintage Mummy, Conquest, Death, Famine, War, Black Tech Demon, Gray Tech Demon, White Tech Demon, Green Tech Demon, Orange Tech Demon, Purple Tech Demon, Pink Tech Demon, Red Detail Tech Demon, Blue Detail Tech Demon, Yellow Detail Tech Demon, Green Detail Tech Demon, Pink Detail Tech Demon, Orange & Gray Tech Demon, Red Tech Demon, Camo Tech Demon, Aqua Camo Tech Demon, Brown Digital Tech Demon, Gold Tech Demon, Orange & Cream Tech Demon, Green & Yellow Tech Demon, Pink Floral Tech Demon, Black & Green Tech Demon, White & Red Tech Demon, Carbon Tech Demon, Carbon Teal Tech Demon, Black & White Tech Demon, Painted Tiger, Gray Painted Tiger, Gold Painted Tiger, Ornate Painted Tiger, Gray Yeti Flat Cap, Woodland Yeti Flat Cap, Green FB Flat Cap, Blue FB Flat Cap, Gray Lézard Flat Cap, Green Lézard Flat Cap, Light Plaid Lézard Flat Cap, Dark Plaid Lézard Flat Cap, White Striped Lézard Flat Cap, Red Striped Lézard Flat Cap, Brown Crevis Flat Cap, Gray Crevis Flat Cap, Black Broker Flat Cap, Burgundy Broker Flat Cap, White Beat Off Earphones, Yellow Beat Off Earphones, Salmon Beat Off Earphones, Orange Beat Off Earphones, Purple Beat Off Earphones, Pink Beat Off Earphones, Turquoise Beat Off Earphones, Blue Beat Off Earphones, Black Beat Off Earphones, Gray Beat Off Earphones, Teal Beat Off Earphones, Red Beat Off Earphones, Wild Striped Pool Sliders, Neon Striped Pool Sliders, Black SC Coin Pool Sliders, White SC Coin Pool Sliders, Black SC Pattern Pool Sliders, Pink SC Pattern Pool Sliders, Blue SC Pattern Pool Sliders, Camo Yeti Pool Sliders, Gray Camo Yeti Pool Sliders, Black Bigness Pool Sliders, Purple Bigness Pool Sliders, Camo Bigness Pool Sliders, Black Blagueurs Pool Sliders, White Blagueurs Pool Sliders, Pink Blagueurs Pool Sliders, Gray Cimicino Pool Sliders, Rouge Cimicino Pool Sliders, Navy DS Pool Sliders, Red DS Pool Sliders, Floral Güffy Pool Sliders, Green Güffy Pool Sliders, White Güffy Pool Sliders, Blue Heat Pool Sliders, Red ProLaps Pool Sliders, Black LD Organics T-Shirt, Green UFO Boxer Shorts, White UFO Boxer Shorts, Gray Believe Backwards Cap, Black Believe Backwards Cap, Glow Believe Backwards Cap
        unlock_packed_bools(34703, 34705) --White Vintage Vampire, Dark Green Vintage Vampire, Light Green Vintage Vampire
        unlock_packed_bools(34730, 34737) --Green Festive Beer Hat, Red Snowflake Beer Hat, Blue Snowflake Beer Hat, Red Holly Beer Hat, Pisswasser Festive Beer Hat, Blarneys Festive Beer Hat, Red Reindeer Beer Hat, Borfmas
        unlock_packed_bools(34761, 34761) --Gooch Outfit
        unlock_packed_bools(36630, 36654) --Snowman
        unlock_packed_bools(36699, 36770) --Ice Vinyl, Ice Vinyl Cut, Mustard Vinyl, Mustard Vinyl Cut, Dark Blue Vinyl, Dark Blue Vinyl Cut, Yellow SN Rooster Revere Collar, Red SC Dragon Revere Collar, Blue SC Dragon Revere Collar, Camo Roses Slab Denim, Orange Trickster Type Denim, Black VDG Cardigan, Blue DS Panthers Cardigan, Red DS Panthers Cardigan, Pink SC Baroque Cardigan, Downtown Cab Co. Revere Collar, Valentines Blazer, 420 Smoking Jacket, Yeti Year of the Rabbit T-Shirt, Gray Yeti Combat Shirt, Black Sprunk Festive, Dark Logger Festive, White Logger Festive, Green Logger Festive, Red Logger Festive, Blue Patriot Logo Festive, Black Patriot Logo Festive, Blue Patriot Festive, Red Patriot Festive, Red Pisswasser Festive, Gold Pisswasser Festive, Red Pisswasser Logo Festive, Gold Pisswasser Logo Festive, Green Pride Brew Festive, Yellow Pride Brew Festive, Yellow Holly Pride Festive, White Holly Pride Festive, Sprunk Snowflakes Festive, Broker Checkerboard T-Shirt, Yeti Ape Tucked T-Shirt, Black Bigness Ski, White Bigness Ski, Black Enema Flourish Ski, Teal Enema Flourish Ski, Magenta Enema Flourish Ski, Camo Roses Slab Forwards, Lime Leopard Slab Forwards, Red SC Dragon Embroidered, Classic DS Tiger Embroidered, Gray DS Tiger Embroidered, Black VDG Bandana Wide, Orange Trickster Type Wide, Gray Yeti Battle Pants, Broker Checkerboard Cargos, 420 Smoking Pants, Camo Roses Slab Canvas, Lime Leopard Slab Canvas, White Signs Squash Ugglies & Socks, Traditional Painted Rabbit, Twilight Painted Rabbit, Noh Painted Rabbit, Lime SC Coin Wraps, Pink SC Coin Wraps, Tan Bracelet Ensemble, Red Manor Round Brow Shades, Le Chien Whistle Necklace, Heartbreak Pendant, Rabbit, Budonk-adonk!, The Red-nosed, The Nutcracker, The GoPostal
        unlock_packed_bools(36774, 36788) --Johnny On The Spot Polo, The Gooch Mask, Snowman Outfit, Gold New Year Glasses, Silver New Year Glasses, Rainbow New Year Glasses, Yellow Holly Beer Hat, Green Reindeer Beer Hat, Zebra Dome, Purple Snakeskin Spiked, Manor Surano Jacket, Pistol Mk II - Season's Greetings (Livery), Pump Shotgun - Dildodude Camo (Livery), Micro SMG - Dildodude Camo (Livery)
        unlock_packed_bools(36809, 36809) --Nemesis T-Shirts
        unlock_packed_bools(41316, 41325) --Ghosts Exposed
        unlock_packed_bools(41593, 41593) --The Merryweather Outfit
        unlock_packed_bools(41656, 41659) --Squaddie (Trade Price), Suede Bucks Finish, Employee of the Month Finish, Uncle T Finish
        unlock_packed_bools(41671, 41671) --Manchez Scout (Trade Price)
        unlock_packed_bools(41894, 41894) --Hinterland Work T-Shirt
        unlock_packed_bools(41897, 41902) --Love Fist T-Shirt, San Andreas Federal Reserve T-Shirt, Los Santos, San Andreas T-Shirt, Heist Mask T-Shirt, Los Santos Map T-Shirt, PRB T-Shirt
        unlock_packed_bools(41915, 41941) --LS Pounders Cap, Vom Feuer Camo Cap, Western MC Cap, Red & White Ammu-Nation Cap, Santo Capra Cap, Alpine Hat, Alien Tracksuit Pants, Scarlet Vintage Devil Mask, Amber Vintage Devil Mask, Green Vintage Devil Mask, Green Vintage Witch Mask, Yellow Vintage Witch Mask, Orange Vintage Witch Mask, Green Vintage Skull Mask, White Vintage Skull Mask, Brown Vintage Skull Mask, Orange Vintage Werewolf Mask, Blue Vintage Werewolf Mask, Brown Vintage Werewolf Mask, Green Vintage Zombie Mask, Brown Vintage Zombie Mask, Teal Vintage Zombie Mask, Turkey Mask, Royal Calacas Mask, Maritime Calacas Mask, Romance Calacas Mask, Floral Calacas Mask
        unlock_packed_bools(41942, 41980) --police5 trade price, The Homie, The Retired Criminal, The Groupie, Black SC Ornate Mini Dress, Dark Manor Racing Suit, Bright Manor Racing Suit, Hinterland Bomber Jacket, Red Happy Moon T-Shirt, Black Happy Moon T-Shirt, White Happy Moon T-Shirt, Rockstar Says Relax Tucked T-Shirt, Trevor Heist Mask Tucked T-Shirt, Franklin Heist Mask Tucked T-Shirt, Michael Heist Mask Tucked T-Shirt, Bugstars Tucked T-Shirt, STD Contractors Tucked T-Shirt, Black Los Santos Tucked T-Shirt, San Andreas Republic Tucked T-Shirt, Go Go Space Monkey Tucked T-Shirt, Vom Feuer Camo Tucked T-Shirt, Black SC Ornate Tucked T-Shirt, Warstock Tucked T-Shirt, Western San Andreas Tucked T-Shirt, Ride or Die Tucked T-Shirt, Bourgeoix Tucked T-Shirt, Blêuter'd Tucked T-Shirt, Cherenkov Tucked T-Shirt, Moodymann Portrait Tucked T-Shirt, Rockstar Silver Jubilee Tucked T-Shirt, Rockstar NY Hoodie, Dollar Daggers Hoodie, Merryweather Hoodie, Go Go Space Monkey Hoodie, Rockstar Lion Crest T-Shirt, Ammu-Nation Baseball T-Shirt, Alien Hooded Tracksuit Top, Manor Benefactor Surano T-Shirt, LS Smoking Jacket
        unlock_packed_bools(41994, 41994) --Junk Energy Racing Suit
        unlock_packed_bools(41996, 41996) --??? T-Shirt
        unlock_packed_bools(42054, 42054) --Strapz Bandana
        unlock_packed_bools(42063, 42063) --The LS Panic
        unlock_packed_bools(42068, 42069) --Snowman Finish for Combat Pistol, Santa's Helper Finish
        unlock_packed_bools(42111, 42111) --The Coast Guard
        unlock_packed_bools(42119, 42123) --Yeti Outfit, Snowman Finish, Santa's Helper Finish, Skull Santa Finish, riot unlocked
        unlock_packed_bools(42128, 42129) --eCola Festive Sweater, Sprunk Festive Sweater
        unlock_packed_bools(42125, 42125) --riot trade price
        unlock_packed_bools(42130, 42146) --1 Party Hat, 2 Party Hat, 3 Party Hat, 4 Party Hat, 5 Party Hat, 6 Party Hat, 7 Party Hat, 8 Party Hat, 9 Party Hat, 10 Party Hat, 11 Party Hat, 12 Party Hat, 13 Party Hat, 14 Party Hat, 15 Party Hat, Bronze Party Outfit, Silver Party Outfit
        unlock_packed_bools(42148, 42148) --Snow Launcher
        unlock_packed_bools(42152, 42190) --The LSDS, The McTony Security, Wooden Dragon Mask, Contrast Dragon Mask, Regal Dragon Mask, Midnight Dragon Mask, Pink Heart Shades, Red Heart Shades, Orange Heart Shades, Yellow Heart Shades, Green Heart Shades, Blue Heart Shades, Purple Heart Shades, Black Heart Shades, Fireworks Bucket Hat, Stars and Stripes Bucket Hat, Lady Liberty Bucket Hat, Green Festive Tree Hat, Red Festive Tree Hat, Brown Festive Reindeer Hat, White Festive Reindeer Hat, Bronze New Year's Hat, Gold New Year's Hat, Silver New Year's Hat, Sprunk x eCola Bodysuit, Rockstar Racing Suit, Rockstar Helmet, Coil Earth Day Tee, IR Earth Day Tee, White High Brass Tee, Black High Brass Tee, Black Lunar New Year Tee, Bigness Carnival Sports Tee, Green 420 Dress, Red Lunar New Year Dress, Carnival Sun Dress, Carnival Bandana, Bigness Carnival Bucket Hat, Black 420 Forwards Cap
        unlock_packed_bools(42217, 42217) --Cluckin' Bell Forwards Cap
        unlock_packed_bools(42233, 42234) --BOXVILLE6, BENSON2
        unlock_packed_bools(42239, 42242) --CAVALCADE3, IMPALER5, POLGAUNTLET, DORADO
        unlock_packed_bools(42244, 42247) --BALLER8, TERMINUS, BOXVILLE6, BENSON2
        if is_player_male then
            unlock_packed_bools(3483, 3492) --Death Defying T-Shirt (Male), For Hire T-Shirt (Male), Gimme That T-Shirt (Male), Asshole T-Shirt (Male), Can't Touch This T-Shirt (Male), Decorated T-Shirt (Male), Psycho Killer T-Shirt (Male), One Man Army T-Shirt (Male), Shot Caller T-Shirt (Male), Showroom T-Shirt (Male)
            unlock_packed_bools(6082, 6083) --Black Benny's T-Shirt, White Benny's T-Shirt
            unlock_packed_bools(6097, 6097) --I Heart LC (T-Shirt) (Male)
            unlock_packed_bools(6169, 6169) --DCTL T-Shirt (Male)
            unlock_packed_bools(6303, 6304) --Crosswalk Tee (Male), R* Crosswalk Tee (Male)
            unlock_packed_bools(15708, 15708) --Black The Black Madonna Emb. Tee (Male)
            unlock_packed_bools(15710, 15710) --The Black Madonna Star Tee (Male)
            unlock_packed_bools(15717, 15717) --White Dixon Repeated Logo Tee (Male)
            unlock_packed_bools(15720, 15720) --Black Dixon Wilderness Tee (Male)
            unlock_packed_bools(15724, 15724) --Tale Of Us Black Box Tee (Male)
            unlock_packed_bools(15728, 15728) --Black Tale Of Us Emb. Tee (Male)
            unlock_packed_bools(15730, 15730) --Black Solomun Yellow Logo Tee (Male)
            unlock_packed_bools(15737, 15737) --??? (Tattoo) (Male)
            unlock_packed_bools(15732, 15732) --White Solomun Tee (Male)
            unlock_packed_bools(15887, 15887) --Lucky 7s (Tattoo) (Male)
            unlock_packed_bools(15894, 15894) --Royals (Tattoo) (Male)
            unlock_packed_bools(28393, 28416) --Badlands Revenge II Retro Tee (Male), Badlands Revenge II Pixtro Tee (Male), Degenatron Glitch Tee (Male), Degenatron Logo Tee (Male), The Wizard's Ruin Rescue Tee (Male), The Wizard's Ruin Vow Tee (Male), Space Monkey Art Tee (Male), Crotch Rockets Tee (Male), Street Legal Tee (Male), Get Truckin' Tee (Male), Arcade Trophy Tee (Male), Videogeddon Tee (Male), Insert Coin Tee (Male), Plushie Princess Tee (Male), Plushie Wasabi Kitty Tee (Male), Plushie Master Tee (Male), Plushie Muffy Tee (Male), Plushie Humpy Tee (Male), Plushie Saki Tee (Male), Plushie Grindy Tee (Male), Plushie Poopie Tee (Male), Plushie Smoker Tee (Male), Shiny Wasabi Kitty Claw Tee (Male), Nazar Speaks Tee (Male),
            unlock_packed_bools(28447, 28451) --11 11 Tee (Male), King Of QUB3D Tee (Male), Qubism Tee (Male), God Of QUB3D Tee (Male), QUB3D Boxart Tee (Male),
            unlock_packed_bools(28452, 28478) --Channel X Aged Tee (Male), Rebel Radio Aged Tee (Male), LSUR Aged Tee (Male), Steel Horse Solid Logo Aged Tee (Male), Black Western Logo Aged Tee (Male), White Nagasaki Aged Tee (Male), Black Principe Aged Tee (Male), Albany Vintage Aged Tee (Male), Benefactor Aged Tee (Male), Bravado Aged Tee (Male), Declasse Aged Tee (Male), Dinka Aged Tee (Male), Grotti Aged Tee (Male), Lampadati Aged Tee (Male), Ocelot Aged Tee (Male), Overflod Aged Tee (Male), Pegassi Aged Tee (Male), Pfister Aged Tee (Male), Vapid Aged Tee (Male), Weeny Aged Tee (Male), Toe Shoes Aged T-Shirt (Male), Vanilla Unicorn Aged T-Shirt (Male), Fake Vapid Aged T-Shirt (Male), I Married My Dad Aged T-Shirt (Male), White Rockstar Camo Aged Tee (Male), Razor Aged T-Shirt (Male), Noise Rockstar Logo Aged Tee (Male)
            unlock_packed_bools(30355, 30361) --Noise Aged Tee (Male), Emotion 98.3 Aged T-Shirt (Male), KDST Aged T-Shirt (Male), KJAH Radio Aged T-Shirt (Male), Bounce FM Aged T-Shirt (Male), K-Rose Aged T-Shirt (Male), Blue The Diamond Resort LS Aged Tee (Male)
            unlock_packed_bools(30407, 30410) --White Keinemusik Tee (Male), Blue Keinemusik Tee (Male), Moodymann Tee (Male), Palms Trax Tee (Male)
            unlock_packed_bools(30418, 30422) --Faces of Death Tee (Male), Straight to Video Tee (Male), Monkey See Monkey Die Tee (Male), Trained to Kill Tee (Male), The Director Tee (Male),
            unlock_packed_bools(41273, 41284) --Monkey (Tattoo) (Male), Dragon (Tattoo) (Male), Snake (Tattoo) (Male), Goat (Tattoo) (Male), Rat (Tattoo) (Male), Rabbit (Tattoo) (Male), Ox (Tattoo) (Male), Pig (Tattoo) (Male), Rooster (Tattoo) (Male), Dog (Tattoo) (Male), Horse (Tattoo) (Male), Tiger (Tattoo) (Male)
        else
            unlock_packed_bools(3496, 3505) --Death Defying Top (Female), For Hire Top (Female), Gimme That Top (Female), Asshole Top (Female), Can't Touch This Top (Female), Decorated Top (Female), Psycho Killer Top (Female), One Man Army Top (Female), Shot Caller Top (Female), Showroom Top (Female)
            unlock_packed_bools(6091, 6092) --Black Benny's T-Shirt, White Benny's T-Shirt
            unlock_packed_bools(6106, 6106) --I Heart LC (T-Shirt) (Female)
            unlock_packed_bools(6181, 6181) --DCTL T-Shirt (Female)
            unlock_packed_bools(6316, 6317) --Crosswalk Tee (Female), R* Crosswalk Tee (Female)
            unlock_packed_bools(15719, 15719) --Black The Black Madonna Emb. Tee (Female)
            unlock_packed_bools(15721, 15721) --The Black Madonna Star Tee (Female)
            unlock_packed_bools(15728, 15728) --White Dixon Repeated Logo Tee (Female)
            unlock_packed_bools(15731, 15731) --Black Dixon Wilderness Tee (Female)
            unlock_packed_bools(15735, 15735) --Tale Of Us Black Box Tee (Female)
            unlock_packed_bools(15739, 15739) --Black Tale Of Us Emb. Tee (Female)
            unlock_packed_bools(15741, 15741) --Black Solomun Yellow Logo Tee (Female)
            unlock_packed_bools(15743, 15743) --White Solomun Tee (Female)
            unlock_packed_bools(15748, 15748) --??? (Tattoo) (Female)
            unlock_packed_bools(15898, 15898) --Lucky 7s (Tattoo) (Female)
            unlock_packed_bools(15905, 15905) --Royals (Tattoo) (Female)
            unlock_packed_bools(28404, 28427) --Badlands Revenge II Retro Tee (Female), Badlands Revenge II Pixtro Tee (Female), Degenatron Glitch Tee (Female), Degenatron Logo Tee (Female), The Wizard's Ruin Rescue Tee (Female), The Wizard's Ruin Vow Tee (Female), Space Monkey Art Tee (Female), Crotch Rockets Tee (Female), Street Legal Tee (Female), Get Truckin' Tee (Female), Arcade Trophy Tee (Female), Videogeddon Tee (Female), Insert Coin Tee (Female), Plushie Princess Tee (Female), Plushie Wasabi Kitty Tee (Female), Plushie Master Tee (Female), Plushie Muffy Tee (Female), Plushie Humpy Tee (Female), Plushie Saki Tee (Female), Plushie Grindy Tee (Female), Plushie Poopie Tee (Female), Plushie Smoker Tee (Female), Shiny Wasabi Kitty Claw Tee (Female), Nazar Speaks Tee (Female),
            unlock_packed_bools(28458, 28462) --11 11 Tee (Female), King Of QUB3D Tee (Female), Qubism Tee (Female), God Of QUB3D Tee (Female), QUB3D Boxart Tee (Female),
            unlock_packed_bools(28463, 28478) --Channel X Aged Tee (Female), Rebel Radio Aged Tee (Female), LSUR Aged Tee (Female), Steel Horse Solid Logo Aged Tee (Female), Black Western Logo Aged Tee (Female), White Nagasaki Aged Tee (Female), Black Principe Aged Tee (Female), Albany Vintage Aged Tee (Female), Benefactor Aged Tee (Female), Bravado Aged Tee (Female), Declasse Aged Tee (Female), Dinka Aged Tee (Female), Grotti Aged Tee (Female), Lampadati Aged Tee (Female), Ocelot Aged Tee (Female), Overflod Aged Tee (Female)
            unlock_packed_bools(30418, 30421) --White Keinemusik Tee (Female), Blue Keinemusik Tee (Female), Moodymann Tee (Female), Palms Trax Tee (Female)
            unlock_packed_bools(30355, 30372) --Pegassi Aged Tee (Female), Pfister Aged Tee (Female), Vapid Aged Tee (Female), Weeny Aged Tee (Female), Toe Shoes Aged T-Shirt (Female), Vanilla Unicorn Aged T-Shirt (Female), Fake Vapid Aged T-Shirt (Female), I Married My Dad Aged T-Shirt (Female), White Rockstar Camo Aged Tee (Female), Razor Aged T-Shirt (Female), Noise Rockstar Logo Aged Tee (Female), Noise Aged Tee (Female), Emotion 98.3 Aged T-Shirt (Female), KDST Aged T-Shirt (Female), KJAH Radio Aged T-Shirt (Female), Bounce FM Aged T-Shirt (Female), K-Rose Aged T-Shirt (Female), Blue The Diamond Resort LS Aged Tee (Female)
            unlock_packed_bools(30429, 30433) --Faces of Death Tee (Female), Straight to Video Tee (Female), Monkey See Monkey Die Tee (Female), Trained to Kill Tee (Female), The Director Tee (Female)
            unlock_packed_bools(41285, 41296) --Monkey (Tattoo) (Female), Dragon (Tattoo) (Female), Snake (Tattoo) (Female), Goat (Tattoo) (Female), Rat (Tattoo) (Female), Rabbit (Tattoo) (Female), Ox (Tattoo) (Female), Pig (Tattoo) (Female), Rooster (Tattoo) (Female), Dog (Tattoo) (Female), Horse (Tattoo) (Female), Tiger (Tattoo) (Female)
        end
        stats.set_packed_stat_int(7315, 6) --WEAPON_STONE_HATCHET
        stats.set_packed_stat_int(18981, 4) --WEAPON_DOUBLEACTION
        stats.set_packed_stat_int(22050, 5) --Oppressor MK2 Trade Price
        stats.set_packed_stat_int(22051, 50) --Carved Wooden Box (Nightclub)
        stats.set_packed_stat_int(22052, 100) --Ammo Box
        stats.set_packed_stat_int(22053, 20) --Meth
        stats.set_packed_stat_int(22054, 80) --Weed
        stats.set_packed_stat_int(22055, 60) --Passports
        stats.set_packed_stat_int(22056, 40) --Crumpled Cash
        stats.set_packed_stat_int(22057, 10) --Impotent Rage Statue
        stats.set_packed_stat_int(22058, 20) --Gold Business Battle Trophy (Nightclub)
        stats.set_packed_stat_int(22063, 20) --Dinka Go Go Monkey Blista
        stats.set_packed_stat_int(41237, 10) --Taxi Livery
        stats.set_int('MPPLY_CREW_NO_HEISTS_0', 2)
        stats.set_int('MPPLY_CREW_NO_HEISTS_1', 5)
        stats.set_int('MPPLY_CREW_NO_HEISTS_2', 5)
        stats.set_int('MPPLY_CREW_NO_HEISTS_3', 5)
        stats.set_int('MPPLY_CREW_NO_HEISTS_4', 5)
        stats.set_int('MPPLY_GANGOPS_LOYALTY2', -1)
        stats.set_int('MPPLY_GANGOPS_LOYALTY3', -1)
        stats.set_int('MPPLY_GANGOPS_CRIMMASMD2', -1)
        stats.set_int('MPPLY_GANGOPS_CRIMMASMD3', -1)
        stats.set_int('MPPLY_GANGOPS_SUPPORT', -1)
        stats.set_int('MPPLY_GANGOPS_ALLINORDER', -1)
        stats.set_int('MPPLY_GANGOPS_LOYALTY', -1)
        stats.set_int('MPPLY_GANGOPS_CRIMMASMD', -1)
        stats.set_int('MPPLY_XMASLIVERIES0', -1)
        stats.set_int('MPPLY_XMASLIVERIES1', -1)
        stats.set_int('MPPLY_XMASLIVERIES2', -1)
        stats.set_int('MPPLY_XMASLIVERIES3', -1)
        stats.set_int('MPPLY_XMASLIVERIES4', -1)
        stats.set_int('MPPLY_XMASLIVERIES5', -1)
        stats.set_int('MPPLY_XMASLIVERIES6', -1)
        stats.set_int('MPPLY_XMASLIVERIES7', -1)
        stats.set_int('MPPLY_XMASLIVERIES8', -1)
        stats.set_int('MPPLY_XMASLIVERIES9', -1)
        stats.set_int('MPPLY_XMASLIVERIES10', -1)
        stats.set_int('MPPLY_XMASLIVERIES11', -1)
        stats.set_int('MPPLY_XMASLIVERIES12', -1)
        stats.set_int('MPPLY_XMASLIVERIES13', -1)
        stats.set_int('MPPLY_XMASLIVERIES14', -1)
        stats.set_int('MPPLY_XMASLIVERIES15', -1)
        stats.set_int('MPPLY_XMASLIVERIES16', -1)
        stats.set_int('MPPLY_XMASLIVERIES17', -1)
        stats.set_int('MPPLY_XMASLIVERIES18', -1)
        stats.set_int('MPPLY_XMASLIVERIES19', -1)
        stats.set_int('MPPLY_XMASLIVERIES20', -1)
        stats.set_int('MPX_HOLDUPS_BITSET', -1)
        stats.set_int('MPX_CHAR_ABILITY_1_UNLCK', -1)
        stats.set_int('MPX_CHAR_ABILITY_2_UNLCK', -1)
        stats.set_int('MPX_CHAR_ABILITY_3_UNLCK', -1)
        stats.set_int('MPX_CHAR_WEAP_UNLOCKED', -1)
        stats.set_int('MPX_CHAR_WEAP_UNLOCKED2', -1)
        stats.set_int('MPX_CHAR_WEAP_ADDON_1_UNLCK', -1)
        stats.set_int('MPX_CHAR_WEAP_ADDON_2_UNLCK', -1)
        stats.set_int('MPX_CHAR_WEAP_ADDON_3_UNLCK', -1)
        stats.set_int('MPX_CHAR_WEAP_ADDON_4_UNLCK', -1)
        stats.set_int('MPX_CHAR_FM_WEAP_UNLOCKED', -1)
        stats.set_int('MPX_CHAR_FM_WEAP_UNLOCKED2', -1)
        stats.set_int('MPX_CHAR_FM_WEAP_UNLOCKED3', -1)
        stats.set_int('MPX_CHAR_FM_WEAP_UNLOCKED4', -1)
        stats.set_int('MPX_CHAR_FM_WEAP_UNLOCKED5', -1)
        stats.set_int('MPX_CHAR_FM_WEAP_ADDON_1_UNLCK', -1)
        stats.set_int('MPX_CHAR_FM_WEAP_ADDON_2_UNLCK', -1)
        stats.set_int('MPX_CHAR_FM_WEAP_ADDON_3_UNLCK', -1)
        stats.set_int('MPX_CHAR_FM_WEAP_ADDON_4_UNLCK', -1)
        stats.set_int('MPX_CHAR_FM_WEAP_ADDON_5_UNLCK', -1)
        stats.set_int('MPX_CHAR_FM_WEAP_ADDON_6_UNLCK', -1)
        stats.set_int('MPX_CHAR_FM_WEAP_ADDON_7_UNLCK', -1)
        stats.set_int('MPX_CHAR_FM_WEAP_ADDON_8_UNLCK', -1)
        stats.set_int('MPX_CHAR_FM_WEAP_ADDON_9_UNLCK', -1)
        stats.set_int('MPX_CHAR_FM_WEAP_ADDON_10_UNLCK', -1)
        stats.set_int('MPX_CHAR_FM_WEAP_ADDON_11_UNLCK', -1)
        stats.set_int('MPX_CHAR_FM_WEAP_ADDON_12_UNLCK', -1)
        stats.set_int('MPX_CHAR_FM_WEAP_ADDON_13_UNLCK', -1)
        stats.set_int('MPX_CHAR_FM_WEAP_ADDON_14_UNLCK', -1)
        stats.set_int('MPX_CHAR_FM_WEAP_ADDON_15_UNLCK', -1)
        stats.set_int('MPX_CHAR_FM_WEAP_ADDON_16_UNLCK', -1)
        stats.set_int('MPX_CHAR_FM_WEAP_ADDON_17_UNLCK', -1)
        stats.set_int('MPX_CHAR_FM_WEAP_ADDON_18_UNLCK', -1)
        stats.set_int('MPX_CHAR_FM_WEAP_ADDON_19_UNLCK', -1)
        stats.set_int('MPX_CHAR_FM_WEAP_ADDON_20_UNLCK', -1)
        stats.set_int('MPX_CHAR_FM_HAIRCUT_1_UNLCK', -1)
        stats.set_int('MPX_CHAR_HAIR_UNLCK1', -1)
        stats.set_int('MPX_CHAR_HAIR_UNLCK2', -1)
        stats.set_int('MPX_CHAR_HAIR_UNLCK3', -1)
        stats.set_int('MPX_CHAR_HAIR_UNLCK4', -1)
        stats.set_int('MPX_CHAR_HAIR_UNLCK5', -1)
        stats.set_int('MPX_CHAR_HAIR_UNLCK6', -1)
        stats.set_int('MPX_CHAR_HAIR_UNLCK7', -1)
        stats.set_int('MPX_CHAR_HAIR_UNLCK8', -1)
        stats.set_int('MPX_CHAR_HAIR_UNLCK9', -1)
        stats.set_int('MPX_CHAR_HAIR_UNLCK10', -1)
        stats.set_int('MPX_CHAR_HAIR_UNLCK11', -1)
        stats.set_int('MPX_CHAR_HAIR_UNLCK12', -1)
        stats.set_int('MPX_CHAR_HAIR_UNLCK13', -1)
        stats.set_int('MPX_CHAR_HAIR_UNLCK14', -1)
        stats.set_int('MPX_CHAR_HAIR_UNLCK15', -1)
        stats.set_int('MPX_CHAR_HAIR_UNLCK16', -1)
        stats.set_int('MPX_CHAR_HAIR_UNLCK17', -1)
        stats.set_int('MPX_CHAR_FM_HEALTH_1_UNLCK', -1)
        stats.set_int('MPX_CHAR_FM_HEALTH_2_UNLCK', -1)
        stats.set_int('MPX_CRDEADLINE', 5)
        stats.set_int('MPX_CHAR_CREWUNLOCK_1_FM_EQUIP', -1)
        stats.set_int('MPX_CHAR_CREWUNLOCK_2_FM_EQUIP', -1)
        stats.set_int('MPX_CHAR_CREWUNLOCK_3_FM_EQUIP', -1)
        stats.set_int('MPX_CHAR_CREWUNLOCK_4_FM_EQUIP', -1)
        stats.set_int('MPX_CHAR_CREWUNLOCK_5_FM_EQUIP', -1)
        stats.set_int('MPX_CHAR_KIT_1_FM_UNLCK', -1)
        stats.set_int('MPX_CHAR_KIT_2_FM_UNLCK', -1)
        stats.set_int('MPX_CHAR_KIT_3_FM_UNLCK', -1)
        stats.set_int('MPX_CHAR_KIT_4_FM_UNLCK', -1)
        stats.set_int('MPX_CHAR_KIT_5_FM_UNLCK', -1)
        stats.set_int('MPX_CHAR_KIT_6_FM_UNLCK', -1)
        stats.set_int('MPX_CHAR_KIT_7_FM_UNLCK', -1)
        stats.set_int('MPX_CHAR_KIT_8_FM_UNLCK', -1)
        stats.set_int('MPX_CHAR_KIT_9_FM_UNLCK', -1)
        stats.set_int('MPX_CHAR_KIT_10_FM_UNLCK', -1)
        stats.set_int('MPX_CHAR_KIT_11_FM_UNLCK', -1)
        stats.set_int('MPX_CHAR_KIT_12_FM_UNLCK', -1)
        stats.set_int('MPX_CHAR_KIT_13_FM_UNLCK', -1)
        stats.set_int('MPX_CHAR_KIT_14_FM_UNLCK', -1)
        stats.set_int('MPX_CHAR_KIT_15_FM_UNLCK', -1)
        stats.set_int('MPX_CHAR_KIT_16_FM_UNLCK', -1)
        stats.set_int('MPX_CHAR_KIT_17_FM_UNLCK', -1)
        stats.set_int('MPX_CHAR_KIT_18_FM_UNLCK', -1)
        stats.set_int('MPX_CHAR_KIT_19_FM_UNLCK', -1)
        stats.set_int('MPX_CHAR_KIT_20_FM_UNLCK', -1)
        stats.set_int('MPX_CHAR_KIT_21_FM_UNLCK', -1)
        stats.set_int('MPX_CHAR_KIT_22_FM_UNLCK', -1)
        stats.set_int('MPX_CHAR_KIT_23_FM_UNLCK', -1)
        stats.set_int('MPX_CHAR_KIT_24_FM_UNLCK', -1)
        stats.set_int('MPX_CHAR_KIT_25_FM_UNLCK', -1)
        stats.set_int('MPX_CHAR_KIT_26_FM_UNLCK', -1)
        stats.set_int('MPX_CHAR_KIT_27_FM_UNLCK', -1)
        stats.set_int('MPX_CHAR_KIT_28_FM_UNLCK', -1)
        stats.set_int('MPX_CHAR_KIT_29_FM_UNLCK', -1)
        stats.set_int('MPX_CHAR_KIT_30_FM_UNLCK', -1)
        stats.set_int('MPX_CHAR_KIT_30_FM_UNLCK', -1)
        stats.set_int('MPX_CHAR_KIT_31_FM_UNLCK', -1)
        stats.set_int('MPX_CHAR_KIT_32_FM_UNLCK', -1)
        stats.set_int('MPX_CHAR_KIT_33_FM_UNLCK', -1)
        stats.set_int('MPX_CHAR_KIT_34_FM_UNLCK', -1)
        stats.set_int('MPX_CHAR_KIT_35_FM_UNLCK', -1)
        stats.set_int('MPX_CHAR_KIT_36_FM_UNLCK', -1)
        stats.set_int('MPX_CHAR_KIT_37_FM_UNLCK', -1)
        stats.set_int('MPX_CHAR_KIT_38_FM_UNLCK', -1)
        stats.set_int('MPX_CHAR_KIT_39_FM_UNLCK', -1)
        stats.set_int('MPX_CHAR_KIT_40_FM_UNLCK', -1)
        stats.set_int('MPX_CHAR_KIT_41_FM_UNLCK', -1)
        stats.set_int('MPX_CHAR_FM_ABILITY_1_UNLCK', -1)
        stats.set_int('MPX_CHAR_FM_ABILITY_2_UNLCK', -1)
        stats.set_int('MPX_CHAR_FM_ABILITY_3_UNLCK', -1)
        stats.set_int('MPX_CHAR_FM_CLOTHES_1_UNLCK', -1)
        stats.set_int('MPX_CHAR_FM_CLOTHES_2_UNLCK', -1)
        stats.set_int('MPX_CHAR_FM_CLOTHES_3_UNLCK', -1)
        stats.set_int('MPX_CHAR_FM_CLOTHES_4_UNLCK', -1)
        stats.set_int('MPX_CHAR_FM_CLOTHES_5_UNLCK', -1)
        stats.set_int('MPX_CHAR_FM_CLOTHES_6_UNLCK', -1)
        stats.set_int('MPX_CHAR_FM_CLOTHES_7_UNLCK', -1)
        stats.set_int('MPX_CHAR_FM_CLOTHES_8_UNLCK', -1)
        stats.set_int('MPX_CHAR_FM_CLOTHES_9_UNLCK', -1)
        stats.set_int('MPX_CHAR_FM_CLOTHES_10_UNLCK', -1)
        stats.set_int('MPX_CHAR_FM_CLOTHES_11_UNLCK', -1)
        stats.set_int('MPX_CHAR_FM_VEHICLE_1_UNLCK', -1)
        stats.set_int('MPX_CHAR_FM_VEHICLE_2_UNLCK', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_0', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_1', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_2', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_3', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_4', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_5', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_6', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_7', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_8', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_9', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_10', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_11', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_12', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_13', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_14', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_15', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_16', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_17', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_18', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_19', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_20', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_21', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_22', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_23', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_24', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_25', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_26', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_27', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_28', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_29', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_30', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_31', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_32', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_33', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_34', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_35', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_36', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_37', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_38', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_39', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_40', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_41', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_42', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_43', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_44', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_45', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_46', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_47', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_48', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_49', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_50', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_51', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_52', -1)
        stats.set_int('MPX_TATTOO_FM_UNLOCKS_53', -1)
        stats.set_int('MPX_RANKAP_UNLK_0', -1)
        stats.set_int('MPX_RANKAP_UNLK_1', -1)
        stats.set_int('MPX_RANKAP_UNLK_2', -1)
        stats.set_int('MPX_RANKAP_UNLK_3', -1)
        stats.set_int('MPX_CHAR_CREWUNLOCK_1_UNLCK', -1)
        stats.set_int('MPX_SR_WEAPON_BIT_SET', -1)
        stats.set_int('MPX_CAR_CLUB_REP', 997430)
        stats.set_bool('MPX_SR_TIER_1_REWARD', true)
        stats.set_bool('MPX_SR_INCREASE_THROW_CAP', true)
        stats.set_bool('MPX_SR_TIER_3_REWARD', true)
        stats.set_bool('MPPLY_MELEECHLENGECOMPLETED', true)
        stats.set_bool('MPPLY_HEADSHOTCHLENGECOMPLETED', true)
        stats.set_int('MPX_CHAR_HEIST_1_UNLCK', -1)
        stats.set_int('MPX_CHAR_FM_VEHICLE_1_UNLCK', -1)
        stats.set_int('MPX_CHAR_FM_VEHICLE_2_UNLCK', -1)
        stats.set_int('MPX_CRHEIST', 50)
        stats.set_int('MPX_CR_BANKHEIST1', 10)
        stats.set_int('MPX_CR_COUNTHEIST1', 10)
        stats.set_int('MPX_HEIST_COMPLETION', 26)
        stats.set_int('MPX_HEIST_TOTAL_TIME', 86400000)
        stats.set_int('MPX_HEISTS_ORGANISED', 50)
        stats.set_int('MPX_RACES_WON', 50)
        stats.set_int('MPX_CHAR_FM_PACKAGE_1_COLLECT', -1)
        stats.set_int('MPX_CHAR_FM_PACKAGE_2_COLLECT', -1)
        stats.set_int('MPX_CHAR_FM_PACKAGE_3_COLLECT', -1)
        stats.set_int('MPX_CHAR_FM_PACKAGE_4_COLLECT', -1)
        stats.set_int('MPX_CHAR_FM_PACKAGE_5_COLLECT', -1)
        stats.set_int('MPX_CHAR_FM_PACKAGE_6_COLLECT', -1)
        stats.set_int('MPX_CHAR_FM_PACKAGE_7_COLLECT', -1)
        stats.set_int('MPX_CHAR_FM_PACKAGE_8_COLLECT', -1)
        stats.set_int('MPX_CHAR_NO_FM_PACKAGES_COL', -1)
        stats.set_int('MPX_CHAR_FM_CARMOD_1_UNLCK', -1)
        stats.set_int('MPX_CHAR_FM_CARMOD_2_UNLCK', -1)
        stats.set_int('MPX_CHAR_FM_CARMOD_3_UNLCK', -1)
        stats.set_int('MPX_CHAR_FM_CARMOD_4_UNLCK', -1)
        stats.set_int('MPX_CHAR_FM_CARMOD_5_UNLCK', -1)
        stats.set_int('MPX_CHAR_FM_CARMOD_6_UNLCK', -1)
        stats.set_int('MPX_CHAR_FM_CARMOD_7_UNLCK', -1)
        stats.set_int('MPX_NUMBER_SLIPSTREAMS_IN_RACE', 110)
        stats.set_int('MPX_NUMBER_TURBO_STARTS_IN_RACE', 90)
        stats.set_int('MPX_USJS_FOUND', 50)
        stats.set_int('MPX_USJS_COMPLETED', 50)
        stats.set_int('MPX_MPPLY_TIMES_RACE_BEST_LAP', 101)
        stats.set_int('MPX_AWD_FMRALLYWONDRIVE', 25)
        stats.set_int('MPX_AWD_FMWINSEARACE', 25)
        stats.set_int('MPX_AWD_FMWINAIRRACE', 25)
        stats.set_int('MPX_AWD_FM_RACES_FASTEST_LAP', 101)
        stats.set_int('MPX_SCRIPT_INCREASE_STAM', 100)
        stats.set_int('MPX_SCRIPT_INCREASE_STRN', 100)
        stats.set_int('MPX_SCRIPT_INCREASE_FLY', 100)
        stats.set_int('MPX_SCRIPT_INCREASE_STL', 100)
        stats.set_int('MPX_SCRIPT_INCREASE_LUNG', 100)
        stats.set_int('MPX_SCRIPT_INCREASE_DRIV', 100)
        stats.set_int('MPX_SCRIPT_INCREASE_SHO', 100)
        stats.set_int('MPX_AWD_DANCE_TO_SOLOMUN', 360)
        stats.set_int('NIGHTCLUB_HOTSPOT_TIME_MS', 3600000)
        stats.set_int('MPX_CASINO_DECORATION_GIFT_1', -1);
        stats.set_bool('MPX_COMPLETE_H4_F_USING_VETIR', true);
        stats.set_bool('MPX_COMPLETE_H4_F_USING_LONGFIN', true);
        stats.set_bool('MPX_COMPLETE_H4_F_USING_ANNIH', true);
        stats.set_bool('MPX_COMPLETE_H4_F_USING_ALKONOS', true);
        stats.set_bool('MPX_COMPLETE_H4_F_USING_PATROLB', true);
        stats.set_bool('MPX_AWD_DEADEYE', true) -- Badlands Revenge II -- Dead Eye
        stats.set_bool('MPX_AWD_PISTOLSATDAWN', true) -- Badlands Revenge II -- Pistols At Dawn
        stats.set_bool('MPX_AWD_TRAFFICAVOI', true) -- Race and Chase -- Beat the Traffic
        stats.set_bool('MPX_AWD_CANTCATCHBRA', true) -- Race and Chase -- All Wheels
        stats.set_bool('MPX_AWD_WIZHARD', true) -- The Wizard's Ruin -- Feelin' Grogy
        stats.set_bool('MPX_AWD_APEESCAPE', true) -- Space Monkey 3: Bananas Gone Bad -- Ape Escape
        stats.set_bool('MPX_AWD_MONKEYKIND', true) -- Space Monkey 3: Bananas Gone Bad -- Monkey Mind
        stats.set_bool('MPX_AWD_AQUAAPE', true) -- Monkey Paradise -- Aquatic Ape
        stats.set_bool('MPX_AWD_KEEPFAITH', true) -- Defender of the Faith -- Keeping The Faith
        stats.set_bool('MPX_AWD_TRUELOVE', true) -- The Love Professor -- True Love
        stats.set_bool('MPX_AWD_NEMESIS', true) -- The Love Professor -- Nemesis
        stats.set_bool('MPX_AWD_FRIENDZONED', true) -- The Love Professor -- Friendzoned
        stats.set_bool('MPX_SCGW_WON_NO_DEATHS', true) -- Street Crimes: Gang Wars Edition -- Win a game without taking any damage
        stats.set_bool('MPX_IAP_CHALLENGE_0', true) -- Invade and Persuade II -- Score over 2,000,000 in a single playthrough
        stats.set_bool('MPX_IAP_CHALLENGE_1', true) -- Invade and Persuade II -- Collect 88 barrels in a single playthrough
        stats.set_bool('MPX_IAP_CHALLENGE_2', true) -- Invade and Persuade II -- Kill 100 animals in a single playthrough
        stats.set_bool('MPX_IAP_CHALLENGE_3', true) -- Invade and Persuade II -- Travel 3,474,000km on the moon
        stats.set_bool('MPX_IAP_CHALLENGE_4', true) -- Invade and Persuade II -- Finish any level of Invade and persuade with over 7 livee
        stats.set_bool('MPX_AWD_KINGOFQUB3D', true) -- QUB3D -- King Of QUB3D
        stats.set_bool('MPX_AWD_QUBISM', true) -- QUB3D -- Qubism
        stats.set_bool('MPX_AWD_GODOFQUB3D', true) -- QUB3D -- God Of QUB3D
        stats.set_bool('MPX_AWD_QUIBITS', true) -- QUB3D -- Qubits
        stats.set_bool('MPX_AWD_ELEVENELEVEN', true) -- Axe Of Fury -- 11 11
        stats.set_bool('MPX_AWD_GOFOR11TH', true) -- Axe Of Fury -- Crank It To 11
        stats.set_bool('MPX_AWD_STRAIGHT_TO_VIDEO', true) -- Camhedz -- Straight To Video
        stats.set_bool('MPX_AWD_MONKEY_C_MONKEY_DO', true) -- Camhedz -- Monkey See Monkey Do
        stats.set_bool('MPX_AWD_TRAINED_TO_KILL', true) -- Camhedz -- Trained to Kill
        stats.set_bool('MPX_AWD_DIRECTOR', true) -- Camhedz -- The Director
        stats.set_int('MPX_AWD_SHARPSHOOTER', 40) -- Badlands Revenge II -- Sharpshooter
        stats.set_int('MPX_AWD_RACECHAMP', 40) -- Race and Chase -- Race Champion
        stats.set_int('MPX_AWD_BATSWORD', 1000000) -- The Wizard's Ruin -- Platinum Sword
        stats.set_int('MPX_AWD_COINPURSE', 950000) -- The Wizard's Ruin -- Platinum Sword -- Coin Purse
        stats.set_int('MPX_AWD_ASTROCHIMP', 3000000) -- Space Monkey 3: Bananas Gone Bad -- Astrochimp
        stats.set_int('MPX_AWD_MASTERFUL', 40000) -- Penetrator -- Masterful
        stats.set_int('MPX_SCGW_NUM_WINS_GANG_0', 55) -- Street Crimes: Gang Wars Edition -- Win 20 games with character 1
        stats.set_int('MPX_SCGW_NUM_WINS_GANG_1', 56) -- Street Crimes: Gang Wars Edition -- Win 20 games with character 2
        stats.set_int('MPX_SCGW_NUM_WINS_GANG_2', 57) -- Street Crimes: Gang Wars Edition -- Win 20 games with character 3
        stats.set_int('MPX_SCGW_NUM_WINS_GANG_3', 58) -- Street Crimes: Gang Wars Edition -- Win 20 games with character 4
        stats.set_int('MPX_IAP_MAX_MOON_DIST', 2147483647) -- Invade and Persuade II -- Travel 3,474,000km on the moon
        stats.set_int('MPX_LAST_ANIMAL', 108) -- Invade and Persuade II -- Kill 100 animals in a single playthrough
        stats.set_int('MPX_CH_ARC_CAB_CLAW_TROPHY', -1) -- Kitty Claw Trophy
        stats.set_int('MPX_CH_ARC_CAB_LOVE_TROPHY', -1) -- The Love Professor Trophy
        stats.set_int('MPX_AWD_FACES_OF_DEATH', 50) -- Camhedz -- Faces Of Death
        stats.set_int('MPX_REV_NV_KILLS', 50) -- Navy Revolver Kills
        stats.set_int("MPX_XM22_FLOW", -1) -- Acid Lab Unlock
        stats.set_int("MPX_XM22_MISSIONS", -1) -- Acid Lab Unlock
        stats.set_int("MPX_PET_CHOP_TIME", NETWORK.GET_CLOUD_TIME_AS_INT() - 86400) -- Pet Chop Time?
        stats.set_bool("MPX_AWD_DOGS_BEST_FRIEND", true) -- Pet Chop Time?
        stats.set_int("MPX_AWD_CALLME", tunables.get_int(654710993)) -- Acid Lab Equipment Unlock
        stats.set_int("MPX_H3_VEHICLESUSED", -1) -- Trade Price for Diamond Casino Heist Finale.
        stats.set_int("MPX_H4_H4_DJ_MISSIONS", -1) -- Trade Price for MP0_H4_H4_DJ_MISSIONS
        stats.set_int("MPX_H4_PROGRESS", -1) -- Trade Price for winky
        stats.set_int("MPX_TUNER_GEN_BS", -1) -- Trade Price for tailgater2
        stats.set_int("MPX_FIXER_HQ_OWNED", 1) -- Trade Price for buffalo4
        stats.set_int("MPX_ULP_MISSION_PROGRESS", -1) -- Trade Price greenwood/conada
        stats.set_int("MPX_SUM23_AVOP_PROGRESS", -1) -- Trade Price Raiju
        stats.set_int("MPX_GANGOPS_FLOW_BITSET_MISS0", -1) -- Trade Price for deluxo/akula/riot2/stromberg/chernobog/barrage/khanjali/volatol/thruster
        stats.set_bool("MPX_AWD_TAXISTAR", true) -- Trade Price for taxi
        stats.set_bool("MPPLY_AWD_HST_ORDER", true)
        stats.set_bool("MPPLY_AWD_HST_SAME_TEAM", true)
        stats.set_bool("MPPLY_AWD_HST_ULT_CHAL", true)
        stats.set_int("MPPLY_HEISTFLOWORDERPROGRESS", -1)
        stats.set_int("MPPLY_HEISTNODEATHPROGREITSET", -1)
        stats.set_int("MPPLY_HEISTTEAMPROGRESSBITSET", -1)
        stats.set_int("MPX_AT_FLOW_VEHICLE_BS", -1) -- Trade price for dune4/dune5/wastelander/blazer5/phantom2/voltic2/technical2/boxville5/ruiner2
        stats.set_int("MPX_LFETIME_HANGAR_BUY_COMPLET", 50) -- Trade price for microlight/rogue/alphaz1/havok/starling/molotok/tula/bombushka/howard/mogul/pyro/seabreeze/nokota/hunter
        stats.set_int("MPX_SALV23_GEN_BS", -1) -- police4 trade price
        stats.set_int("MPX_SALV23_INST_PROG", -1) -- polgauntlet trade price
        stats.set_int("MPX_SALV23_SCOPE_BS", -1) -- police5 trade price
        stats.set_int("MPX_MOST_TIME_ON_3_PLUS_STARS", 300000) -- police4 trade price
        stats.set_int("MPX_LOWRIDER_FLOW_COMPLETE", 1)
        stats.set_int("MPX_AT_FLOW_MISSION_PROGRESS", 50)
        stats.set_int("MPX_AT_FLOW_IMPEXP_NUM", 50)
        stats.set_int("MPX_AT_FLOW_BITSET_MISSIONS0", -1)
        stats.set_int("MPX_WVM_FLOW_MISSION_PROGRESS", 50)
        stats.set_int("MPX_WVM_FLOW_IMPEXP_NUM", 50)
        stats.set_int("MPX_WVM_FLOW_BITSET_MISSIONS0", -1)
        stats.set_int("MPX_WVM_FLOW_VEHICLE_BS", -1)
        stats.set_int("MPX_GANGOPS_FLOW_MISSION_PROG", -1)
        stats.set_int("MPX_GANGOPS_FLOW_IMPEXP_NUM", 50)
        stats.set_int("MPX_WAM_FLOW_VEHICLE_BS", -1)
        stats.set_int("MPX_GANGOPS_FLOW_PASSED_BITSET", -1)
        stats.set_int("MPX_VCM_FLOW_PROGRESS", -1)
        stats.set_int("MPX_TUNER_FLOW_BS", -1)
        stats.set_int("MPX_TUNER_MIS_BS", -1)
        stats.set_int("MPX_TUNER_COMP_BS", -1)
        stats.set_int("MPX_GANGOPS_FM_MISSION_PROG", -1)
        stats.set_int("MPX_GANGOPS_FM_BITSET_MISS0", -1)
        stats.set_bool("MPX_UNLOCKED_MESSAGE_FLEECA", true)
        stats.set_bool("MPX_CARMEET_PV_CHLLGE_CMPLT", true)
        --Make it think you've beat all the heists as leader.
        stats.set_int("MPX_HEIST_SAVED_STRAND_0", tunables.get_int('ROOT_ID_HASH_THE_FLECCA_JOB'))
        stats.set_int("MPX_HEIST_SAVED_STRAND_0_L", 5)
        stats.set_int("MPX_HEIST_SAVED_STRAND_1", tunables.get_int('ROOT_ID_HASH_THE_PRISON_BREAK'))
        stats.set_int("MPX_HEIST_SAVED_STRAND_1_L", 5)
        stats.set_int("MPX_HEIST_SAVED_STRAND_2", tunables.get_int('ROOT_ID_HASH_THE_HUMANE_LABS_RAID'))
        stats.set_int("MPX_HEIST_SAVED_STRAND_2_L", 5)
        stats.set_int("MPX_HEIST_SAVED_STRAND_3", tunables.get_int('ROOT_ID_HASH_SERIES_A_FUNDING'))
        stats.set_int("MPX_HEIST_SAVED_STRAND_3_L", 5)
        stats.set_int("MPX_HEIST_SAVED_STRAND_4", tunables.get_int('ROOT_ID_HASH_THE_PACIFIC_STANDARD_JOB'))
        stats.set_int("MPX_HEIST_SAVED_STRAND_4_L", 5)
        stats.set_int("MPX_LIFETIME_BUY_COMPLETE", 1025)
        stats.set_int("MPX_LIFETIME_BUY_UNDERTAKEN", 1025)
        stats.set_int("MPX_LIFETIME_SELL_COMPLETE", 1025)
        stats.set_int("MPX_LIFETIME_SELL_UNDERTAKEN", 1025)
        stats.set_int("MPX_LIFETIME_CONTRA_EARNINGS", 25000000) --Contraband Earnings
        stats.set_int("MPX_LFETIME_BIKER_BUY_COMPLET", 1025)
        stats.set_int("MPX_LFETIME_BIKER_BUY_UNDERTA", 1025)
        stats.set_int("MPX_LFETIME_BIKER_SELL_COMPLET", 1025)
        stats.set_int("MPX_LFETIME_BIKER_SELL_UNDERTA", 1025)
        stats.set_int("MPX_LFETIME_BIKER_BUY_COMPLET1", 1025)
        stats.set_int("MPX_LFETIME_BIKER_BUY_UNDERTA1", 1025)
        stats.set_int("MPX_LFETIME_BIKER_SELL_COMPLET1", 1025)
        stats.set_int("MPX_LFETIME_BIKER_SELL_UNDERTA1", 1025)
        stats.set_int("MPX_LFETIME_BIKER_BUY_COMPLET2", 1025)
        stats.set_int("MPX_LFETIME_BIKER_BUY_UNDERTA2", 1025)
        stats.set_int("MPX_LFETIME_BIKER_SELL_COMPLET2", 1025)
        stats.set_int("MPX_LFETIME_BIKER_SELL_UNDERTA2", 1025)
        stats.set_int("MPX_LFETIME_BIKER_BUY_COMPLET3", 1025)
        stats.set_int("MPX_LFETIME_BIKER_BUY_UNDERTA3", 1025)
        stats.set_int("MPX_LFETIME_BIKER_SELL_COMPLET3", 1025)
        stats.set_int("MPX_LFETIME_BIKER_SELL_UNDERTA3", 1025)
        stats.set_int("MPX_LFETIME_BIKER_BUY_COMPLET4", 1025)
        stats.set_int("MPX_LFETIME_BIKER_BUY_UNDERTA4", 1025)
        stats.set_int("MPX_LFETIME_BIKER_SELL_COMPLET4", 1025)
        stats.set_int("MPX_LFETIME_BIKER_SELL_UNDERTA4", 1025)
        stats.set_int("MPX_LFETIME_BIKER_BUY_COMPLET5", 1025)
        stats.set_int("MPX_LFETIME_BIKER_BUY_UNDERTA5", 1025)
        stats.set_int("MPX_LFETIME_BIKER_SELL_COMPLET5", 1025)
        stats.set_int("MPX_LFETIME_BIKER_SELL_UNDERTA5", 1025)
        stats.set_int("MPX_LIFETIME_BKR_SELL_EARNINGS0", 25000000)
        stats.set_int("MPX_LIFETIME_BKR_SELL_EARNINGS1", 25000000)
        stats.set_int("MPX_LIFETIME_BKR_SELL_EARNINGS2", 25000000)
        stats.set_int("MPX_LIFETIME_BKR_SELL_EARNINGS3", 25000000)
        stats.set_int("MPX_LIFETIME_BKR_SELL_EARNINGS4", 25000000)
        stats.set_int("MPX_LFETIME_BIKER_BUY_COMPLET6", 10) --Allow buying of Stank Breath acid name.
        stats.set_int("MPX_LFETIME_BIKER_SELL_COMPLET6", 10) --Allow buying of Squatch Bait acid  name.
        stats.set_packed_stat_int(41241, 5) --Allow buying of Chair Shot acid name.
        stats.set_int("MPX_LIFETIME_BKR_SELL_EARNINGS6", 1000000) --Allow buying of Fck Your Sleep acid name.
        stats.set_packed_stat_int(7666, 25) --Fill CEO office with money
        unlock_packed_bools(7553, 7594) --Fill CEO office with junk
        stats.set_packed_stat_int(9357, 4) --Fill Clubhouse with money
        unlock_packed_bools(9400, 9414) --Fill Clubhouse with junk
        stats.set_int("MPX_XMAS2023_ADV_MODE_WINS", 6) --Unlock Christmas 2023 liveries.
        stats.set_int("MPX_FIXER_GENERAL_BS", -8577) -- Trade price for champion/baller7
        stats.set_int("MPX_FIXER_COMPLETED_BS", -1) -- Compelete all The Contract missions.
        stats.set_int("MPX_FIXER_COUNT", 20) -- Trade price for granger2/deity/patriot3/jubilee
        stats.set_int("MPPLY_XMAS23_PLATES0", 3) -- ECola & Sprunk Plates
        stats.set_int("MPX_COUNT_HOTRING_RACE", 20) -- Liveries for hotring
        stats.set_int("MPX_FINISHED_SASS_RACE_TOP_3", 20) -- Trade price for hotring/everon2
        for i = 0, 2 do --Unlock all daily rewards.
            local objective = globals.get_int(current_objectives_global + (1 + (0 * 5569)) + 681 + 4243 + (1 + (i * 3)))
            globals.set_int(objectives_state_global + 1 + (1 + (i * 1)), objective)
        end
        globals.set_int(objectives_state_global, 1)
        globals.set_int(weekly_words_global + (1 + (0 * 6)) + 1, globals.get_int(weekly_words_global + (1 + (0 * 6)) + 2)) --Unlock Weekly Objective
        gui.show_message('Wasabi Words TM', '解锁一切!')
    end)
end)
toolTip(Stats, "解锁游戏中的所有内容, 功能由ShinyWasabi制作")

-- Autorun Drops
local Money = KAOS:add_tab("金钱选项.")
--local Drops = Money:add_tab("Drops")


--Drops:add_separator()
--Drops:add_text("You CAN run multiple at once (like Robot bubblegum/Alien)")
--Drops:add_text("Select a Player from the list and toggle");

-- Teleports tab - Credits to USBMenus https://github.com/Deadlineem/Extras-Addon-for-YimMenu/issues/9#issuecomment-1955881222

local Tel = Pla:add_tab("传送")

-- Define your array with names and IDs
local properties = {
    {name = "藏身处", id = 40}, {name = "办公室", id = 475}, {name = "竞技场", id = 643}, {name = "地堡", id = 557}, {name = "游戏厅", id = 740},
    {name = "汽车修理店", id = 779}, {name = "机构", id = 826}, {name = "俱乐部会所", id = 492}, {name = "飞机库", id = 569}, {name = "设施", id = 590},
    {name = "夜总会", id = 614}, {name = "怪胎店", id = 847}, {name = "废品回收场", id = 867}, {name = "日食车库", id = 856}, {name = "游艇", id = 455},
    {name = "科萨特卡", id = 760},
    -- Add more properties as needed
    -- Cayo Drainage = 768
    --"Safehouse"（藏身处），ID为40
    --"Office"（办公室），ID为475
    --"Arena"（竞技场），ID为643
    --"Bunker"（地堡），ID为557
    --"Arcade"（游戏厅），ID为740
    --"Auto Shop"（汽车修理店），ID为779
    --"Agency"（机构），ID为826
    --"Clubhouse"（俱乐部会所），ID为492
    --"Hangar"（飞机库），ID为569
    --"Facility"（设施），ID为590
    --"Night Club"（夜总会），ID为614
    --"Freakshop"（怪诞商店），ID为847
    --"Salvage Yard"（废品回收场），ID为867
    --"Eclipse Garage"（日食车库），ID为856
    --"Yacht"（游艇），ID为455
    --"Kosatka"（科萨特卡），ID为760
}


local function findNearestBlip(propertyId)
    local ped = PLAYER.PLAYER_PED_ID()
    local minDistanceSquared = math.huge
    local nearestBlipId = nil
    local iterator = propertyId
    local blipId = HUD.GET_FIRST_BLIP_INFO_ID(iterator)
    while blipId ~= 0 do
        local blipCoords = HUD.GET_BLIP_COORDS(blipId)
        local distanceSquared = MISC.GET_DISTANCE_BETWEEN_COORDS(ped, blipCoords.x, blipCoords.y, blipCoords.z, 1, 0, false)
        if distanceSquared < minDistanceSquared and blipId ~= propertyId then
            minDistanceSquared = distanceSquared
            nearestBlipId = blipId
        end
        blipId = HUD.GET_NEXT_BLIP_INFO_ID(iterator)
    end
    return nearestBlipId
end


local function addBlips(array)
    for k in pairs(array) do
        array[k] = nil
    end
    for _, property in ipairs(properties) do
        local ped = PLAYER.PLAYER_PED_ID()
        local nearestBlipId = findNearestBlip(property.id)
        if nearestBlipId then
            local blipCoords = HUD.GET_BLIP_COORDS(nearestBlipId)
            if property.id == 760 then
                table.insert(array, {property.name, blipCoords.x, blipCoords.y, blipCoords.z + 8})
            elseif property.id == 740 then
                table.insert(array, {property.name, blipCoords.x + 10, blipCoords.y - 5, blipCoords.z})
            else
                table.insert(array, {property.name, blipCoords.x, blipCoords.y, blipCoords.z})
            end
        end
    end
end

local locationIndex = 0
local locationTypeIndex = 0

locationTypes = {"自定义", "已拥有"}

customCoords = {
    {"公寓（日蚀大厦）", -774.77, 312.19, 85.70},
    {"赌场", 922.223938, 49.779373, 80.764793},
    {"LS汽车改装店", -370.269958, -129.910370, 38.681633},
    {"公寓", -773.640869, 305.234619, 85.705841},
    {"录制 A 工作室.", -835.250427, -226.589691, 37.267345},
    {"豪华汽车店", -796.260986, -245.412369, 37.079193},
    {"郊区商店", -1208.171387, -782.429016, 17.157467},
    {"面具店", -1339.069946, -1279.114502, 4.866990},
    {"毒蛇店", -719.559692, -157.998932, 36.998993},
    {"本尼改装车行", -205.040863, -1305.484009, 31.369892},
}
--"LS Customs"（LS汽车改装店），坐标：(-370.269958, -129.910370, 38.681633)
--"Eclipse Towers"（日食大厦），坐标：(-773.640869, 305.234619, 85.705841)
--"Record A Studios"（A录音工作室），坐标：(-835.250427, -226.589691, 37.267345)
--"Luxury Autos"（豪华汽车店），坐标：(-796.260986, -245.412369, 37.079193)
--"Suburban"（郊区商店），坐标：(-1208.171387, -782.429016, 17.157467)
--"Mask Shop"（面具店），坐标：(-1339.069946, -1279.114502, 4.866990)
--"Poisonby's"（毒蛇店），坐标：(-719.559692, -157.998932, 36.998993)
--"Benny's"（本尼改装车行），坐标：(-205.040863, -1305.484009, 31.369892)

ownedCoords = {}

locations = {customCoords, ownedCoords}

Tel:add_imgui(function()
    addBlips(ownedCoords)
    copyLocation = ImGui.Button("将位置复制到剪贴板")
    toolTip("", "将当前位置复制到剪贴板，以便将自定义坐标添加到菜单中.")
    locationTypeIndex, locationTypeSelected = ImGui.Combo("位置类型", locationTypeIndex, locationTypes, #locationTypes)
    toolTip("", "选择位置类型（自定义位置 |自有物业)")
    locationNames = {}
    for i, location in ipairs(locations[locationTypeIndex + 1]) do
        table.insert(locationNames, location[1])
    end
    locationIndex, locationSelected = ImGui.ListBox("地点", locationIndex, locationNames, #locationNames)
    if locationSelected then
        ENTITY.SET_ENTITY_COORDS(PLAYER.PLAYER_PED_ID(), locations[locationTypeIndex + 1][locationIndex + 1][2], locations[locationTypeIndex + 1][locationIndex + 1][3], locations[locationTypeIndex + 1][locationIndex + 1][4] - 1, true, false, false, false)
    end
    toolTip("", "点击传送到这个位置")
    if copyLocation then
        coords = ENTITY.GET_ENTITY_COORDS(PLAYER.PLAYER_PED_ID(), true)
        coordsString = coords.x.. ", ".. coords.y.. ", ".. coords.z
        gui.show_message("剪贴板", "复制 ".. coordsString.. " 到剪贴板.")
        ImGui.SetClipboardText(coordsString)
    end
end)
local YimActions = Pla:add_tab("人物动画")
local anim_index = 0
local scenario_index = 0
local switch = 0
local filteredAnims = {}
local filteredScenarios = {}
local spawned_props = {}
local searchQuery = ""
local is_typing = false
local clumsy = false
local rod = false
local manualFlags = false
local disableProps = false
local controllable = false
local looped = false
local upperbody = false
local freeze = false
is_playing_anim = false
is_playing_scenario = false
script.register_looped("playerID", function(playerID)
    if NETWORK.NETWORK_IS_SESSION_ACTIVE() then
        is_online = true
        onlinePed = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(PLAYER.PLAYER_ID())
    else
        is_online = false
        spPed = self.get_ped()
    end
    if is_online then
        ped = onlinePed
    else
        ped = spPed
    end
    playerID:yield()
end)
script.register_looped("Ragdoll Loop", function(script)
    script:yield()
    if clumsy then
        script:sleep(100)
        rod = false
        if PED.IS_PED_RAGDOLL(ped) then
            script:sleep(2500)
            return
        end
        PED.SET_PED_RAGDOLL_ON_COLLISION(ped, true)
    elseif rod then
        script:sleep(100)
        clumsy = false
        if PAD.IS_CONTROL_PRESSED(0, 252) then
            PED.SET_PED_TO_RAGDOLL(ped, 1500, 0, 0, false)
        end
    end
    script:yield()
end)
script.register_looped("animation hotkey", function(script)
    script:yield()
    if is_playing_anim then
        if PAD.IS_CONTROL_PRESSED(0, 256) then
            if PED.IS_PED_IN_ANY_VEHICLE(ped, false) then
                cleanup()
                is_playing_anim = false
            else
                cleanup()
                is_playing_anim = false
                local current_coords = ENTITY.GET_ENTITY_COORDS(ped)
                ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, current_coords.x, current_coords.y, current_coords.z, true, false, false)
            end
        end
    end
end)
script.register_looped("disable game input", function()
        if is_typing then
            PAD.DISABLE_ALL_CONTROL_ACTIONS(0)
        end
end)
local function updatefilteredAnims()
    filteredAnims = {}
    for _, anim in ipairs(animlist) do
        if string.find(string.lower(anim.name), string.lower(searchQuery)) then
            table.insert(filteredAnims, anim)
        end
    end
    table.sort(animlist, function(a, b)
        return a.name < b.name
    end)
end
local function displayFilteredAnims()
    updatefilteredAnims()
    local animNames = {}
    for _, anim in ipairs(filteredAnims) do
        table.insert(animNames, anim.name)
    end
    anim_index, used = ImGui.ListBox("##animlistbox", anim_index, animNames, #filteredAnims)
end
local function Button(text, color, hovercolor, activecolor)
    ImGui.PushStyleColor(ImGuiCol.Button, color[1], color[2], color[3], color[4])
    ImGui.PushStyleColor(ImGuiCol.ButtonHovered, hovercolor[1], hovercolor[2], hovercolor[3], hovercolor[4])
    ImGui.PushStyleColor(ImGuiCol.ButtonActive, activecolor[1], activecolor[2], activecolor[3], activecolor[4])
    local retval = ImGui.Button(text)
    ImGui.PopStyleColor()
    return retval
end
local function busyspinner(text, type)
    HUD.BEGIN_TEXT_COMMAND_BUSYSPINNER_ON("STRING")
    HUD.ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(text)
    HUD.END_TEXT_COMMAND_BUSYSPINNER_ON(type)
end
local function setmanualflag()
    if looped then
        flag_loop = 1
    else
        flag_loop = 0
    end
    if freeze then
        flag_freeze = 2
    else
        flag_freeze = 0
    end
    if upperbody then
        flag_upperbody = 16
    else
        flag_upperbody = 0
    end
    if controllable then
        flag_control = 32
    else
        flag_control = 0
    end
    flag = flag_loop + flag_freeze + flag_upperbody + flag_control
end
local function helpmarker(text)
    ImGui.SameLine()
    ImGui.TextDisabled("(?)")
    if ImGui.IsItemHovered() then
        ImGui.SetNextWindowBgAlpha(0.75)
        ImGui.BeginTooltip()
        ImGui.PushTextWrapPos(ImGui.GetFontSize() * 20)
        ImGui.TextWrapped(text)
        ImGui.PopTextWrapPos()
        ImGui.EndTooltip()
	end
end
local function widgetToolTip(text)
    if ImGui.IsItemHovered() then
        ImGui.SetNextWindowBgAlpha(0.75)
        ImGui.BeginTooltip()
        ImGui.PushTextWrapPos(ImGui.GetFontSize() * 20)
        ImGui.TextWrapped(text)
        ImGui.PopTextWrapPos()
        ImGui.EndTooltip()
	end
end
local function setdrunk()
    script.run_in_fiber(function()
        while not STREAMING.HAS_CLIP_SET_LOADED("MOVE_M@DRUNK@VERYDRUNK") do
            STREAMING.REQUEST_CLIP_SET("MOVE_M@DRUNK@VERYDRUNK")
            coroutine.yield()
        end
        PED.SET_PED_MOVEMENT_CLIPSET(ped, "MOVE_M@DRUNK@VERYDRUNK", 1.0)
    end)
end
local function sethoe()
    script.run_in_fiber(function()
        while not STREAMING.HAS_CLIP_SET_LOADED("move_f@maneater") do
            STREAMING.REQUEST_CLIP_SET("move_f@maneater")
            coroutine.yield()
        end
        PED.SET_PED_MOVEMENT_CLIPSET(ped, "move_f@maneater", 1.0)
    end)
end
local function setcrouched()
    script.run_in_fiber(function()
        while not STREAMING.HAS_CLIP_SET_LOADED("move_ped_crouched") do
            STREAMING.REQUEST_CLIP_SET("move_ped_crouched")
            coroutine.yield()
        end
        PED.SET_PED_MOVEMENT_CLIPSET(ped, "move_ped_crouched", 0.3)
    end)
end
local function setlester()
    script.run_in_fiber(function()
        while not STREAMING.HAS_CLIP_SET_LOADED("move_heist_lester") do
            STREAMING.REQUEST_CLIP_SET("move_heist_lester")
            coroutine.yield()
        end
        PED.SET_PED_MOVEMENT_CLIPSET(ped, "move_heist_lester", 0.4)
    end)
end
local function setballistic()
    script.run_in_fiber(function()
        while not STREAMING.HAS_CLIP_SET_LOADED("anim_group_move_ballistic") do
            STREAMING.REQUEST_CLIP_SET("anim_group_move_ballistic")
            coroutine.yield()
        end
        PED.SET_PED_MOVEMENT_CLIPSET(ped, "anim_group_move_ballistic", 1)
    end)
end
YimActions:add_imgui(function()
    ImGui.Text("Search:")
    ImGui.PushItemWidth(350)
    searchQuery, used = ImGui.InputText("", searchQuery, 32)
    if ImGui.IsItemActive() then
        is_typing = true
    else
        is_typing = false
    end
    ImGui.BeginTabBar("人物动画", ImGuiTabBarFlags.None)
    if ImGui.BeginTabItem("动画") then
        ImGui.PushItemWidth(350)
        displayFilteredAnims()
        ImGui.Separator()
        manualFlags, used = ImGui.Checkbox("编辑标志", manualFlags, true)
        helpmarker("允许您自定义动画的播放方式。\n示例：如果动画设置为循环播放，但您希望它冻结，请激活此设置，然后选择所需的设置.")
        ImGui.SameLine()
        disableProps, used = ImGui.Checkbox("禁用道具", disableProps, true)
        helpmarker("选择是否播放带有道具的动画。在播放动画之前选中或取消选中此项.")
        if manualFlags then
            ImGui.Separator()
            controllable, used = ImGui.Checkbox("允许控制", controllable, true)
            helpmarker("允许你控制你的角色和/或车辆。如果与“仅限上半身”配对，您可以播放动画和四处走动/奔跑/开车。")
            ImGui.SameLine() ImGui.Spacing() ImGui.SameLine() ImGui.Spacing() ImGui.SameLine() ImGui.Spacing() ImGui.SameLine() ImGui.Spacing() ImGui.SameLine()
            looped, used = ImGui.Checkbox("循环", looped, true)
            helpmarker("永久播放动画，直到您手动停止它.")
            upperbody, used = ImGui.Checkbox("仅限上半身", upperbody, true)
            helpmarker("仅在角色的上半身（从腰部以上）播放动画。")
            ImGui.SameLine() ImGui.Spacing() ImGui.SameLine() ImGui.Spacing() ImGui.SameLine()
            freeze, used = ImGui.Checkbox("冻结", freeze, true)
            helpmarker("将动画冻结在最后一帧。适用于布娃娃/睡眠/死亡动画.")
        end
        info = filteredAnims[anim_index + 1]
        function cleanup()
            script.run_in_fiber(function()
                TASK.CLEAR_PED_TASKS(ped)
                ENTITY.DELETE_ENTITY(prop1)
                ENTITY.DELETE_ENTITY(prop2)
                GRAPHICS.STOP_PARTICLE_FX_LOOPED(loopedFX)
                STREAMING.REMOVE_ANIM_DICT(info.dict)
                STREAMING.REMOVE_NAMED_PTFX_ASSET(info.ptfxdict)
            end)
        end
        if ImGui.Button("   播放    ") then
            local coords = ENTITY.GET_ENTITY_COORDS(ped, false)
            local heading = ENTITY.GET_ENTITY_HEADING(ped)
            local forwardX = ENTITY.GET_ENTITY_FORWARD_X(ped)
            local forwardY = ENTITY.GET_ENTITY_FORWARD_Y(ped)
            local boneIndex = PED.GET_PED_BONE_INDEX(ped, info.boneID)
            local bonecoords = PED.GET_PED_BONE_COORDS(ped, info.boneID)
            if manualFlags then
                setmanualflag()
            else
                flag = info.flag
            end
            if info.type == 1 then
                cleanup()
                script.run_in_fiber(function()
                    if not disableProps then
                        while not STREAMING.HAS_MODEL_LOADED(info.prop1) do
                            STREAMING.REQUEST_MODEL(info.prop1)
                            coroutine.yield()
                        end
                        prop1 = OBJECT.CREATE_OBJECT(info.prop1, 0.0, 0.0, 0.0, true, true, true)
                        table.insert(spawned_props, prop1)
                        ENTITY.ATTACH_ENTITY_TO_ENTITY(prop1, ped, boneIndex, info.posx, info.posy, info.posz, info.rotx, info.roty, info.rotz, false, false, false, false, 2, true, 1)
                    end
                    while not STREAMING.HAS_ANIM_DICT_LOADED(info.dict) do
                        STREAMING.REQUEST_ANIM_DICT(info.dict)
                        coroutine.yield()
                    end
                    TASK.TASK_PLAY_ANIM(ped, info.dict, info.anim, 4.0, -4.0, -1, flag, 1.0, false, false, false)
                    is_playing_anim = true
                end)
            elseif info.type == 2 then
                cleanup()
                script.run_in_fiber(function(type2)
                    while not STREAMING.HAS_NAMED_PTFX_ASSET_LOADED(info.ptfxdict) do
                        STREAMING.REQUEST_NAMED_PTFX_ASSET(info.ptfxdict)
                        coroutine.yield()
                    end
                    while not STREAMING.HAS_ANIM_DICT_LOADED(info.dict) do
                        STREAMING.REQUEST_ANIM_DICT(info.dict)
                        coroutine.yield()
                    end
                    TASK.TASK_PLAY_ANIM(ped, info.dict, info.anim, 4.0, -4.0, -1, flag, 0, false, false, false)
                    is_playing_anim = true
                    type2:sleep(info.ptfxdelay)
                    GRAPHICS.USE_PARTICLE_FX_ASSET(info.ptfxdict)
                    loopedFX = GRAPHICS.START_NETWORKED_PARTICLE_FX_LOOPED_ON_ENTITY_BONE(info.ptfxname, ped, info.ptfxOffx, info.ptfxOffy, info.ptfxOffz, info.ptfxrotx, info.ptfxroty, info.ptfxrotz, boneIndex, info.ptfxscale, false, false, false, 0, 0, 0, 0)
                end)
            elseif info.type == 3 then
                cleanup()
                script.run_in_fiber(function()
                    if not disableProps then
                        while not STREAMING.HAS_MODEL_LOADED(info.prop1) do
                            STREAMING.REQUEST_MODEL(info.prop1)
                            coroutine.yield()
                        end
                        prop1 = OBJECT.CREATE_OBJECT(info.prop1, coords.x + forwardX /1.7, coords.y + forwardY /1.7, coords.z, true, true, false)
                        table.insert(spawned_props, prop1)
                        ENTITY.SET_ENTITY_HEADING(prop1, heading + info.rotz)
                        OBJECT.PLACE_OBJECT_ON_GROUND_PROPERLY(prop1)
                    end
                    while not STREAMING.HAS_ANIM_DICT_LOADED(info.dict) do
                        STREAMING.REQUEST_ANIM_DICT(info.dict)
                        coroutine.yield()
                    end
                    TASK.TASK_PLAY_ANIM(ped, info.dict, info.anim, 4.0, -4.0, -1, flag, 1.0, false, false, false)
                    is_playing_anim = true
                end)
            elseif info.type == 4 then
                cleanup()
                script.run_in_fiber(function(type4)
                    if not disableProps then
                        while not STREAMING.HAS_MODEL_LOADED(info.prop1) do
                            STREAMING.REQUEST_MODEL(info.prop1)
                            coroutine.yield()
                        end
                        prop1 = OBJECT.CREATE_OBJECT(info.prop1, 0.0, 0.0, 0.0, true, true, false)
                        table.insert(spawned_props, prop1)
                        ENTITY.SET_ENTITY_COORDS(prop1, bonecoords.x + info.posx, bonecoords.y + info.posy, bonecoords.z + info.posz)
                        type4:sleep(20)
                        OBJECT.PLACE_OBJECT_ON_GROUND_PROPERLY(prop1)
                        ENTITY.SET_ENTITY_COLLISION(prop1, info.propColl, info.propColl)
                    end
                    while not STREAMING.HAS_ANIM_DICT_LOADED(info.dict) do
                        STREAMING.REQUEST_ANIM_DICT(info.dict)
                        coroutine.yield()
                    end
                    TASK.TASK_PLAY_ANIM(ped, info.dict, info.anim, 4.0, -4.0, -1, flag, 1.0, false, false, false)
                    is_playing_anim = true
                end)
            elseif info.type == 5 then
                cleanup()
                script.run_in_fiber(function(type5)
                    while not STREAMING.HAS_ANIM_DICT_LOADED(info.dict) do
                        STREAMING.REQUEST_ANIM_DICT(info.dict)
                        coroutine.yield()
                    end
                    TASK.TASK_PLAY_ANIM(ped, info.dict, info.anim, 4.0, -4.0, -1, flag, 0.0, false, false, false)
                    if not disableProps then
                        while not STREAMING.HAS_MODEL_LOADED(info.prop1) do
                            STREAMING.REQUEST_MODEL(info.prop1)
                            coroutine.yield()
                        end
                        prop1 = OBJECT.CREATE_OBJECT(info.prop1, 0.0, 0.0, 0.0, true, true, false)
                        table.insert(spawned_props, prop1)
                        ENTITY.ATTACH_ENTITY_TO_ENTITY(prop1, ped, boneIndex, info.posx, info.posy, info.posz, info.rotx, info.roty, info.rotz, false, false, false, false, 2, true, 1)
                        type5:sleep(50)
                        while not STREAMING.HAS_NAMED_PTFX_ASSET_LOADED(info.ptfxdict) do
                            STREAMING.REQUEST_NAMED_PTFX_ASSET(info.ptfxdict)
                            coroutine.yield()
                        end
                        type5:sleep(info.ptfxdelay)
                        GRAPHICS.USE_PARTICLE_FX_ASSET(info.ptfxdict)
                        loopedFX = GRAPHICS.START_NETWORKED_PARTICLE_FX_LOOPED_ON_ENTITY(info.ptfxname, prop1, info.ptfxOffx, info.ptfxOffy, info.ptfxOffz, info.ptfxrotx, info.ptfxroty, info.ptfxrotz, info.ptfxscale, false, false, false, 0, 0, 0, 0)
                    end
                    is_playing_anim = true
                end)
            elseif info.type == 6 then
                    cleanup()
                    script.run_in_fiber(function()
                        if not disableProps then
                            while not STREAMING.HAS_MODEL_LOADED(info.prop1) do
                                STREAMING.REQUEST_MODEL(info.prop1)
                                coroutine.yield()
                            end
                            prop1 = OBJECT.CREATE_OBJECT(info.prop1, 0.0, 0.0, 0.0, true, true, false)
                            table.insert(spawned_props, prop1)
                            ENTITY.ATTACH_ENTITY_TO_ENTITY(prop1, ped, boneIndex, info.posx, info.posy, info.posz, info.rotx, info.roty, info.rotz, false, false, false, false, 2, true, 1)
                            while not STREAMING.HAS_MODEL_LOADED(info.prop2) do
                                STREAMING.REQUEST_MODEL(info.prop2)
                                coroutine.yield()
                            end
                            prop2 = OBJECT.CREATE_OBJECT(info.prop2, 0.0, 0.0, 0.0, true, true, false)
                            table.insert(spawned_props, prop2)
                            ENTITY.ATTACH_ENTITY_TO_ENTITY(prop2, ped, PED.GET_PED_BONE_INDEX(ped, info.bone2), info.posx2, info.posy2, info.posz2, info.rotx2, info.roty2, info.rotz2, false, false, false, false, 2, true, 1)
                        end
                        while not STREAMING.HAS_ANIM_DICT_LOADED(info.dict) do
                            STREAMING.REQUEST_ANIM_DICT(info.dict)
                            coroutine.yield()
                        end
                        TASK.TASK_PLAY_ANIM(ped, info.dict, info.anim, 4.0, -4.0, -1, flag, 1.0, false, false, false)
                        is_playing_anim = true
                    end)
            else
                cleanup()
                script.run_in_fiber(function()
                    while not STREAMING.HAS_ANIM_DICT_LOADED(info.dict) do
                        STREAMING.REQUEST_ANIM_DICT(info.dict)
                        coroutine.yield()
                    end
                    TASK.TASK_PLAY_ANIM(ped, info.dict, info.anim, 4.0, -4.0, -1, flag, 0.0, false, false, false)
                    is_playing_anim = true
                end)
            end
        end
        ImGui.SameLine()
        if ImGui.Button("   停止    ") then
            if PED.IS_PED_IN_ANY_VEHICLE(ped, false) then
                cleanup()
                is_playing_anim = false
            else
                cleanup()
                is_playing_anim = false
                local current_coords = ENTITY.GET_ENTITY_COORDS(ped)   
                ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, current_coords.x, current_coords.y, current_coords.z, true, false, false)
            end
        end
        widgetToolTip("提示：您也可以通过按键盘上的[del]或控制器上的[X]来停止动画.")
        ImGui.SameLine()
        if Button("强制丢弃道具", {1, 0, 0, 1}, {1, 0, 0, 0.7}, {1, 0, 0, 0.5}) then
            for k, v in ipairs(spawned_props) do
                if is_playing_anim then
                    script.run_in_fiber(function()
                        if ENTITY.DOES_ENTITY_EXIST(v) then
                            ENTITY.DETACH_ENTITY(v)
                            ENTITY.SET_ENTITY_AS_NO_LONGER_NEEDED(v)
                            TASK.CLEAR_PED_TASKS(ped)
                            is_playing_anim = false
                            table.remove(spawned_props, k)
                        end
                    end)
                end
            end
        end
        widgetToolTip("如果动画意外中断，某些道具可能会卡住。使用此按钮摆脱它们.")
        event.register_handler(menu_event.ScriptsReloaded, function()
            PED.RESET_PED_MOVEMENT_CLIPSET(ped, 0.0)
            PED.SET_PED_RAGDOLL_ON_COLLISION(ped, false)
            if is_playing_anim then
                GRAPHICS.STOP_PARTICLE_FX_LOOPED(loopedFX)
                ENTITY.DELETE_ENTITY(prop1)
                ENTITY.SET_ENTITY_AS_NO_LONGER_NEEDED(prop1)
                ENTITY.DELETE_ENTITY(prop2)
                ENTITY.SET_ENTITY_AS_NO_LONGER_NEEDED(prop2)
                TASK.CLEAR_PED_TASKS_IMMEDIATELY(ped)
                STREAMING.REMOVE_NAMED_PTFX_ASSET(info.ptfxdict)
                STREAMING.REMOVE_ANIM_DICT(info.dict)
            -- //fix player clipping through the ground after ending low-positioned anims//
                local current_coords = ENTITY.GET_ENTITY_COORDS(ped)
                if PED.IS_PED_IN_ANY_VEHICLE(ped, false) then
                    PED.SET_PED_COORDS_KEEP_VEHICLE(ped, current_coords.x, current_coords.y, current_coords.z)
                else
                    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, current_coords.x, current_coords.y, current_coords.z, true, false, false)
                end
                is_playing_anim = false
            end
        end)
        event.register_handler(menu_event.MenuUnloaded, function()
            PED.RESET_PED_MOVEMENT_CLIPSET(ped, 0.0)
            PED.SET_PED_RAGDOLL_ON_COLLISION(ped, false)
            if is_playing_anim then
                GRAPHICS.STOP_PARTICLE_FX_LOOPED(loopedFX)
                ENTITY.DELETE_ENTITY(prop1)
                ENTITY.SET_ENTITY_AS_NO_LONGER_NEEDED(prop1)
                ENTITY.DELETE_ENTITY(prop2)
                ENTITY.SET_ENTITY_AS_NO_LONGER_NEEDED(prop2)
                TASK.CLEAR_PED_TASKS_IMMEDIATELY(ped)
                STREAMING.REMOVE_NAMED_PTFX_ASSET(info.ptfxdict)
                STREAMING.REMOVE_ANIM_DICT(info.dict)
            -- //fix player clipping through the ground after ending low-positioned anims//
                local current_coords = ENTITY.GET_ENTITY_COORDS(ped)
                if PED.IS_PED_IN_ANY_VEHICLE(ped, false) then
                    PED.SET_PED_COORDS_KEEP_VEHICLE(ped, current_coords.x, current_coords.y, current_coords.z)
                else
                    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, current_coords.x, current_coords.y, current_coords.z, true, false, false)
                end
                is_playing_anim = false
            end
        end)
        ImGui.Separator()
        ImGui.Text("布娃娃选项：")
        ImGui.Spacing()
        clumsy, used = ImGui.Checkbox("笨拙", clumsy, true)
        helpmarker("当你与任何物体碰撞时，会让你变成布娃娃。\n（不适用于布娃娃按需)")
        ImGui.SameLine()
        rod, used = ImGui.Checkbox("布娃娃点播", rod, true)
        helpmarker("按下键盘上的[X]键或控制器上的[LT]键来立即让角色进入“翻滚动作”状态。如果按住按钮时间越长，角色在地面上停留的时间就越长。\n值得注意的是，这个功能在使用“Clumsy（笨拙）”模式时不可用。")
        ImGui.Spacing()
        ImGui.Text("移动选项:")
        ImGui.Spacing()
        local isChanged = false
        switch, isChanged = ImGui.RadioButton("正常", switch, 0)
        if isChanged then
            PED.RESET_PED_MOVEMENT_CLIPSET(ped, 0.0)
            isChanged = false
        end
        ImGui.SameLine()
        switch, isChanged = ImGui.RadioButton("醉酒", switch, 1)
        widgetToolTip("与布娃娃选项配合得很好.")
        if isChanged then setdrunk() end
        ImGui.SameLine()
        switch, isChanged = ImGui.RadioButton("妓女", switch, 2)
        if isChanged then sethoe() end
        switch, isChanged = ImGui.RadioButton("蹲", switch, 3)
        widgetToolTip("你可以将这个动作与默认的潜行动作[左CTRL]配对使用")
        if isChanged then setcrouched() end
        ImGui.SameLine()
        switch, isChanged = ImGui.RadioButton("莱斯特", switch, 4)
        if isChanged then setlester() end
        ImGui.SameLine()
        switch, isChanged = ImGui.RadioButton("重装", switch, 5)
        if isChanged then setballistic() end
        ImGui.EndTabItem()
    end
    if ImGui.BeginTabItem("场景") then
        ImGui.PushItemWidth(335)
        local function updatefilteredScenarios()
            filteredScenarios = {}
            for _, scene in ipairs(ped_scenarios) do
                if string.find(string.lower(scene.name), string.lower(searchQuery)) then
                    table.insert(filteredScenarios, scene)
                end
            end
        end
        local function displayFilteredScenarios()
            updatefilteredScenarios()
            local scenarioNames = {}
            for _, scene in ipairs(filteredScenarios) do
                table.insert(scenarioNames, scene.name)
            end
            scenario_index, used = ImGui.ListBox(" ", scenario_index, scenarioNames, #filteredScenarios)
        end
        displayFilteredScenarios()
        ImGui.Separator()
        if ImGui.Button("   播放    ") then
            local data = filteredScenarios[scenario_index+1]
            local coords = ENTITY.GET_ENTITY_COORDS(ped, false)
            local heading = ENTITY.GET_ENTITY_HEADING(ped)
            local forwardX = ENTITY.GET_ENTITY_FORWARD_X(ped)
            local forwardY = ENTITY.GET_ENTITY_FORWARD_Y(ped)
            if data.name == "使用烧烤架" then
                script.run_in_fiber(function()
                    while not STREAMING.HAS_MODEL_LOADED(286252949) do
                        STREAMING.REQUEST_MODEL(286252949)
                        coroutine.yield()
                    end
                    bbq = OBJECT.CREATE_OBJECT(286252949, coords.x + (forwardX), coords.y + (forwardY), coords.z, true, true, false)
                    ENTITY.SET_ENTITY_HEADING(bbq, heading)
                    OBJECT.PLACE_OBJECT_ON_GROUND_PROPERLY(bbq)
                    TASK.CLEAR_PED_TASKS_IMMEDIATELY(ped)
                    TASK.TASK_START_SCENARIO_IN_PLACE(ped, data.scenario, -1, true)
                    is_playing_scenario = true
                end)
            else
                script.run_in_fiber(function(script)
                    TASK.CLEAR_PED_TASKS_IMMEDIATELY(ped)
                    TASK.TASK_START_SCENARIO_IN_PLACE(ped, data.scenario, -1, true)
                    is_playing_scenario = true
                end)
            end
        end
        ImGui.SameLine() ImGui.Spacing() ImGui.SameLine() ImGui.Spacing() ImGui.SameLine() ImGui.Spacing() ImGui.SameLine() ImGui.Spacing() ImGui.SameLine() ImGui.Spacing() ImGui.SameLine() ImGui.Spacing() ImGui.SameLine() ImGui.Spacing() ImGui.SameLine() ImGui.Spacing() ImGui.SameLine() ImGui.SameLine() ImGui.Spacing() ImGui.SameLine() ImGui.Spacing() ImGui.SameLine() ImGui.Spacing() ImGui.SameLine() 
        ImGui.SameLine() ImGui.Spacing() ImGui.SameLine() ImGui.Spacing() ImGui.SameLine() ImGui.Spacing() ImGui.SameLine() ImGui.Spacing() ImGui.SameLine()
        if ImGui.Button("   停止    ") then
            if is_playing_scenario then
                script.run_in_fiber(function(script)
                    busyspinner("停止方案...", 3)
                    ENTITY.DELETE_ENTITY(bbq)
                    TASK.CLEAR_PED_TASKS(ped)
                    is_playing_scenario = false
                    script:sleep(2000)
                    HUD.BUSYSPINNER_OFF()
                end)
            end
        end
        widgetToolTip("提示：您也可以通过按键盘上的[del]或控制器上的[X]来停止场景。")
        event.register_handler(menu_event.ScriptsReloaded, function()
            if is_playing_scenario then
                ENTITY.DELETE_ENTITY(bbq)
                TASK.CLEAR_PED_TASKS_IMMEDIATELY(ped)
                is_playing_scenario = false
            end
        end)
        event.register_handler(menu_event.MenuUnloaded, function()
            if is_playing_scenario then
                ENTITY.DELETE_ENTITY(bbq)
                TASK.CLEAR_PED_TASKS_IMMEDIATELY(ped)
                is_playing_scenario = false
            end
        end)
        ImGui.EndTabItem()
    end
end)
script.register_looped("scenario hotkey", function(hotkey)
    hotkey:yield()
    if is_playing_scenario then
        if PAD.IS_CONTROL_PRESSED(0, 256) then
            script.run_in_fiber(function(script)
                busyspinner("停止方案...", 3)
                ENTITY.DELETE_ENTITY(bbq)
                TASK.CLEAR_PED_TASKS(ped)
                is_playing_scenario = false
                script:sleep(2000)
                HUD.BUSYSPINNER_OFF()
            end)
        end
    end
end)
-- CasinoPacino - gir489returns
casino_gui = Money:add_tab("赌场")

blackjack_cards         = 112
blackjack_table_players = 1772
blackjack_decks         = 846
 
three_card_poker_cards           = blackjack_cards
three_card_poker_table           = 745
three_card_poker_current_deck    = 168
three_card_poker_anti_cheat      = 1034
three_card_poker_anti_cheat_deck = 799
three_card_poker_deck_size       = 55
 
roulette_master_table   = 120
roulette_outcomes_table = 1357
roulette_ball_table     = 153
 
slots_random_results_table = 1344
 
prize_wheel_win_state   = 276
prize_wheel_prize       = 14
prize_wheel_prize_state = 45
 
globals_tuneable        = 262145
 
casino_heist_cut        = 1971696
casino_heist_cut_offset = 1497 + 736 + 92
casino_heist_lester_cut = 28998
casino_heist_gunman_cut = 29024
casino_heist_driver_cut = 29029
casino_heist_hacker_cut = 29035
 
casino_heist_approach      = 0
casino_heist_target        = 0
casino_heist_last_approach = 0
casino_heist_hard          = 0
casino_heist_gunman        = 0
casino_heist_driver        = 0
casino_heist_hacker        = 0
casino_heist_weapons       = 0
casino_heist_cars          = 0
casino_heist_masks         = 0
 
fm_mission_controller_cart_grab       = 10247
fm_mission_controller_cart_grab_speed = 14
fm_mission_controller_cart_autograb   = true

casino_gui:add_text("老虎机")
bypass_casino_bans = casino_gui:add_checkbox("绕过赌场冷却时间")
casino_gui:add_sameline()
rig_slot_machine = casino_gui:add_checkbox("钻机老虎机")
casino_gui:add_text("这是被检测到的，并且可以禁止，请极其谨慎地使用它!")
casino_gui:add_separator()
 
casino_gui:add_text("扑克") --If his name is Al Pacino and he said, "It's not Al anymore, it's Dunk!", then his name should now be Dunk Pacino.
force_poker_cards = casino_gui:add_checkbox("强制所有玩家手牌达到皇家同花顺")
casino_gui:add_sameline()
set_dealers_poker_cards = casino_gui:add_checkbox("强迫庄家展示手牌以达成爆冷门")
set_dealers_poker_cards:set_enabled(true)
 
function set_poker_cards(player_id, players_current_table, card_one, card_two, card_three)
    locals.set_int("three_card_poker", (three_card_poker_cards) + (three_card_poker_current_deck) + (1 + (players_current_table * three_card_poker_deck_size)) + (2) + (1) + (player_id * 3), card_one)
    locals.set_int("three_card_poker", (three_card_poker_anti_cheat) + (three_card_poker_anti_cheat_deck) + (1) + (1 + (players_current_table * three_card_poker_deck_size)) + (1) + (player_id * 3), card_one)
    locals.set_int("three_card_poker", (three_card_poker_cards) + (three_card_poker_current_deck) + (1 + (players_current_table * three_card_poker_deck_size)) + (2) + (2) + (player_id * 3), card_two)
    locals.set_int("three_card_poker", (three_card_poker_anti_cheat) + (three_card_poker_anti_cheat_deck) + (1) + (1 + (players_current_table * three_card_poker_deck_size)) + (2) + (player_id * 3), card_two)
    locals.set_int("three_card_poker", (three_card_poker_cards) + (three_card_poker_current_deck) + (1 + (players_current_table * three_card_poker_deck_size)) + (2) + (3) + (player_id * 3), card_three)
    locals.set_int("three_card_poker", (three_card_poker_anti_cheat) + (three_card_poker_anti_cheat_deck) + (1) + (1 + (players_current_table * three_card_poker_deck_size)) + (3) + (player_id * 3), card_three)
end
 
function get_cardname_from_index(card_index)
    if card_index == 0 then
        return "Rolling"
    end
 
    local card_number = math.fmod(card_index, 13)
    local cardName = ""
    local cardSuit = ""
 
    if card_number == 1 then
        cardName = "A"
    elseif card_number == 11 then
        cardName = "J"
    elseif card_number == 12 then
        cardName = "Q"
    elseif card_number == 13 then
        cardName = "K"
    else
        cardName = tostring(card_number)
    end
 
    if card_index >= 1 and card_index <= 13 then
        cardSuit = "梅花"
    elseif card_index >= 14 and card_index <= 26 then
        cardSuit = "方块"
    elseif card_index >= 27 and card_index <= 39 then
        cardSuit = "红桃"
    elseif card_index >= 40 and card_index <= 52 then
        cardSuit = "黑桃"
    end
 
    return cardName .. " of " .. cardSuit
end
 
casino_gui:add_separator()
casino_gui:add_text("二十一点")
casino_gui:add_text("庄家面朝下的卡: ")
casino_gui:add_sameline()
dealers_card_gui_element = casino_gui:add_input_string("##dealers_card_gui_element")
 
casino_gui:add_button("让庄家的手破产", function()
    script.run_in_fiber(function (script)
        local player_id = PLAYER.PLAYER_ID()
        while NETWORK.NETWORK_GET_HOST_OF_SCRIPT("blackjack", -1, 0) ~= player_id and NETWORK.NETWORK_GET_HOST_OF_SCRIPT("blackjack", 0, 0) ~= player_id and NETWORK.NETWORK_GET_HOST_OF_SCRIPT("blackjack", 1, 0) ~= player_id and NETWORK.NETWORK_GET_HOST_OF_SCRIPT("blackjack", 2, 0) ~= player_id and NETWORK.NETWORK_GET_HOST_OF_SCRIPT("blackjack", 3, 0) ~= player_id do 
            network.force_script_host("blackjack")
            gui.show_message("赌场Pacino", "控制二十一点脚本.") --If you see this spammed, someone if fighting you for control.
            script:yield()
        end
        local blackjack_table = locals.get_int("blackjack", blackjack_table_players + 1 + (player_id * 8) + 4) --The Player's current table he is sitting at.
        if blackjack_table ~= -1 then
            locals.set_int("blackjack", blackjack_cards + blackjack_decks + 1 + (blackjack_table * 13) + 1, 11)
            locals.set_int("blackjack", blackjack_cards + blackjack_decks + 1 + (blackjack_table * 13) + 2, 12)
            locals.set_int("blackjack", blackjack_cards + blackjack_decks + 1 + (blackjack_table * 13) + 3, 13)
            locals.set_int("blackjack", blackjack_cards + blackjack_decks + 1 + (blackjack_table * 13) + 12, 3)
        end
    end)
end)
 
casino_gui:add_separator()
casino_gui:add_text("轮盘赌")
force_roulette_wheel = casino_gui:add_checkbox("激活轮盘赌装备")

local player_id = PLAYER.PLAYER_ID()

        casVal = -1
        casino_gui:add_imgui(function()
            casVal, used2 = ImGui.SliderInt("投注号码", casVal, -1, 36)
            if used2 then
                valz = casVal
            end
        end)
        
casino_gui:add_separator()
casino_gui:add_text("使用这些选项是有风险的，尤其是在使用冷却时间旁路时")
 
script.register_looped("赌场 Pacino 线程", function (script)
    if force_poker_cards:is_enabled() then
        local player_id = PLAYER.PLAYER_ID()
        if SCRIPT.GET_NUMBER_OF_THREADS_RUNNING_THE_SCRIPT_WITH_THIS_HASH(joaat("three_card_poker")) ~= 0 then
            while NETWORK.NETWORK_GET_HOST_OF_SCRIPT("three_card_poker", -1, 0) ~= player_id and NETWORK.NETWORK_GET_HOST_OF_SCRIPT("three_card_poker", 0, 0) ~= player_id and NETWORK.NETWORK_GET_HOST_OF_SCRIPT("three_card_poker", 1, 0) ~= player_id and NETWORK.NETWORK_GET_HOST_OF_SCRIPT("three_card_poker", 2, 0) ~= player_id and NETWORK.NETWORK_GET_HOST_OF_SCRIPT("three_card_poker", 3, 0) ~= player_id do 
                network.force_script_host("three_card_poker")
                gui.show_message("赌场Pacino", "控制三张牌扑克脚本.") --If you see this spammed, someone if fighting you for control.
                script:sleep(500)
            end
            local players_current_table = locals.get_int("three_card_poker", three_card_poker_table + 1 + (player_id * 9) + 2) --The Player's current table he is sitting at.
            if (players_current_table ~= -1) then -- If the player is sitting at a poker table
                local player_0_card_1 = locals.get_int("three_card_poker", (three_card_poker_cards) + (three_card_poker_current_deck) + (1 + (players_current_table * three_card_poker_deck_size)) + (2) + (1) + (0 * 3))
                local player_0_card_2 = locals.get_int("three_card_poker", (three_card_poker_cards) + (three_card_poker_current_deck) + (1 + (players_current_table * three_card_poker_deck_size)) + (2) + (2) + (0 * 3))
                local player_0_card_3 = locals.get_int("three_card_poker", (three_card_poker_cards) + (three_card_poker_current_deck) + (1 + (players_current_table * three_card_poker_deck_size)) + (2) + (3) + (0 * 3))
                if player_0_card_1 ~= 50 or player_0_card_2 ~= 51 or player_0_card_3 ~= 52 then --Check if we need to overwrite the deck.
                    local total_players = 0
                    for player_iter = 0, 31, 1 do
                        local player_table = locals.get_int("three_card_poker", three_card_poker_table + 1 + (player_iter * 9) + 2)
                        if player_iter ~= player_id and player_table == players_current_table then --An additional player is sitting at the user's table.
                            total_players = total_players + 1
                        end
                    end
                    for playing_player_iter = 0, total_players, 1 do
                        set_poker_cards(playing_player_iter, players_current_table, 50, 51, 52)
                    end
                    if set_dealers_poker_cards:is_enabled() then
                        set_poker_cards(total_players + 1, players_current_table, 1, 8, 22)
                    end
                end
            end
        end
    end
    if SCRIPT.GET_NUMBER_OF_THREADS_RUNNING_THE_SCRIPT_WITH_THIS_HASH(joaat("blackjack")) ~= 0 then
        local dealers_card = 0
        local blackjack_table = locals.get_int("blackjack", blackjack_table_players + 1 + (PLAYER.PLAYER_ID() * 8) + 4) --The Player's current table he is sitting at.
        if blackjack_table ~= -1 then
            dealers_card = locals.get_int("blackjack", blackjack_cards + blackjack_decks + 1 + (blackjack_table * 13) + 1) --Dealer's facedown card.
            dealers_card_gui_element:set_value(get_cardname_from_index(dealers_card))
        else
            dealers_card_gui_element:set_value("目前不坐在二十一点桌旁")
        end
    else
        dealers_card_gui_element:set_value("目前不在赌场")
    end
    if force_roulette_wheel:is_enabled() then
         local player_id = PLAYER.PLAYER_ID()
        if SCRIPT.GET_NUMBER_OF_THREADS_RUNNING_THE_SCRIPT_WITH_THIS_HASH(joaat("casinoroulette")) ~= 0 then
            while NETWORK.NETWORK_GET_HOST_OF_SCRIPT("casinoroulette", -1, 0) ~= player_id and NETWORK.NETWORK_GET_HOST_OF_SCRIPT("casinoroulette", 0, 0) ~= player_id and NETWORK.NETWORK_GET_HOST_OF_SCRIPT("casinoroulette", 1, 0) ~= player_id and NETWORK.NETWORK_GET_HOST_OF_SCRIPT("casinoroulette", 2, 0) ~= player_id and NETWORK.NETWORK_GET_HOST_OF_SCRIPT("casinoroulette", 3, 0) ~= player_id do 
                network.force_script_host("casinoroulette")
                gui.show_message("CasinoPacino", "Taking control of the casinoroulette script.") --If you see this spammed, someone if fighting you for control.
                script:sleep(500)
            end
            for tabler_iter = 0, 6, 1 do
                locals.set_int("casinoroulette", (roulette_master_table) + (roulette_outcomes_table) + (roulette_ball_table) + (tabler_iter), valz)
                gui.show_message("赌场Pacino激活!", "开奖号码: "..valz)
            end
        end
    end

    if SCRIPT.GET_NUMBER_OF_THREADS_RUNNING_THE_SCRIPT_WITH_THIS_HASH(joaat("casino_slots")) ~= 0 then
        local needs_run = false
        if rig_slot_machine:is_enabled() then
            for slots_iter = 3, 195, 1 do
                if slots_iter ~= 67 and slots_iter ~= 132 then
                    if locals.get_int("casino_slots", (slots_random_results_table) + (slots_iter)) ~= 6 then
                        needs_run = true
                    end
                end
            end
        else
            local sum = 0
            for slots_iter = 3, 195, 1 do
                if slots_iter ~= 67 and slots_iter ~= 132 then
                    sum = sum + locals.get_int("casino_slots", (slots_random_results_table) + (slots_iter))
                end
            end
            needs_run = sum == 1146
        end
        if needs_run then
            for slots_iter = 3, 195, 1 do
                if slots_iter ~= 67 and slots_iter ~= 132 then
                    local slot_result = 6
                    if rig_slot_machine:is_enabled() == false then
                        math.randomseed(os.time()+slots_iter)
                        slot_result = math.random(0, 7)
                    end
                    locals.set_int("casino_slots", (slots_random_results_table) + (slots_iter), slot_result)
                end
            end
        end
    end
    if bypass_casino_bans:is_enabled() then
        STATS.STAT_SET_INT(joaat("MPPLY_CASINO_CHIPS_WON_GD"), 0, true)
    end
    if gui.is_open() and casino_gui:is_selected() then
        casino_heist_approach = stats.get_int("MPX_H3OPT_APPROACH")
        casino_heist_target = stats.get_int("MPX_H3OPT_TARGET")
        casino_heist_last_approach = stats.get_int("MPX_H3_LAST_APPROACH")
        casino_heist_hard = stats.get_int("MPX_H3_HARD_APPROACH")
        casino_heist_gunman = stats.get_int("MPX_H3OPT_CREWWEAP")
        casino_heist_driver = stats.get_int("MPX_H3OPT_CREWDRIVER")
        casino_heist_hacker = stats.get_int("MPX_H3OPT_CREWHACKER")
        casino_heist_weapons = stats.get_int("MPX_H3OPT_WEAPS")
        casino_heist_cars = stats.get_int("MPX_H3OPT_VEHS")
        casino_heist_masks = stats.get_int("MPX_H3OPT_MASKS")
    end
    if HUD.IS_PAUSE_MENU_ACTIVE() then
        PAD.DISABLE_CONTROL_ACTION(0, 348, true)
        PAD.DISABLE_CONTROL_ACTION(0, 204, true)
    end
    if fm_mission_controller_cart_autograb then
        if locals.get_int("fm_mission_controller", fm_mission_controller_cart_grab) == 3 then
            locals.set_int("fm_mission_controller", fm_mission_controller_cart_grab, 4)
        elseif locals.get_int("fm_mission_controller", fm_mission_controller_cart_grab) == 4 then
            locals.set_float("fm_mission_controller", fm_mission_controller_cart_grab + fm_mission_controller_cart_grab_speed, 2)
        end
    end
end)

casino_gui:add_button("广播消息", function()
    if dealers_card_gui_element:get_value() ~= "Not in Casino." then
        if force_roulette_wheel:is_enabled() then
            network.send_chat_message("[赌场钻机]: 确保您拥有赌场顶层公寓，或者您是 CEO 的 CEO，并且您在玩之前拥有 50k+ 筹码!")
            network.send_chat_message("[赌场钻机]: 轮盘赌桌在赌场纵！ 来赌场轻松赚钱!")
        else
            gui.show_message("错误", "轮盘装备未启用，请先启用!")
        end
    else
        gui.show_message("错误", "您需要在赌场靠近桌子才能使用它")
    end
end)
casino_gui:add_sameline()
casino_gui:add_button("如何下注", function()
    if dealers_card_gui_element:get_value() ~= "目前不在赌场" then
        if force_roulette_wheel:is_enabled() then
            if casVal == -1 then 
                local casVal = "00"
                network.send_chat_message("[赌场钻机]: 最大化你的赌注，投入 1 个筹码 "..casVal.." 然后将尽可能多的筹码堆叠在与中奖号码同一行的相应“2 比 1”上")
            else
                network.send_chat_message("[赌场钻机]: 最大化你的赌注，投入 1 个筹码 "..casVal.." 然后将尽可能多的筹码堆叠在与中奖号码同一行的相应“2 比 1”上")
            end
        else
            gui.show_message("错误", "轮盘装备未启用，请先启用!")
        end
    else
        gui.show_message("Error", "You need to be in the casino near the tables to use this")
    end
end)
casino_gui:add_sameline()
casino_gui:add_button("Alt Betting Info", function()
    if dealers_card_gui_element:get_value() ~= "目前不在赌场" then
        if force_roulette_wheel:is_enabled() then
            network.send_chat_message("[赌场钻机]: 您可以选择将尽可能多的筹码堆叠在与中奖号码同一行的“1st 12、2nd 12 或 3rd 12”上，而不是“2 比 1”")
        else
            gui.show_message("错误", "轮盘赌装备未启用，请先启用它！")
        end
    else
        gui.show_message("错误", "您需要在赌场靠近桌子才能使用它")
    end
end)

casino_gui:add_separator()
casino_gui:add_text("除老虎机装备外，所有东西都适合所有人.")
-- Instant Money Loops - Pessi v2
local TransactionManager <const> = {};
TransactionManager.__index = TransactionManager

function TransactionManager:New()
    local self = setmetatable({}, TransactionManager);
-- hashes for other loops in case you wanted to change the ones I added, or add more options.
    self.m_transactions = {
        {label = "15M (Bend Job Limited)", hash = 0x176D9D54},
        {label = "15M (Bend Bonus Limited)", hash = 0xA174F633},
        {label = "7M (Gang Money Limited)", hash = 0xED97AFC1},
        {label = "3.6M (Casino Heist Money Limited)", hash = 0xB703ED29},
        {label = "2.5M (Gang Money Limited)", hash = 0x46521174},
        {label = "2.5M (Island Heist Money Limited)", hash = 0xDBF39508},
        {label = "2M (Heist Awards Money Limited)", hash = 0x8107BB89},
        {label = "2M (Tuner Robbery Money Limited)", hash = 0x921FCF3C},
        {label = "2M (Business Hub Money Limited)", hash = 0x4B6A869C},
        {label = "1M (Avenger Operations Money Limited)", hash = 0xE9BBC247},
        {label = "1M (Daily Objective Event Money Limited)", hash = 0x314FB8B0},
        {label = "1M (Daily Objective Money Limited)", hash = 0xBFCBE6B6},
        {label = "680K (Betting Money Limited)", hash = 0xACA75AAE},
        {label = "500K (Juggalo Story Money Limited)", hash = 0x05F2B7EE},
        {label = "310K (Vehicle Export Money Limited)", hash = 0xEE884170},
        {label = "200K (DoomsDay Finale Bonus Money Limited)", hash = 0xBA16F44B},
        {label = "200K (Action Figures Money Limited)",  hash = 0x9145F938},
        {label = "200K (Collectibles Money Limited)",    hash = 0xCDCF2380},
        {label = "190K (Vehicle Sales Money Limited)",   hash = 0xFD389995}
    }

    return self;
end

function TransactionManager:GetPrice(hash, category)
    return tonumber(NETSHOPPING.NET_GAMESERVER_GET_PRICE(hash, category, true))
end

function TransactionManager:TriggerTransaction(hash, amount)
    globals.set_int(4537212 + 1, 2147483646)
    globals.set_int(4537212 + 7, 2147483647)
    globals.set_int(4537212 + 6, 0)
    globals.set_int(4537212 + 5, 0)
    globals.set_int(4537212 + 3, hash)
    globals.set_int(4537212 + 2, amount or self:GetPrice(hash, 0x57DE404E))
    globals.set_int(4537212, 1)
end

local millLoop = Money:add_tab("循环刷钱")
millLoop:add_text("金钱循环（严重风险!)")
local oneMillLoop = millLoop:add_checkbox("1百万 循环")
script.register_looped("onemLoop", function(script)
    script:yield()
    if oneMillLoop:is_enabled() == true then
        onemLoop = not onemLoop
        if onemLoop then
            TransactionManager:TriggerTransaction(0x615762F1)
                script:yield();
            gui.show_message("金钱循环", "1百万循环运行，享受轻松赚钱!")
        end
    end
end)
toolTip(millLoop, "运行一个 $1,000,000 的循环，将运行到停用为止，不会增加收入或总收入.")
millLoop:add_sameline()
local twofiveMillLoop = millLoop:add_checkbox("2.5百万 循环")
script.register_looped("twofmLoop", function(script)
    script:yield()
    if twofiveMillLoop:is_enabled() == true then
        twofmLoop = not twofmLoop
        if twofmLoop then
            TransactionManager:TriggerTransaction(0xDBF39508)
                script:yield();
            gui.show_message("金钱循环", "2.5 磨机循环运行，享受轻松赚钱!")
        end
    end
end)
toolTip(millLoop, "运行一个 $2,500,000 的循环，（似乎没有循环）")
millLoop:add_sameline()
local threeSixMillLoop = millLoop:add_checkbox("3.6百万循环")
script.register_looped("threesmLoop", function(script)
    script:yield()
    if threeSixMillLoop:is_enabled() == true then
        threesmLoop = not threesmLoop
        if threesmLoop then
            TransactionManager:TriggerTransaction(0xB703ED29)
                script:yield();
            gui.show_message("金钱循环", "3.6百万循环运行，享受轻松赚钱!")
        end
    end
end)
toolTip(millLoop, "运行一个 $3,600,000 的循环，（似乎没有循环）")
millLoop:add_sameline()
local sevenMillLoop = millLoop:add_checkbox("7百万循环")
script.register_looped("sevenmLoop", function(script)
    script:yield()
    if sevenMillLoop:is_enabled() == true then
        sevenmLoop = not sevenmLoop
        if sevenmLoop then
            TransactionManager:TriggerTransaction(0xED97AFC1)
                script:yield();
            gui.show_message("金钱循环", "7百万循环运行，享受轻松赚钱!")
        end
    end
end)
toolTip(millLoop, "运行一个 $7,000,000 的循环，（似乎没有循环）")
millLoop:add_sameline()
local fifteenMillLoop = millLoop:add_checkbox("1千5百万循环")
script.register_looped("fifteenMLoop", function(script)
    script:yield()
    if fifteenMillLoop:is_enabled() == true then
        fifteenMLoop = not fifteenMLoop
        if fifteenMLoop then
            TransactionManager:TriggerTransaction(0x176D9D54)
                script:yield();
            gui.show_message("金钱循环", "15磨机循环运行，享受轻松赚钱!")
        end
    end
end)
toolTip(millLoop, "运行一个 15,000,000 美元的循环，（似乎有时会循环，或者在某些战局中循环？")

moneyRemover = Money:add_tab("卸钱器")

removerInput = moneyRemover:add_input_int("重装防护装备")

moneyRemover:add_button("设定金额", function()
    if removerInput:get_value() <= 500 then
        gui.show_error("卸钱器", "金额必须大于 500")
    else
        globals.set_int(262145 + 20498, removerInput:get_value())
        gui.show_message("卸钱器", "成功设定金额")
    end
end)
toolTip(moneyRemover, "将弹道装备价格设置为上述值，设置后，在互动菜单中购买重装装备")
toolTip(moneyRemover, "'健康和弹药 ->弹道设备服务 ->请求弹道设备'")

-- Object Spawner (Can be used negatively!) (Originally from Kuter Menu)

-- Function to convert object names to hashes using joaat()
local function getObjectHashes(names)
    local hashes = {}
    for _, name in ipairs(names) do
        local hash = joaat(name)
        table.insert(hashes, hash)
    end
    return hashes
end

-- Get object hashes
local objectHashes = getObjectHashes(objectNames)

local Obje = KAOS:add_tab("对象选项")
local Objets = Obje:add_tab("生成器")

local orientationPitch = 0
local orientationYaw = 0
local orientationRoll = 0
local spawnDistance = { x = 0, y = 0, z = 0 }
local defaultOrientationPitch = 0
local defaultOrientationYaw = 0
local defaultOrientationRoll = 0
local defaultSpawnDistance = { x = 0, y = 0, z = 0 }

local defaultObjSpawnDistance = 3.0  -- Adjust this distance as needed
local objSpawnDistance = 3.0  -- Adjust this distance as needed

local previewAlpha = 175
local defaultPreviewAlpha = 175

-- Function to reset sliders to default values
local function resetSliders()
    orientationPitch = defaultOrientationPitch
    orientationYaw = defaultOrientationYaw
    orientationRoll = defaultOrientationRoll
    spawnDistance.x = defaultSpawnDistance.x
    spawnDistance.y = defaultSpawnDistance.y
    spawnDistance.z = defaultSpawnDistance.z
    objSpawnDistance = defaultObjSpawnDistance
    previewAlpha = defaultPreviewAlpha
end

--[[
---@class Preview
Preview = {handle = 0, modelHash = 0}
Preview.__index = Preview

---@param modelHash Hash
---@return Preview
function Preview.new(modelHash)
    local self = setmetatable({}, Preview)
    self.modelHash = modelHash
    return self
end

---@param pos v3
function Preview:create(pos, heading)
    if self:exists() then return end
    self.handle = VEHICLE.CREATE_VEHICLE(self.modelHash, pos.x, pos.y, pos.z, heading, false, false, false)
    ENTITY.SET_ENTITY_ALPHA(self.handle, 153, true)
    ENTITY.SET_ENTITY_COLLISION(self.handle, false, false)
    ENTITY.SET_CAN_CLIMB_ON_ENTITY(self.handle, false)
end--]]

Objets:add_imgui(function()
    orientationPitch, used = ImGui.SliderInt("俯仰", orientationPitch, 0, 360)
    toolTip("", "改变物体的俯仰（侧向轴）")
    orientationYaw, used = ImGui.SliderInt("偏航", orientationYaw, 0, 360)
    toolTip("", "改变物体的偏航（垂直轴）")
    orientationRoll, used = ImGui.SliderInt("翻滚", orientationRoll, 0, 360)
    toolTip("", "改变物体的翻滚（前后轴）")
end)

Objets:add_imgui(function()
    spawnDistance.x, used = ImGui.SliderFloat("生成距离 X", spawnDistance.x, -25, 25)
    toolTip("", "改变物体生成的 X 坐标（左右取决于你面对的方向）")
    spawnDistance.y, used = ImGui.SliderFloat("生成距离 Y", spawnDistance.y, -25, 25)
    toolTip("", "改变物体生成的 Y 坐标（前后取决于你面对的方向）")
    spawnDistance.z, used = ImGui.SliderFloat("生成距离 Z", spawnDistance.z, -25, 25)
    toolTip("", "改变物体生成的 Z 坐标（上下）")
    objSpawnDistance, sdChanged = ImGui.SliderFloat("距离", objSpawnDistance, 0, 25)
    toolTip("", "物体与玩家之间的距离")
end)

Objets:add_imgui(function()
    previewAlpha, alphaChanged = ImGui.SliderInt("预览 Alpha 版", previewAlpha, 0, 255)
end)

-- Save default values
defaultOrientationPitch = orientationPitch
defaultOrientationYaw = orientationYaw
defaultOrientationRoll = orientationRoll
defaultSpawnDistance.x = spawnDistance.x
defaultSpawnDistance.y = spawnDistance.y
defaultSpawnDistance.z = spawnDistance.z

-- Reset Sliders button
Objets:add_button("重置滑块", function()
    resetSliders()
end)
toolTip(Objets, "将定位滑块重置为默认值")

Objets:add_separator()
-- Objects hashes/names, add to this list (top of file) to have more objects in your listbox on YimMenu
local adultesItems = {}

for i, hash in ipairs(objectHashes) do
    table.insert(adultesItems, { hash = hash, nom = objectNames[i] })
end

local selectedObjectIndex = 0

Objets:add_text("对象生成器")

-- Add search input field
local searchQuery = ""
Objets:add_imgui(function()
    if is_typing then
        PAD.DISABLE_ALL_CONTROL_ACTIONS(0)
    end
    searchQuery, used = ImGui.InputText("搜索对象", searchQuery, 128)
     if ImGui.IsItemActive() then
        is_typing = true
    else
        is_typing = false
    end
end)
toolTip(Objets, "搜索要生成的对象（例如：容器或笼子)")

local filteredItems = {}

-- Function to update filtered items based on search query
local function updateFilteredItems()
    filteredItems = {}
    for _, item in ipairs(adultesItems) do
        if string.find(string.lower(item.nom), string.lower(searchQuery)) then
            table.insert(filteredItems, item)
        end
    end
end

-- Function to display the filtered list
local function displayFilteredList()
    updateFilteredItems()

    local itemNames = {}
    for _, item in ipairs(filteredItems) do
        table.insert(itemNames, item.nom)
    end
    selectedObjectIndex, used = ImGui.ListBox("", selectedObjectIndex, itemNames, #filteredItems)
end

Objets:add_imgui(displayFilteredList)

Objets:add_separator()

spawnedObjects = {}
names = {}

previewObjects = Objets:add_checkbox("预览")
toolTip(Objets, "在生成对象之前显示对象的预览")

previewSpawned = false

previewObject = nil

previousPreview = nil

script.register_looped("objectsPreview", function()
    if not Objets:is_selected() then
        previewObjects:set_enabled(false)
    end
    if previewObjects:is_enabled() then
        local selectedObjectInfo = filteredItems[selectedObjectIndex + 1]
        if selectedObjectInfo then
            -- Get the player's ped handle
            local playerPed = PLAYER.GET_PLAYER_PED(network.get_selected_player())

            -- Get the player's current position and orientation
            local playerPos = ENTITY.GET_ENTITY_COORDS(playerPed, true)
            local playerHeading = ENTITY.GET_ENTITY_HEADING(playerPed)
            local forwardVector = ENTITY.GET_ENTITY_FORWARD_VECTOR(playerPed)

            -- Calculate the spawn distance and offset
            local spawnOffsetX = objSpawnDistance * forwardVector.x
            local spawnOffsetY = objSpawnDistance * forwardVector.y

            -- Calculate the spawn position based on the offset
            local spawnX = playerPos.x + spawnOffsetX
            local spawnY = playerPos.y + spawnOffsetY
            local spawnZ = playerPos.z  -- Adjust the height if needed

            -- Spawn the object at the calculated position
            local objectHash = selectedObjectInfo.hash  -- Replace with the object hash or model name
            while not STREAMING.HAS_MODEL_LOADED(objectHash) do
                STREAMING.REQUEST_MODEL(objectHash)
                coroutine.yield()
            end
            if previewObject ~= objectHash and previewObject ~= nil then
                delete_entity(previewObject)
                previewSpawned = false
            end
            if not previewSpawned then
                local spawnedObject = OBJECT.CREATE_OBJECT(objectHash, spawnX, spawnY, spawnZ, true, true, false)
                ENTITY.SET_ENTITY_AS_NO_LONGER_NEEDED(spawnedObject)
                ENTITY.SET_ENTITY_ROTATION(spawnedObject, 0, 0, playerHeading, 2, true)  -- Adjust rotation if needed
                ENTITY.SET_ENTITY_ALPHA(spawnedObject, 175, true)
                ENTITY.SET_ENTITY_COLLISION(spawnedObject, false, false)
                ENTITY.SET_CAN_CLIMB_ON_ENTITY(spawnedObject, false)
                previewSpawned = true
                previewObject = spawnedObject
            end
            ENTITY.SET_ENTITY_COORDS(previewObject, spawnX + spawnDistance.x, spawnY + spawnDistance.y, spawnZ + spawnDistance.z, true, false, false, false)
            ENTITY.SET_ENTITY_ROTATION(previewObject, orientationRoll, orientationYaw, playerHeading + orientationPitch, 2, true)
            ENTITY.SET_ENTITY_ALPHA(previewObject, previewAlpha, true)
            --gui.show_message("Preview", "Moved ".. selectedObjectInfo.nom.. " to ".. tostring(spawnX).. ", ".. tostring(spawnY))
            previousPreview = objectHash
        else
            gui.show_message("对象生成器", "未找到所选对象.")
        end
    else
        if previewObject ~= nil then if ENTITY.DOES_ENTITY_EXIST(previewObject) then delete_entity(previewObject) end end
        previewSpawned = false
        previewObject = nil
        previousPreview = nil
    end
end)

Objets:add_sameline()

Objets:add_imgui(function()
    --objSpawnDistance, sdChanged = ImGui.SliderFloat("Distance", objSpawnDistance, 0, 25)
end)

Objets:add_button("生成选定的", function()
    script.run_in_fiber(function()
        local selectedObjectInfo = filteredItems[selectedObjectIndex + 1]
        if selectedObjectInfo then
            -- Get the player's ped handle
            local playerPed = PLAYER.GET_PLAYER_PED(network.get_selected_player())
            playerName = PLAYER.GET_PLAYER_NAME(network.get_selected_player())

            -- Get the player's current position and orientation
            local playerPos = ENTITY.GET_ENTITY_COORDS(playerPed, true)
            local playerHeading = ENTITY.GET_ENTITY_HEADING(playerPed)
            local forwardVector = ENTITY.GET_ENTITY_FORWARD_VECTOR(playerPed)

            -- Calculate the spawn distance and offset
            local spawnOffsetX = objSpawnDistance * forwardVector.x
            local spawnOffsetY = objSpawnDistance * forwardVector.y

            -- Calculate the spawn position based on the offset
            local spawnX = playerPos.x + spawnOffsetX
            local spawnY = playerPos.y + spawnOffsetY
            local spawnZ = playerPos.z - 1.15  -- Adjust the height if needed

            -- Spawn the object at the calculated position
            local objectHash = selectedObjectInfo.hash  -- Replace with the object hash or model name
            while not STREAMING.HAS_MODEL_LOADED(objectHash) do
                STREAMING.REQUEST_MODEL(objectHash)
                coroutine.yield()
            end
            local spawnedObject = OBJECT.CREATE_OBJECT(objectHash, spawnX + spawnDistance.x, spawnY + spawnDistance.y, spawnZ + spawnDistance.z, true, true, false)
            ENTITY.SET_ENTITY_ROTATION(spawnedObject, orientationRoll, orientationYaw, playerHeading + orientationPitch, 2, true)  -- Adjust rotation if needed
            --gui.show_message("Preview", "Moved ".. selectedObjectInfo.nom.. " to ".. tostring(spawnX).. ", ".. tostring(spawnY))
            local net_id = NETWORK.OBJ_TO_NET(spawnedObject)
            NETWORK.SET_NETWORK_ID_EXISTS_ON_ALL_MACHINES(net_id, true)
            gui.show_message("对象生成器", "生成的对象 "..selectedObjectInfo.nom.." 上 "..playerName)
            ENTITY.SET_ENTITY_AS_NO_LONGER_NEEDED(spawnedObject)
            table.insert(spawnedObjects, spawnedObject)
            table.insert(names, selectedObjectInfo.nom)
        else
            gui.show_message("对象生成器", "未找到所选对象.")
        end
    end)
end)
toolTip(Objets, "在所选玩家位置上生成所选物品，如果没有玩家作为目标，它就会在你身上生成")

objects = 0

Objets:add_imgui(function()
    for i, object in ipairs(spawnedObjects) do
        if not ENTITY.DOES_ENTITY_EXIST(object) then
            delete_entity(object)
            table.remove(spawnedObjects, i)
            table.remove(names, i)
        end
    end
    if #names == 0 then
        objects = ImGui.Combo("", 0, {"空"}, 1)
        toolTip("", "生成的对象将在这里")
    else
        objects = ImGui.Combo("", objects, names, #names)
        toolTip("", "生成对象列表")
        gui.show_message("生成的对象", tostring(objects).. " + ".. tostring(names[objects + 1]).. " ".. ENTITY.GET_ENTITY_MODEL(spawnedObjects[objects + 1]))
    end
    ImGui.SameLine()
    if ImGui.Button("删除") then
        gui.show_message("删除", "删除 ".. spawnedObjects[objects + 1])
        delete_entity(spawnedObjects[objects + 1])
        table.remove(spawnedObjects, objects + 1)
        table.remove(names, objects + 1)
        --if names[objects] == nil then objects = objects - 1 end
    end
    if #spawnedObjects ~= 0 then toolTip("", "删除此生成的对象") else toolTip("", "删除生成的对象") end
    if #names > 0 then
        objLoc = ENTITY.GET_ENTITY_COORDS(spawnedObjects[objects + 1], false)
        rot = ENTITY.GET_ENTITY_ROTATION(spawnedObjects[objects + 1], 2)
        objLocX, objLocY, objLocZ = objLoc.x, objLoc.y, objLoc.z
        roll, pitch, yaw = rot.x, rot.y, rot.z
        objLocX, xChanged = ImGui.SliderFloat("X", objLocX, objLocX - 1, objLocX + 1)
        if xChanged then
            ENTITY.SET_ENTITY_COORDS(spawnedObjects[objects + 1], objLocX, objLoc.y, objLoc.z, true, false, false, false)
        end
        objLocY, yChanged = ImGui.SliderFloat("Y", objLocY, objLocY - 1, objLocY + 1)
        if yChanged then
            ENTITY.SET_ENTITY_COORDS(spawnedObjects[objects + 1], objLoc.x, objLocY, objLoc.z, true, false, false, false)
        end
        objLocZ, zChanged = ImGui.SliderFloat("Z", objLocZ, objLocZ - 1, objLocZ + 1)
        if zChanged then
            ENTITY.SET_ENTITY_COORDS(spawnedObjects[objects + 1], objLoc.x, objLoc.y, objLocZ, true, false, false, false)
        end
        pitch, pitchChanged = ImGui.SliderFloat("俯仰 ", pitch, -180, 180)
        if pitchChanged then
            ENTITY.SET_ENTITY_ROTATION(spawnedObjects[objects + 1], rot.x, pitch, rot.z, 2, false)
        end
        yaw, yawChanged = ImGui.SliderFloat("偏航 ", yaw, -180, 180)
        if yawChanged then
            ENTITY.SET_ENTITY_ROTATION(spawnedObjects[objects + 1], rot.x, rot.y, yaw, 2, false)
        end
        roll, rollChanged = ImGui.SliderFloat("翻滚 ", roll, -180, 180)
        if rollChanged then
            ENTITY.SET_ENTITY_ROTATION(spawnedObjects[objects + 1], roll, rot.y, rot.z, 2, false)
        end
    end
end)

-- Vehicle Options Tab
local Veh = KAOS:add_tab("车辆选项")

-- Vehicle Spawner
local vSpawn = Veh:add_tab("车辆生成")

-- Orientation sliders and Spawn X Y Z sliders
local orientationPitch = 0
local orientationYaw = 0
local orientationRoll = 0
local spawnDistance = { x = 0, y = 0, z = -1 }
local defaultOrientationPitch = 0
local defaultOrientationYaw = 0
local defaultOrientationRoll = 0
local defaultSpawnDistance = { x = 0, y = 0, z = -1 }


-- Function to reset sliders to default values
local function resetVehicleSliders()
    orientationPitch = defaultOrientationPitch
    orientationYaw = defaultOrientationYaw
    orientationRoll = defaultOrientationRoll
    spawnDistance.x = defaultSpawnDistance.x
    spawnDistance.y = defaultSpawnDistance.y
    spawnDistance.z = defaultSpawnDistance.z
end

vSpawn:add_imgui(function()
    orientationPitch, _ = ImGui.SliderInt("俯仰", orientationPitch, 0, 360)
    toolTip("", "改变车辆的俯仰（侧向轴）")
    orientationYaw, _ = ImGui.SliderInt("偏航", orientationYaw, 0, 360)
    toolTip("", "改变车辆的偏航（垂直轴）")
    orientationRoll, _ = ImGui.SliderInt("翻滚", orientationRoll, 0, 360)
    toolTip("", "改变车辆的翻滚（前后轴）")
end)

vSpawn:add_imgui(function()
    spawnDistance.x, _ = ImGui.SliderFloat("生成距离 X", spawnDistance.x, -25, 25)
    toolTip("", "改变对象生成的 X 坐标（左右取决于你面对的方向）")
    spawnDistance.y, _ = ImGui.SliderFloat("生成距离 Y", spawnDistance.y, -25, 25)
    toolTip("", "改变对象生成的 Y 坐标（前后取决于你面对的方向）")
    spawnDistance.z, _ = ImGui.SliderFloat("生成距离 Z", spawnDistance.z, -25, 25)
    toolTip("", "改变对象生成的 Z 坐标（上下）")
end)

-- Save default values
defaultOrientationPitch = orientationPitch
defaultOrientationYaw = orientationYaw
defaultOrientationRoll = orientationRoll
defaultSpawnDistance.x = spawnDistance.x
defaultSpawnDistance.y = spawnDistance.y
defaultSpawnDistance.z = spawnDistance.z

-- Reset Sliders button
vSpawn:add_button("重置滑块", function()
    resetVehicleSliders()
end)
toolTip(vSpawn, "将滑块重置为默认值")
vSpawn:add_separator()

-- Function to spawn the vehicle with specified orientation and spawn position
function spawn_vehicle_with_orientation(vehicle_joaat, pos, pitch, yaw, roll)
    script.run_in_fiber(function (script)
        local load_counter = 0
        while STREAMING.HAS_MODEL_LOADED(vehicle_joaat) == false do
            STREAMING.REQUEST_MODEL(vehicle_joaat)
            script:yield()
            if load_counter > 100 then
                return
            else
                load_counter = load_counter + 1
            end
        end
        local veh = VEHICLE.CREATE_VEHICLE(vehicle_joaat, pos.x, pos.y, pos.z, yaw, true, true, false)
        -- Set vehicle orientation
        ENTITY.SET_ENTITY_ROTATION(veh, pitch, yaw, roll, 2, true)
        local networkId = NETWORK.VEH_TO_NET(veh)
        if NETWORK.NETWORK_GET_ENTITY_IS_NETWORKED(veh) then
            NETWORK.SET_NETWORK_ID_EXISTS_ON_ALL_MACHINES(networkId, true)
        end
        if endPollution:is_enabled() then
            ENTITY.SET_ENTITY_AS_NO_LONGER_NEEDED(veh) -- only use to cut spawned object/vehicle/ped pollution out of sessions, plans for this eventually.
        end
    end)
end

-- Function to display the list of vehicle models with search functionality
local searchQuery = ""
local filteredVehicleModels = {}

local function updateFilteredVehicleModels()
    filteredVehicleModels = {}
    for _, model in ipairs(vehicleModels) do
        if string.find(string.lower(model), string.lower(searchQuery)) then
            table.insert(filteredVehicleModels, model)
        end
    end
end

local function displayVehicleModelsList()
    updateFilteredVehicleModels()
    local vehicleModelNames = {}
    for _, item in ipairs(filteredVehicleModels) do
        table.insert(vehicleModelNames, vehicles.get_vehicle_display_name(item))
    end
    selectedObjectIndex, _ = ImGui.ListBox("车型", selectedObjectIndex, vehicleModelNames, #vehicleModelNames)
end

-- Add search input field
vSpawn:add_imgui(function()
    if is_typing then
        PAD.DISABLE_ALL_CONTROL_ACTIONS(0)
    end
    searchQuery, _ = ImGui.InputText("搜索车辆", searchQuery, 128)
    if ImGui.IsItemActive() then
        is_typing = true
    else
        is_typing = false
    end
end)
toolTip(vSpawn, "搜索车辆（例如：Adder、Baller、Zentorno)")
vSpawn:add_imgui(displayVehicleModelsList)

-- Add separator
vSpawn:add_separator()

-- Spawn Selected button with orientation and spawn position

vSpawn:add_button("生成选定的", function()
    local selectedModelIndex = selectedObjectIndex + 1
    if selectedModelIndex > 0 then
        local selectedVehicleModel = filteredVehicleModels[selectedModelIndex]
        if selectedVehicleModel then
            local vehicleHash = MISC.GET_HASH_KEY(selectedVehicleModel)
            local selPlayer = network.get_selected_player()
            local targetPlayerPed = PLAYER.GET_PLAYER_PED(selPlayer)
            local playerName = PLAYER.GET_PLAYER_NAME(selPlayer)
            local playerPos = ENTITY.GET_ENTITY_COORDS(targetPlayerPed, false)
            playerPos.x = playerPos.x + spawnDistance.x
            playerPos.y = playerPos.y + spawnDistance.y
            playerPos.z = playerPos.z + spawnDistance.z
            spawn_vehicle_with_orientation(vehicleHash, playerPos, orientationPitch, orientationYaw, orientationRoll)
            gui.show_message("载具生成", "生成 "..vehicles.get_vehicle_display_name(vehicleHash).." 为 "..playerName)
        end
    else
        gui.show_message("载具生成", "请选择车型.")
    end
--end
end)
toolTip(vSpawn, "在所选玩家上生成车辆，如果没有选择玩家，则默认为您")

vSpawn:add_sameline()
local endPollution = vSpawn:add_checkbox("无污染")
endPollution:set_enabled(true)
toolTip(vSpawn, "将实体设置为不再需要以防止不可见车辆的会话污染，仅将其关闭以将汽车赠送给他人")
toolTip(vSpawn, "如果您禁用此功能，请确保使用删除枪“自身>武器>自定义枪（启用）>删除枪”，并在将赠送的汽车驶入车库后将其删除")
-- Vehicle Gift Options

 
function giftVehToPlayer(vehicle, playerId, playerName)
    if RequestControl(vehicle) then
        local netHash = NETWORK.NETWORK_HASH_FROM_PLAYER_HANDLE(playerId)
 
        DECORATOR.DECOR_SET_INT(vehicle, "MPBitset", 8)
        DECORATOR.DECOR_SET_INT(vehicle, "Previous_Owner", netHash)
        DECORATOR.DECOR_SET_INT(vehicle, "Veh_Modded_By_Player", netHash)
        DECORATOR.DECOR_SET_INT(vehicle, "Not_Allow_As_Saved_Veh", 0)
        DECORATOR.DECOR_SET_INT(vehicle, "Player_Vehicle", netHash)
 
        gui.show_message("礼品车成功", "赠送 "..VEHICLE.GET_DISPLAY_NAME_FROM_VEHICLE_MODEL(ENTITY.GET_ENTITY_MODEL(vehicle)).." 给 "..playerName)
    else
        gui.show_message("礼品车辆故障", "未能控制车辆")
    end
end

-- Assuming gui provides a 'show_message' method
local Gif = Veh:add_tab("送礼")
 
-- Assuming gui provides a 'add_button' method
Gif:add_button("礼品车", function()
    local selectedPlayer = network.get_selected_player()
 
    -- Check if a player is selected
    local targetPlayerPed = PLAYER.GET_PLAYER_PED(selectedPlayer)
    local playerName = PLAYER.GET_PLAYER_NAME(selectedPlayer)
 
    if PED.IS_PED_IN_ANY_VEHICLE(targetPlayerPed, true) then
        local targetVehicle = PED.GET_VEHICLE_PED_IS_IN(targetPlayerPed, true)
        giftVehToPlayer(targetVehicle, selectedPlayer, playerName)
        --sleep(5)
        --ENTITY.SET_ENTITY_AS_NO_LONGER_NEEDED(targetVehicle)
    end 
end)
toolTip(Gif, "按照“赠送流程”操作后，向礼品按钮发送垃圾邮件，直到它显示“成功”以赠送车辆.")
Gif:add_sameline()
Gif:add_button("获取车辆统计数据", function()
    local selectedPlayer = network.get_selected_player()
    local targetPlayerPed = PLAYER.GET_PLAYER_PED(selectedPlayer)
 
    if PED.IS_PED_IN_ANY_VEHICLE(targetPlayerPed, true) then
        last_veh = PED.GET_VEHICLE_PED_IS_IN(targetPlayerPed, true)
    end 
 
 
    if last_veh  then 
        local playerName = PLAYER.GET_PLAYER_NAME(selectedPlayer)
        gui.show_message("信息",
            "user :"..PLAYER.GET_PLAYER_NAME(selectedPlayer).."->"..NETWORK.NETWORK_HASH_FROM_PLAYER_HANDLE(selectedPlayer).."->".. joaat(playerName).."\n".. --NETWORK.GET_HASH_KEY(playerName).."\n"..
            " Previous_Owner:"..DECORATOR.DECOR_GET_INT(last_veh , "Previous_Owner").."\n"..
            " Vehicle Model:"..VEHICLE.GET_DISPLAY_NAME_FROM_VEHICLE_MODEL(ENTITY.GET_ENTITY_MODEL(last_veh)).."\n"..
            " Player_Vehicle:"..DECORATOR.DECOR_GET_INT(last_veh , "Player_Vehicle").."\n"..
            " MPBitset:"..DECORATOR.DECOR_GET_INT(last_veh , "MPBitset").."\n"..
            " Veh_Modded_By_Player:"..DECORATOR.DECOR_GET_INT(last_veh , "Veh_Modded_By_Player").."\n"..
            " Not_Allow_As_Saved_Veh:"..DECORATOR.DECOR_GET_INT(last_veh , "Not_Allow_As_Saved_Veh"))
    end  
end)
toolTip(Gif, "检查以确保车辆统计数据符合要求（开发测试按钮）)")
Gif:add_separator()
Gif:add_button("如何赠送车辆（将鼠标悬停在工具提示处!)", function()

end)
toolTip(Gif, "要赠送车辆，请确保所有玩家的车辆都已修复/归还，并且车库已满")
toolTip(Gif, "让他们进入满车库，开出一辆车，然后再开回车库，然后步行出来")
toolTip(Gif, "使用附加功能的车辆生成器生成车辆（取消勾选无污染框！），可选择进入并使用 Yim 的 LS 定制选项卡对其进行定制（不要按下 '启动 汽车改装店!'）")
toolTip(Gif, "完成后，请下车，让他们上车，然后不断点击赠送车辆按钮，直到右上角显示 '成功'")
toolTip(Gif, "注意：赠送的车辆应该是全保险的，请确保他们在 汽车改装店 中检查它！")
local tokyodrift = Veh:add_tab("Tokyo 漂移")
script.register_looped("playerID", function(playerID)
    if NETWORK.NETWORK_IS_SESSION_ACTIVE() then
        is_online = true
        onlinePed = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(PLAYER.PLAYER_ID())
    else
        is_online = false
        spPed = self.get_ped()
    end
    if is_online then
        ped = onlinePed
    else
        ped = spPed
    end
    current_vehicle = PED.GET_VEHICLE_PED_IS_USING(ped)
    is_car = VEHICLE.IS_THIS_MODEL_A_CAR(ENTITY.GET_ENTITY_MODEL(current_vehicle))
    playerID:yield()
end)
local ShiftDrift = false
local DriftIntensity = 0
local DriftTires = false
local function resettokyodrift()
    DriftTires = false
    ShiftDrift = false
    DriftIntensity = 0
    shiftDriftToggled = false
end
tokyodrift:add_imgui(function()
manufacturer = VEHICLE.GET_MAKE_NAME_FROM_VEHICLE_MODEL(ENTITY.GET_ENTITY_MODEL(current_vehicle))
mfr_name = (manufacturer:lower():gsub("^%l", string.upper))
vehicle_name = vehicles.get_vehicle_display_name(ENTITY.GET_ENTITY_MODEL(current_vehicle))
    if PED.IS_PED_IN_ANY_VEHICLE(ped, true) and is_car then
        ImGui.Text("车辆: "..mfr_name.." "..vehicle_name)
        ImGui.Spacing()
        ShiftDrift, shiftDriftToggled = ImGui.Checkbox("激活 Tokyo 漂移", ShiftDrift, true)
        ImGui.SameLine()
        ImGui.TextDisabled("(?)")
        if ImGui.IsItemHovered() then
            ImGui.BeginTooltip()
            ImGui.Text("按住[左shift]键可漂移")
            ImGui.EndTooltip()
        end
        if shiftDriftToggled then
            if not ShiftDrift then
                DriftTires = false
            end
        end
        DriftTires, driftTyresToggled = ImGui.Checkbox("使用低抓地力轮胎", DriftTires, true)
        ImGui.SameLine()
        ImGui.TextDisabled("(?)")
        if ImGui.IsItemHovered() then
            ImGui.BeginTooltip()
            ImGui.Text("这将使用 GTA 5 的低抓地力轮胎.")
            ImGui.EndTooltip()
        end
        if not DriftTires then
            ImGui.Spacing()
            ImGui.Text("强度:")
            DriftIntensity, DriftIntensityUsed = ImGui.SliderInt("", DriftIntensity, 0, 3)
            if ImGui.IsItemHovered() then
                ImGui.BeginTooltip()
                ImGui.Text("0：无抓地力（非常僵硬）。\n1：平衡（推荐）。\n2：弱漂移。\n3：最弱漂移.")
                ImGui.EndTooltip()
            end
        end
    elseif PED.IS_PED_IN_ANY_VEHICLE(ped, true) and not is_car then
        ImGui.Text("Tokyo 漂移仅适用于汽车和卡车.\n"..current_vehicle)
    else
        ImGui.Text("在使用脚本之前先上车！")
    end
    ImGui.Spacing() ImGui.Spacing() ImGui.Spacing() ImGui.Spacing() ImGui.Spacing() ImGui.Spacing()
    ImGui.Separator()
    if ImGui.Button("-- 功能作者 --") then
        ImGui.OpenPopup("功能作者")
    end
    ImGui.SetNextWindowPos(600, 400, ImGuiCond.Appearing)
    ImGui.SetNextWindowBgAlpha(0.6)
    if ImGui.BeginPopupModal("功能作者", true, ImGuiWindowFlags.AlwaysAutoResize | ImGuiWindowFlags.NoMove) then
        ImGui.Text("原始脚本 [Shift-Drift]，由 Harmless05 制作\n并由 SAMURAI （xesdoog).")
        ImGui.Text("访问 Harmless 在 Github 上的个人资料:")
        ImGui.Indent()
        ImGui.TextColored(0.25, 0.65, 0.96, 0.8, "https://github.com/Harmless05")
        ImGui.Unindent()
        if ImGui.IsItemHovered() then
            ImGui.BeginTooltip()
            ImGui.Text("点击复制链接")
            ImGui.EndTooltip()
        end
        if ImGui.IsItemHovered() and ImGui.IsItemClicked(0) then
            ImGui.SetClipboardText("https://github.com/Harmless05")
            gui.show_message("Tokyo 漂移", "Copied \"https://github.com/Harmless05\" to clipboard!")
            log.info("Copied \"https://github.com/Harmless05\" to clipboard!")
        end
        -- ImGui.Text("Checkout Harmless-Scripts:")
        -- ImGui.BulletText("https://github.com/YimMenu-Lua/Harmless-Scripts")
        -- if ImGui.IsItemHovered() then
        --     ImGui.BeginTooltip()
        --     ImGui.Text("Click to copy link")
        --     ImGui.EndTooltip()
        -- end
        -- if ImGui.IsItemHovered() and ImGui.IsItemClicked(0) then
        --     ImGui.SetClipboardText("https://github.com/YimMenu-Lua/Harmless-Scripts")    <-- Crashes my game for some reason! The profile link is fine but clicking the YimMenu-Lua repo link crashes my game???🤨
        --     gui.show_message("TokyoDrift Credits", "Copied \"https://github.com/YimMenu-Lua/Harmless-Scripts\" to clipboard!")
        -- end
        ImGui.EndPopup()
    end
end)
event.register_handler(menu_event.MenuUnloaded, function()
 resettokyodrift()
end)
event.register_handler(menu_event.ScriptsReloaded, function()
 resettokyodrift()
end)
script.register_looped("Drift Loop", function(script)
    script:yield()
    if is_car and DriftTires and PAD.IS_CONTROL_PRESSED(0, 21) then
        VEHICLE.SET_DRIFT_TYRES(current_vehicle, true)
    else
        VEHICLE.SET_DRIFT_TYRES(current_vehicle, false)
    end
    script:yield()
    if is_car and ShiftDrift and PAD.IS_CONTROL_PRESSED(0, 21) and not DriftTires then
        VEHICLE.SET_VEHICLE_REDUCE_GRIP(current_vehicle, true)
        VEHICLE.SET_VEHICLE_REDUCE_GRIP_LEVEL(current_vehicle, DriftIntensity)
    else
        VEHICLE.SET_VEHICLE_REDUCE_GRIP(current_vehicle, false)
    end
end)
 -- Global Player Options
 
 local Global = KAOS:add_tab("全局")
 
 -- Global RP Loop Options
 local PRGBGLoop = false
 Global:add_text("全局 友好的选项")
 rpLoop = Global:add_checkbox("给予 RP (开/关)")
 
     script.register_looped("PRGBGLoop", function()
     if rpLoop:is_enabled() == true then
         local model = joaat("vw_prop_vw_colle_prbubble")
         local pickup = joaat("PICKUP_CUSTOM_SCRIPT")
         local money_value = 0
         gui.show_message("警告", "15 名或更多玩家可能会导致延迟或 RP 不下降.")
         STREAMING.REQUEST_MODEL(model)
         while STREAMING.HAS_MODEL_LOADED(model) == false do
             sleep(1)
         end
     
         if STREAMING.HAS_MODEL_LOADED(model) then
             local localPlayerId = PLAYER.PLAYER_ID()
             local player_count = PLAYER.GET_NUMBER_OF_PLAYERS() - 1 -- Minus 1 player (yourself) from the drop count.
             gui.show_message("全局", "将小雕像放到 ".. player_count.." 战局中的玩家.")
 
             for i = 0, 31 do
                 if i ~= localPlayerId then
                     local player_id = i
                     
                     local coords = ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(player_id), true)
                     local objectIdSpawned = OBJECT.CREATE_AMBIENT_PICKUP(
                         pickup,
                         coords.x - 0,
                         coords.y + 0,
                         coords.z + 0.4,
                         3,
                         money_value,
                         model,
                         true,
                         false
                     )
                     ENTITY.SET_ENTITY_VISIBLE(objectIdSpawned, true, false)
                     local net_id = NETWORK.OBJ_TO_NET(objectIdSpawned)
                     NETWORK.SET_NETWORK_ID_EXISTS_ON_ALL_MACHINES(objectIdSpawned, true)
                     
                     ENTITY.SET_ENTITY_AS_NO_LONGER_NEEDED(objectIdSpawned)
                 end
             end
         end
         --sleep(0.2) -- Sets the timer in seconds for how long this should pause before sending another figure
     end
     end)
toolTip(Global, "在整个战局中掉落公主机器人雕像（略有故障）)")
Global:add_sameline()       
local goodRP = Global:add_checkbox("快速RP")
script.register_looped("goodRP", function()
    if goodRP:is_enabled() == true then
        for p = 0, 31 do
            if p ~= PLAYER.PLAYER_ID() then
                for i = 20, 24 do 
                    network.trigger_script_event(1 << p, {968269233 , p, 1, 4, i, 1, 1, 1, 1})
                    local player_count = PLAYER.GET_NUMBER_OF_PLAYERS()
                    gui.show_message("快速RP", "给大量的RP "..player_count.." 战局中的玩家")
                end
            end
        end
    end
end)
toolTip(Global, "用 RP 淹没整个战局（大约每秒 1-3 级）)")
Global:add_sameline()
local goodMoney = Global:add_checkbox("钱")
    script.register_looped("goodMoney", function()
        if goodMoney:is_enabled() == true then
            for i = 0, 31 do
                pid = i
                local localPlayerId = PLAYER.PLAYER_ID()
                if pid ~= localPlayerId then
                    for n = 0, 10 do
                        for l = -10, 10 do
                            network.trigger_script_event(1 << pid, {968269233 , pid, 1, l, l, n, 1, 1, 1})
                            gui.show_message("钱", "给钱（最多 225k）给 "..player_count.." 战局中的玩家")
                        end
                    end
                end
            end
        end
        sleep(0.2)
    end)
toolTip(Global, "应该给整个会话金钱和 rp")
--[[ Global Sound Spam Options -- Temporarily Disabled as it causes you to crash on use
Global:add_separator()
Global:add_text("Sound Spams")
local soundIndex = 0
local isPlaying = false

useLoopedG = false
local useLoopedG = Global:add_checkbox("Loop?")
local searchQuery = ""
local filteredSoundNames = {}
local selectedFilteredSoundIndex = 0

local function updateFilteredSoundNames()
    filteredSoundNames = {}
    for _, sound in ipairs(sounds) do
        if string.find(string.lower(sound.SoundName), string.lower(searchQuery)) then
            table.insert(filteredSoundNames, sound.SoundName)
        end
    end
end

-- Function to display the list of sound names
local function displaySoundNamesList()
    updateFilteredSoundNames()
    if selectedFilteredSoundIndex > #filteredSoundNames then
        selectedFilteredSoundIndex = 0
    end
    selectedFilteredSoundIndex, _ = ImGui.Combo("Select Sound", selectedFilteredSoundIndex, filteredSoundNames, #filteredSoundNames)
end

-- Add search input field and sound selection
Global:add_imgui(function()
    if is_typing then
        PAD.DISABLE_ALL_CONTROL_ACTIONS(0)
    end
    searchQuery, _ = ImGui.InputText("Search Sounds", searchQuery, 128)
    if ImGui.IsItemActive() then
        is_typing = true
    else
        is_typing = false
    end

    displaySoundNamesList()

    if ImGui.Button("Play") then
        isPlaying = true
        local selectedSoundName = filteredSoundNames[selectedFilteredSoundIndex + 1]
        for i = 0, 31 do
            local playerIndex = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(i)
                local selectedSound = sounds[1]
                for _, sound in ipairs(sounds) do
                    if sound.SoundName == selectedSoundName then
                        selectedSound = sound
                        break
                    end
                end
                AUDIO.PLAY_SOUND_FROM_ENTITY(AUDIO.GET_SOUND_ID(), selectedSound.AudioName, playerIndex, selectedSound.AudioRef, true, 999999999)
                gui.show_message("Sound Spam", "Playing "..selectedSound.SoundName.." on the entire session.")
        end
    end
end)


Global:add_sameline()
Global:add_button("Stop Local Sounds", function()
    isPlaying = false
    --for i=-1,100 do
    --local soundId = AUDIO.PLAY_SOUND_FROM_ENTITY(AUDIO.GET_SOUND_ID(), selectedSound.AudioName, playerIndex, selectedSound.AudioRef, true, 999999999)
        AUDIO.STOP_SOUND(soundId)
        AUDIO.RELEASE_SOUND_ID(soundId)
    --end
end)]]

-- Global Particle Effects
Global:add_separator()
Global:add_text("PTFX")
local fireworkLoop = Global:add_checkbox("烟花（开/关）")

function load_fireworks()

    STREAMING.REQUEST_NAMED_PTFX_ASSET("proj_indep_firework")
    
    if not STREAMING.HAS_NAMED_PTFX_ASSET_LOADED("proj_indep_firework") then
        return false
    end
    
    STREAMING.REQUEST_NAMED_PTFX_ASSET("scr_indep_fireworks")
    
    if not STREAMING.HAS_NAMED_PTFX_ASSET_LOADED("scr_indep_fireworks") then
        return false
    end

    return true
end

function random_color()
    return math.random(0, 200), math.random(0, 255), math.random(0, 255)
end

script.register_looped("FireworkLoop", function()
    if fireworkLoop:is_enabled() == true then
        if load_fireworks() then
            local localPlayerId = PLAYER.PLAYER_ID()
            for i = 0, 31 do
                if i ~= localPlayerId then
                    local player_id = i
                    local player_coords = ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(player_id), true)

                    -- Get random color values
                    local colorR, colorG, colorB = random_color()
                    player_coords.z = player_coords.z - 1
                    setExp1 = player_coords.z + 25
                    setExp2 = player_coords.z + 35
                    -- Play the explosion particle effect with random color
                    GRAPHICS.USE_PARTICLE_FX_ASSET("scr_indep_fireworks")
                    GRAPHICS.SET_PARTICLE_FX_NON_LOOPED_COLOUR(colorR, colorG, colorB)
                    GRAPHICS.START_NETWORKED_PARTICLE_FX_NON_LOOPED_AT_COORD("scr_indep_firework_trailburst", player_coords.x, player_coords.y, player_coords.z, 0, 0, 0, math.random(1, 5), false, false, false, false)
                    sleep(0.05)
                    GRAPHICS.USE_PARTICLE_FX_ASSET("proj_indep_firework")
                    GRAPHICS.SET_PARTICLE_FX_NON_LOOPED_COLOUR(colorR, colorG, colorB)
                    GRAPHICS.START_NETWORKED_PARTICLE_FX_NON_LOOPED_AT_COORD("scr_indep_firework_grd_burst", player_coords.x, player_coords.y, setExp1, 0, 0, 0, math.random(1, 5), false, false, false, false)
                    
                    GRAPHICS.USE_PARTICLE_FX_ASSET("proj_indep_firework_v2")
                    GRAPHICS.SET_PARTICLE_FX_NON_LOOPED_COLOUR(colorR, colorG, colorB)
                    GRAPHICS.START_NETWORKED_PARTICLE_FX_NON_LOOPED_AT_COORD("scr_xmas_firework_burst_fizzle", player_coords.x, player_coords.y, setExp2, 0, 0, 0, math.random(1, 5), false, false, false, false)
                end
            end
        end
    end
end)
toolTip(Global, "从战局中的每个玩家那里射出一系列烟花效果")
Global:add_sameline()
local flameLoopGlobal = Global:add_checkbox("火焰（开/关）")
function load_flame()

    STREAMING.REQUEST_NAMED_PTFX_ASSET("scr_bike_adversary")
    
    if not STREAMING.HAS_NAMED_PTFX_ASSET_LOADED("scr_bike_adversary") then
        return false
    end

    return true
end

function random_color()
    return math.random(0, 255), math.random(0, 255), math.random(0, 255)
end

script.register_looped("FlameLoopGlobal", function()
    if flameLoopGlobal:is_enabled() == true then
        if load_flame() then
            local localPlayerId = PLAYER.PLAYER_ID()
            for i = 0, 31 do
                if i ~= localPlayerId then
                    local player_id = i
                    local player_coords = ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(player_id), true)

                    -- Get random color values
                    local colorR, colorG, colorB = random_color()
                    test = player_coords.z - 1
                    GRAPHICS.USE_PARTICLE_FX_ASSET("scr_bike_adversary")
                    GRAPHICS.SET_PARTICLE_FX_NON_LOOPED_COLOUR(colorR, colorG, colorB)
                    GRAPHICS.START_NETWORKED_PARTICLE_FX_NON_LOOPED_AT_COORD("scr_adversary_foot_flames", player_coords.x, player_coords.y, test, 0, 0, 0, 5, false, false, false, false)
                end
            end
            sleep(0.2)
        end
    end
end)
toolTip(Global, "为战局中的每个玩家提供“幽灵骑士”火焰效果")
Global:add_sameline()
local lightningLoopGlobal = Global:add_checkbox("闪电（开/关）")
function load_lightning()

    STREAMING.REQUEST_NAMED_PTFX_ASSET("des_tv_smash")
    
    if not STREAMING.HAS_NAMED_PTFX_ASSET_LOADED("des_tv_smash") then
        return false
    end

    return true
end

function random_color()
    return math.random(0, 255), math.random(0, 255), math.random(0, 255)
end

script.register_looped("lightningLoopGlobal", function()
    if lightningLoopGlobal:is_enabled() == true then
        if load_lightning() then
            local localPlayerId = PLAYER.PLAYER_ID()
            for i = 0, 31 do
                if i ~= localPlayerId then
                    local player_id = i
                    local player_coords = ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(player_id), true)

                    -- Get random color values
                    local colorR, colorG, colorB = random_color()
                    test = player_coords.z
                    GRAPHICS.USE_PARTICLE_FX_ASSET("des_tv_smash")
                    GRAPHICS.SET_PARTICLE_FX_NON_LOOPED_COLOUR(colorR, colorG, colorB)
                    GRAPHICS.START_NETWORKED_PARTICLE_FX_NON_LOOPED_AT_COORD("ent_sht_electrical_box_sp", player_coords.x, player_coords.y, test, 0, 0, 0, 5, false, false, false, false)
                end
            end
            sleep(0.2)
        end
    end
end)
toolTip(Global, "为整个战局提供闪电/电流效果")
Global:add_sameline()
local snowLoopGlobal = Global:add_checkbox("雪（开/关）")
function load_snow()

    STREAMING.REQUEST_NAMED_PTFX_ASSET("proj_xmas_snowball")
    
    if not STREAMING.HAS_NAMED_PTFX_ASSET_LOADED("proj_xmas_snowball") then
        return false
    end

    return true
end

function random_color()
    return math.random(0, 255), math.random(0, 255), math.random(0, 255)
end

script.register_looped("snowLoopGlobal", function()
    if snowLoopGlobal:is_enabled() == true then
        if load_snow() then
            local localPlayerId = PLAYER.PLAYER_ID()
            for i = 0, 32 do
                if i ~= localPlayerId then
                    local player_id = i
                    local player_coords = ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(player_id), true)

                    -- Get random color values
                    local colorR, colorG, colorB = random_color()
                    test = player_coords.z
                    GRAPHICS.USE_PARTICLE_FX_ASSET("proj_xmas_snowball")
                    GRAPHICS.SET_PARTICLE_FX_NON_LOOPED_COLOUR(colorR, colorG, colorB)
                    GRAPHICS.START_NETWORKED_PARTICLE_FX_NON_LOOPED_AT_COORD("exp_grd_snowball", player_coords.x, player_coords.y, test, 0, 0, 0, 5, false, false, false, false)
                end
            end
            sleep(0.2)
        end
    end
end)
toolTip(Global, "使整个战局具有被雪球击中的效果")
-- Global Explode
Global:add_separator()
Global:add_text("恶作剧选项")
local hornsCB = Global:add_checkbox("喇叭")
script.register_looped("horns", function(hornsTest)
    if hornsCB:is_enabled() then
        local vehicles = entities.get_all_vehicles_as_handles()
        for i, vehicle in ipairs(vehicles) do
            if request_control(vehicle) then
                VEHICLE.START_VEHICLE_HORN(vehicle, 1000, 0, true)
                AUDIO.USE_SIREN_AS_HORN(vehicle, true)
            end
        end
        hornsTest:yield()
    end
    sleep(0.2)
end)
toolTip(Global, "使所有车辆喇叭不断响起.")
Global:add_separator()
Global:add_text("崩溃选项")
Global:add_button("船只外观崩溃", function()
    script.run_in_fiber(function (pedpacrash)
        gui.show_message("船只外观", "给大家船只外观崩溃.")
        PED.SET_PED_COORDS_KEEP_VEHICLE(PLAYER.PLAYER_PED_ID(), -74.94, -818.58, 327)
        local spped = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(PLAYER.PLAYER_ID())
        local ppos = ENTITY.GET_ENTITY_COORDS(spped, true)
        for n = 0 , 5 do
            local object_hash = joaat("prop_byard_rowboat4")
            STREAMING.REQUEST_MODEL(object_hash)
              while not STREAMING.HAS_MODEL_LOADED(object_hash) do
                pedpacrash:yield()
            end
            PLAYER.SET_PLAYER_PARACHUTE_MODEL_OVERRIDE(PLAYER.PLAYER_ID(),object_hash)
            ENTITY.SET_ENTITY_COORDS_NO_OFFSET(spped, 0,0,500, false, true, true)
            WEAPON.GIVE_DELAYED_WEAPON_TO_PED(spped, 0xFBAB5776, 1000, false)
            pedpacrash:sleep(1000)
            for i = 0 , 20 do
                PAD.SET_CONTROL_VALUE_NEXT_FRAME(2, 144, 1.0)
                PED.FORCE_PED_TO_OPEN_PARACHUTE(spped)
            end
            pedpacrash:sleep(1000)
            ENTITY.SET_ENTITY_COORDS_NO_OFFSET(spped, ppos.x, ppos.y, ppos.z, false, true, true)
    
            local object_hash2 = joaat("prop_byard_rowboat4")
            STREAMING.REQUEST_MODEL(object_hash2)
            while not STREAMING.HAS_MODEL_LOADED(object_hash2) do
                pedpacrash:yield()
            end
            PLAYER.SET_PLAYER_PARACHUTE_MODEL_OVERRIDE(PLAYER.PLAYER_ID(),object_hash2)
            ENTITY.SET_ENTITY_COORDS_NO_OFFSET(spped, 0,0,500, false, false, true)
            WEAPON.GIVE_DELAYED_WEAPON_TO_PED(spped, 0xFBAB5776, 1000, false)
            pedpacrash:sleep(1000)
            for i = 0 , 20 do
                PED.FORCE_PED_TO_OPEN_PARACHUTE(spped)
                PAD.SET_CONTROL_VALUE_NEXT_FRAME(2, 144, 1.0)
            end
            pedpacrash:sleep(1000)
            ENTITY.SET_ENTITY_COORDS_NO_OFFSET(spped, ppos.x, ppos.y, ppos.z, false, true, true)
        end
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(spped, ppos.x, ppos.y, ppos.z, false, true, true)
    end)
end)
toolTip(Global, "给大家船皮！（降落伞坠毁与船作为降落伞，相当有效）将在整个会话中坠毁，在某些模组制作者上不起作用.")
Global:add_sameline()
Global:add_button("片段崩溃", function()
    script.run_in_fiber(function (fragcrash)
    local localPlayerId = PLAYER.PLAYER_PED_ID()
        for i = 0, 31 do
            if i ~= localPlayerId then
                local players = i
                fraghash = joaat("prop_fragtest_cnst_04")
                STREAMING.REQUEST_MODEL(fraghash)
                local TargetCrds = ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED(selPlayer), false)
                local crashstaff1 = OBJECT.CREATE_OBJECT(fraghash, TargetCrds.x, TargetCrds.y, TargetCrds.z, true, false, false)
                    OBJECT.BREAK_OBJECT_FRAGMENT_CHILD(crashstaff1, 1, false)
                local crashstaff2 = OBJECT.CREATE_OBJECT(fraghash, TargetCrds.x, TargetCrds.y, TargetCrds.z, true, false, false)
                    OBJECT.BREAK_OBJECT_FRAGMENT_CHILD(crashstaff2, 1, false)
                local crashstaff3 = OBJECT.CREATE_OBJECT(fraghash, TargetCrds.x, TargetCrds.y, TargetCrds.z, true, false, false)
                    OBJECT.BREAK_OBJECT_FRAGMENT_CHILD(crashstaff3, 1, false)
                local crashstaff4 = OBJECT.CREATE_OBJECT(fraghash, TargetCrds.x, TargetCrds.y, TargetCrds.z, true, false, false)
                    OBJECT.BREAK_OBJECT_FRAGMENT_CHILD(crashstaff4, 1, false)
                for v = 0, 100 do   
                    local TargetPlayerPos = ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED(network.get_selected_player()), false)
                    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(crashstaff1, TargetPlayerPos.x, TargetPlayerPos.y, TargetPlayerPos.z, false, true, true)
                    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(crashstaff2, TargetPlayerPos.x, TargetPlayerPos.y, TargetPlayerPos.z, false, true, true)
                    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(crashstaff3, TargetPlayerPos.x, TargetPlayerPos.y, TargetPlayerPos.z, false, true, true)
                    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(crashstaff4, TargetPlayerPos.x, TargetPlayerPos.y, TargetPlayerPos.z, false, true, true)
                    fragcrash:sleep(10)
                    delete_entity(crashstaff1)
                    delete_entity(crashstaff2)
                    delete_entity(crashstaff3)
                    delete_entity(crashstaff4)
                end
            end
        end
    end)
    script.run_in_fiber(function (fragcrash2)
    local localPlayerId = PLAYER.PLAYER_ID()
        for i = 0, 31 do
            if i ~= localPlayerId then
                local players = i
                local TargetCrds = ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED(players), false)
                fraghash = joaat("prop_fragtest_cnst_04")
                STREAMING.REQUEST_MODEL(fraghash)
                for v=1,10 do
                 
                    local object = OBJECT.CREATE_OBJECT(fraghash, TargetCrds.x, TargetCrds.y, TargetCrds.z, true, false, false)
                    OBJECT.BREAK_OBJECT_FRAGMENT_CHILD(object, 1, false)
                    delete_entity(object)
                    local object = OBJECT.CREATE_OBJECT(fraghash, TargetCrds.x, TargetCrds.y, TargetCrds.z, true, false, false)
                    OBJECT.BREAK_OBJECT_FRAGMENT_CHILD(object, 1, false)
                    delete_entity(object)
                    local object = OBJECT.CREATE_OBJECT(fraghash, TargetCrds.x, TargetCrds.y, TargetCrds.z, true, false, false)
                    OBJECT.BREAK_OBJECT_FRAGMENT_CHILD(object, 1, false)
                    delete_entity(object)
                    local object = OBJECT.CREATE_OBJECT(fraghash, TargetCrds.x, TargetCrds.y, TargetCrds.z, true, false, false)
                    OBJECT.BREAK_OBJECT_FRAGMENT_CHILD(object, 1, false)
                    delete_entity(object)
                    local object = OBJECT.CREATE_OBJECT(fraghash, TargetCrds.x, TargetCrds.y, TargetCrds.z, true, false, false)
                    OBJECT.BREAK_OBJECT_FRAGMENT_CHILD(object, 1, false)
                    delete_entity(object)
                    local object = OBJECT.CREATE_OBJECT(fraghash, TargetCrds.x, TargetCrds.y, TargetCrds.z, true, false, false)
                    OBJECT.BREAK_OBJECT_FRAGMENT_CHILD(object, 1, false)
                    delete_entity(object)
                    local object = OBJECT.CREATE_OBJECT(fraghash, TargetCrds.x, TargetCrds.y, TargetCrds.z, true, false, false)
                    OBJECT.BREAK_OBJECT_FRAGMENT_CHILD(object, 1, false)
                    delete_entity(object)
                    local object = OBJECT.CREATE_OBJECT(fraghash, TargetCrds.x, TargetCrds.y, TargetCrds.z, true, false, false)
                    OBJECT.BREAK_OBJECT_FRAGMENT_CHILD(object, 1, false)
                    delete_entity(object)
                    local object = OBJECT.CREATE_OBJECT(fraghash, TargetCrds.x, TargetCrds.y, TargetCrds.z, true, false, false)
                    OBJECT.BREAK_OBJECT_FRAGMENT_CHILD(object, 1, false)
                    delete_entity(object)
                    local object = OBJECT.CREATE_OBJECT(fraghash, TargetCrds.x, TargetCrds.y, TargetCrds.z, true, false, false)
                    OBJECT.BREAK_OBJECT_FRAGMENT_CHILD(object, 1, false)
                    fragcrash2:sleep(100)
                    delete_entity(object)
                end
            end
        end
    end)
end)
toolTip(Global, "片段崩溃整个战局")
Global:add_sameline()
Global:add_button("HUD 破坏", function()
for p = 0, 31 do
    local pid = p
    if p ~= PLAYER.PLAYER_ID() then
        for i = -1, 1 do
            network.trigger_script_event(1 << pid, {1450115979, pid, i})
        end
    end
end
    gui.show_message("HUD 破坏", "您已经破坏了整个会话 HUD 和内饰.")
    gui.show_message("HUD 破坏", "这导致他们没有HUD，也看不到内部入口点，他们也无法暂停或切换武器.")
end)
toolTip(Global, "破坏会话中每个玩家的 HUD，使他们的任务在自由模式中断，移除他们的 HUD，防止暂停并阻止进入属性，因为它移除了 entrace 标记")
Global:add_sameline()
local clownJetAttack = Global:add_checkbox("小丑喷气式攻击")
    script.register_looped("clownJetAttack", function(clownJetsOne)
        if clownJetAttack:is_enabled() == true then
            for i = 0, 31 do
                if i ~= PLAYER.PLAYER_ID() then
                    local player = i
                    local players = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(player)
                    local playerName = PLAYER.GET_PLAYER_NAME(players)
                    local coords = ENTITY.GET_ENTITY_COORDS(players, true)
                    local heading = ENTITY.GET_ENTITY_HEADING(players)
                    local spawnDistance = 250.0 * math.sin(math.rad(heading))
                    local spawnHeight = 10.0 -- Adjust this value to set the height at which the jet spawns
                    local isRoad, roadCoords = PATHFIND.GET_NTH_CLOSEST_VEHICLE_NODE_WITH_HEADING(coords.x + spawnDistance, coords.y + spawnDistance, coords.z, 1, coords, heading, 0, 9, 3.0, 2.5)
                    local clown = joaat("s_m_y_clown_01")
                    local jet = joaat("Lazer")
                    local weapon = -1121678507

                    STREAMING.REQUEST_MODEL(clown)
                    STREAMING.REQUEST_MODEL(jet)
                    STREAMING.REQUEST_MODEL(weapon)

                    while not STREAMING.HAS_MODEL_LOADED(clown) or not STREAMING.HAS_MODEL_LOADED(jet) do    
                        STREAMING.REQUEST_MODEL(clown)
                        STREAMING.REQUEST_MODEL(jet)
                        clownJetsOne:yield()
                    end

                    -- Calculate the spawn position for the jet in the air
                    local jetSpawnX = coords.x + math.random(-1000, 1000)
                    local jetSpawnY = coords.y + math.random(-1000, 1000)
                    local jetSpawnZ = coords.z + math.random(100, 1200)
                    
                    local colors = {27, 28, 29, 150, 30, 31, 32, 33, 34, 143, 35, 135, 137, 136, 36, 38, 138, 99, 90, 88, 89, 91, 49, 50, 51, 52, 53, 54, 92, 141, 61, 62, 63, 64, 65, 66, 67, 68, 69, 73, 70, 74, 96, 101, 95, 94, 97, 103, 104, 98, 100, 102, 99, 105, 106, 71, 72, 142, 145, 107, 111, 112,}
                    local jetVehicle = VEHICLE.CREATE_VEHICLE(jet, jetSpawnX, jetSpawnY, jetSpawnZ, heading, true, false, false)
                    if jetVehicle ~= 0 then
                        local primaryColor = colors[math.random(#colors)]
                        local secondaryColor = colors[math.random(#colors)]

                        -- Set vehicle colors
                        VEHICLE.SET_VEHICLE_COLOURS(jetVehicle, primaryColor, secondaryColor)
                        -- Spawn clowns inside the jet
                        for seat = -1, -1 do
                            local ped = PED.CREATE_PED(0, clown, jetSpawnX, jetSpawnY, jetSpawnZ, heading, true, true)
                            
                            if ped ~= 0 then
                                local group = joaat("HATES_PLAYER")
                                PED.ADD_RELATIONSHIP_GROUP("clowns", group)
                                ENTITY.SET_ENTITY_CAN_BE_DAMAGED_BY_RELATIONSHIP_GROUP(ped, false, group)
                                PED.SET_PED_CAN_BE_TARGETTED(ped, false)
                                WEAPON.GIVE_WEAPON_TO_PED(ped, weapon, 999999, false, true)
                                PED.SET_PED_COMBAT_ATTRIBUTES(ped, 5, true)
                                PED.SET_PED_COMBAT_ATTRIBUTES(ped, 13, true)
                                PED.SET_PED_COMBAT_ATTRIBUTES(ped, 31, true)
                                PED.SET_PED_COMBAT_ATTRIBUTES(ped, 17, false)
                                PED.SET_PED_COMBAT_ATTRIBUTES(ped, 1, true)
                                PED.SET_PED_COMBAT_ATTRIBUTES(ped, 46, true)
                                PED.SET_PED_COMBAT_ATTRIBUTES(ped, 0, false)
                                PED.SET_PED_INTO_VEHICLE(ped, jetVehicle, seat)
                                TASK.TASK_COMBAT_PED(ped, players, 0, 16)
                                ENTITY.SET_ENTITY_MAX_HEALTH(ped, 1000)
                                ENTITY.SET_ENTITY_HEALTH(ped, 1000, 0)
                                ENTITY.SET_ENTITY_MAX_HEALTH(jetVehicle, 1000)
                                ENTITY.SET_ENTITY_HEALTH(jetVehicle, 1000, 0)
                                PED.SET_AI_WEAPON_DAMAGE_MODIFIER(10000)
                                WEAPON.SET_WEAPON_DAMAGE_MODIFIER(1060309761, 10000)
                            else
                                gui.show_error("失败", "无法创建 ped")
                            end
                        end
                    else
                        gui.show_error("失败", "无法创建 jet")
                    end
                
                    if jetVehicle == 0 then 
                        gui.show_error("失败", "无法创建 Jet")
                    else
                        gui.show_message("搅局行为", "小丑拉泽斯诞生了！ 锁定已获得！目标: "..PLAYER.GET_PLAYER_NAME(player).." 每 15 秒生成一次喷气机.")
                    end
                end
            end
            -- Release the resources associated with the spawned entities
            ENTITY.SET_ENTITY_AS_NO_LONGER_NEEDED(jetVehicle)
            ENTITY.SET_ENTITY_AS_NO_LONGER_NEEDED(ped)
            sleep(15)
        end
    end)
toolTip(Global, "在整个战局中生成带有小丑的 Rainbos 彩色喷气机作为飞行员，每 15 秒循环运行一次.")
local explosionLoop = false
explosionLoop = Global:add_checkbox("爆炸（开/关）)")

script.register_looped("explosionLoop", function()
    if explosionLoop:is_enabled() == true then
        local explosionType = 1  -- Adjust this according to the explosion type you want (1 = GRENADE, 2 = MOLOTOV, etc.)
        local explosionFx = "explosion_barrel"
        local localPlayerId = PLAYER.PLAYER_ID()

        for i = 0, 31 do
            if i ~= localPlayerId then
                local player_id = i
                local coords = ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(player_id), true)
                gui.show_message("全局（有毒）“、”爆炸 " .. PLAYER.GET_PLAYER_NAME(player_id) .. " 反复")
                
                FIRE.ADD_EXPLOSION(coords.x, coords.y, coords.z, explosionType, 100000.0, true, false, 0, false)
                GRAPHICS.USE_PARTICLE_FX_ASSET(explosionFx)
                GRAPHICS.START_PARTICLE_FX_NON_LOOPED_AT_COORD("explosion_barrel", coords.x, coords.y, coords.z, 0.0, 0.0, 0.0, 1.0, false, true, false)

                -- Optionally, you can play an explosion sound here using AUDIO.PLAY_SOUND_FROM_COORD
            end
        end

        sleep(0.4)  -- Sets the timer in seconds for how long this should pause before exploding another player
    end
end)
toolTip(Global, "分解整个战局")
Global:add_sameline()
local ramGlobal = Global:add_checkbox("车辆夹层（开/关）)")

script.register_looped("ramGlobal", function()
    if ramGlobal:is_enabled() then
    local localPlayerId = PLAYER.PLAYER_ID()
         for i = 0, 31 do
            if i ~= localPlayerId then
                local player_id = i
                    if NETWORK.NETWORK_IS_PLAYER_ACTIVE(player_id) then
                        local coords = ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(player_id), true)

                        -- Get a random vehicle model from the list (make sure 'vehicleModels' is defined)
                        local randomModel = vehicleModels[math.random(1, #vehicleModels)]

                        -- Convert the string vehicle model to its hash value
                        local modelHash = MISC.GET_HASH_KEY(randomModel)

                        -- Create the vehicle without the last boolean argument (keepTrying)
                        local vehicle = VEHICLE.CREATE_VEHICLE(modelHash, coords.x, coords.y, coords.z + 20, 0.0, true, true, false)
                        -- Set vehicle orientation
                        ENTITY.SET_ENTITY_ROTATION(vehicle, 0, 0, 0, 2, true)
                        local networkId = NETWORK.VEH_TO_NET(vehicle)
                        if NETWORK.NETWORK_GET_ENTITY_IS_NETWORKED(vehicle) then
                            NETWORK.SET_NETWORK_ID_EXISTS_ON_ALL_MACHINES(networkId, true)
                        end

                        if vehicle then
                            -- Set the falling velocity (adjust the value as needed)
                            ENTITY.SET_ENTITY_VELOCITY(vehicle, 0, 0, -100000000)
                            -- Optionally, you can play a sound or customize the ramming effect here
                            VEHICLE.SET_ALLOW_VEHICLE_EXPLODES_ON_CONTACT(vehicle, true)
                        end
                        
                        local vehicle2 = VEHICLE.CREATE_VEHICLE(modelHash, coords.x, coords.y, coords.z - 20, 0.0, true, true, false)
                        -- Set vehicle orientation
                        ENTITY.SET_ENTITY_ROTATION(vehicle2, 0, 0, 0, 2, true)
                        local networkId = NETWORK.VEH_TO_NET(vehicle2)
                        if NETWORK.NETWORK_GET_ENTITY_IS_NETWORKED(vehicle2) then
                            NETWORK.SET_NETWORK_ID_EXISTS_ON_ALL_MACHINES(networkId, true)
                        end

                        if vehicle2 then
                            -- Set the falling velocity (adjust the value as needed)
                            ENTITY.SET_ENTITY_VELOCITY(vehicle2, 0, 0, 100000000)
                            -- Optionally, you can play a sound or customize the ramming effect here
                            VEHICLE.SET_ALLOW_VEHICLE_EXPLODES_ON_CONTACT(vehicle2, true)
                        end

                        gui.show_message("搅局行为", "用车辆撞击" .. PLAYER.GET_PLAYER_NAME(player_id))

                        -- Use these lines to delete the vehicle after spawning. 
                        -- Needs some type of delay between spawning and deleting to function properly
                        
                        ENTITY.SET_ENTITY_AS_NO_LONGER_NEEDED(vehicle)
                        ENTITY.SET_ENTITY_AS_NO_LONGER_NEEDED(vehicle2)
                    end
            end
        end

        -- Sets the timer in seconds for how long this should pause before ramming another player
        --sleep(0.2)
    end
end)
toolTip(Global, "将整个会话与车辆夹在一起")
-- Global Crashes
Global:add_sameline()
local crashGlobal = Global:add_checkbox("PR 全局崩溃 (On/Off)")

script.register_looped("crashGlobal", function()
    if crashGlobal:is_enabled() then
    local localPlayerId = PLAYER.PLAYER_ID()
         for i = 0, 31 do
            if i ~= localPlayerId then
                local player_id = i
                local model = joaat("vw_prop_vw_colle_prbubble")
                local pickup = joaat("PICKUP_CUSTOM_SCRIPT")
                local money_value = 100000000000

                STREAMING.REQUEST_MODEL(model)

                if STREAMING.HAS_MODEL_LOADED(model) then
                gui.show_message("全局 (有毒)", "崩溃 " .. PLAYER.GET_PLAYER_NAME(player_id) .. " 带小雕像")
                    local coords = ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(player_id), true)
                    local objectIdSpawned = OBJECT.CREATE_AMBIENT_PICKUP(
                        pickup,
                        coords.x,
                        coords.y,
                        coords.z + 0.5,
                        3,
                        money_value,
                        model,
                        true,
                        false
                    )

                    local net_id = NETWORK.OBJ_TO_NET(objectIdSpawned)
                    NETWORK.SET_NETWORK_ID_EXISTS_ON_ALL_MACHINES(objectIdSpawned, true)
                    
                    ENTITY.SET_ENTITY_AS_NO_LONGER_NEEDED(objectIdSpawned)
                end
                 sleep(0.1) -- Sets the timer in seconds for how long this should pause
            end
        end
    end
end)
toolTip(Global, "生成价格过高的公主机器人雕像，使会话中的所有玩家崩溃")
-- Global Weapons
Global:add_separator()
Global:add_text("全局 武器选项")
Global:add_button("将所有武器交给玩家", function()
    local player_count = PLAYER.GET_NUMBER_OF_PLAYERS()

    for i = 0, 31 do
        local playerID = i
        local ent = PLAYER.GET_PLAYER_PED(playerID)
        if ENTITY.DOES_ENTITY_EXIST(ent) and not ENTITY.IS_ENTITY_DEAD(ent, false) then
            for _, name in ipairs(weaponNamesString) do
                local weaponHash = MISC.GET_HASH_KEY(name)
                WEAPON.GIVE_WEAPON_TO_PED(ent, weaponHash, 9999, false, true)
            end
        end
    end
    local msg = "我已经给了整个大厅所有的武器。 这只持续到您切换战局，享受!"
    network.send_chat_message(msg, false)
    gui.show_message("全局", "成功将所有武器赠送给所有玩家")
end)
toolTip(Global, "将所有武器交给整个会话，并宣布您已经这样做了")
Global:add_sameline()
Global:add_button("从玩家身上移除所有武器", function()
    local player_count = PLAYER.GET_NUMBER_OF_PLAYERS()

    for i = 0, 31 do
        local playerID = i
        local ent = PLAYER.GET_PLAYER_PED(playerID)
        if ENTITY.DOES_ENTITY_EXIST(ent) and not ENTITY.IS_ENTITY_DEAD(ent, false) then
            for _, name in ipairs(weaponNamesString) do
                local weaponHash = MISC.GET_HASH_KEY(name)
                WEAPON.REMOVE_WEAPON_FROM_PED(ent, weaponHash)
            end
        end
    end
    local msg = "我已经从整个大厅中移除了所有武器。 这只持续到你切换会话，玩得开心!"
    network.send_chat_message(msg, false)
    gui.show_message("全局", "成功移除所有玩家的所有武器")
end)
toolTip(Global, "从整个战局中移除所有武器，并宣布您已经这样做了")
-- Story Mode Options

StoryCharacters = KAOS:add_tab("故事模式")

    mCash = 0
    StoryCharacters:add_imgui(function()
        mCash, used = ImGui.SliderInt("麦克 现金", mCash, 1, 2147483646)
        out = "麦克的现金设置为 $"..tostring(mCash)
        if used then
            STATS.STAT_SET_INT(joaat("SP0_TOTAL_CASH"), mCash, true)
            gui.show_message('故事模式现金更新!', out)
        end
    end)
    
    fCash = 0
    StoryCharacters:add_imgui(function()
        fCash, used = ImGui.SliderInt("富兰克林现金", fCash, 1, 2147483646)
        out = "富兰克林斯的现金设置为 $"..tostring(fCash)
        if used then
            STATS.STAT_SET_INT(joaat("SP1_TOTAL_CASH"), fCash, true)
            gui.show_message('故事模式现金更新!', out)
        end
    end)
    
    tCash = 0
    StoryCharacters:add_imgui(function()
        tCash, used = ImGui.SliderInt("崔弗的现金", tCash, 1, 2147483646)
        out = "崔弗的现金设置为 $"..tostring(tCash)
        if used then
            STATS.STAT_SET_INT(joaat("SP2_TOTAL_CASH"), tCash, true)
            gui.show_message('故事模式现金更新!', out)
        end
    end)
    StoryCharacters:add_separator()
    mStats = 0
    StoryCharacters:add_imgui(function()
        mStats, used = ImGui.SliderInt("麦克的统计数据", mStats, 0, 100)
        out = "麦克 统计信息设置为 "..tostring(mStats).."/100"
        if used then
            STATS.STAT_SET_INT(joaat("SP0_SPECIAL_ABILITY"), mStats, true)
            STATS.STAT_SET_INT(joaat("SP0_STAMINA"), mStats, true)
            STATS.STAT_SET_INT(joaat("SP0_STRENGTH"), mStats, true)
            STATS.STAT_SET_INT(joaat("SP0_LUNG_CAPACITY"), mStats, true)
            STATS.STAT_SET_INT(joaat("SP0_WHEELIE_ABILITY"), mStats, true)
            STATS.STAT_SET_INT(joaat("SP0_FLYING_ABILITY"), mStats, true)
            STATS.STAT_SET_INT(joaat("SP0_SHOOTING_ABILITY"), mStats, true)
            STATS.STAT_SET_INT(joaat("SP0_STEALTH_ABILITY"), mStats, true)
            gui.show_message('故事模式统计更新!', out)
        end
    end)
    
    fStats = 0
    StoryCharacters:add_imgui(function()
        fStats, used = ImGui.SliderInt("富兰克林统计数据", fStats, 0, 100)
        out = "富兰克林的统计数据设置为 "..tostring(fStats).."/100"
        if used then
            STATS.STAT_SET_INT(joaat("SP1_SPECIAL_ABILITY"), fStats, true)
            STATS.STAT_SET_INT(joaat("SP1_STAMINA"), fStats, true)
            STATS.STAT_SET_INT(joaat("SP1_STRENGTH"), fStats, true)
            STATS.STAT_SET_INT(joaat("SP1_LUNG_CAPACITY"), fStats, true)
            STATS.STAT_SET_INT(joaat("SP1_WHEELIE_ABILITY"), fStats, true)
            STATS.STAT_SET_INT(joaat("SP1_FLYING_ABILITY"), fStats, true)
            STATS.STAT_SET_INT(joaat("SP1_SHOOTING_ABILITY"), fStats, true)
            STATS.STAT_SET_INT(joaat("SP1_STEALTH_ABILITY"), fStats, true)
            gui.show_message('故事模式统计更新!', out)
        end
    end)
    
    tStats = 0
    StoryCharacters:add_imgui(function()
        tStats, used = ImGui.SliderInt("崔弗的统计数据", tStats, 0, 100)
        out = "崔弗的统计数据设置为 "..tostring(tStats).."/100"
        if used then
            STATS.STAT_SET_INT(joaat("SP2_SPECIAL_ABILITY"), tStats, true)
            STATS.STAT_SET_INT(joaat("SP2_STAMINA"), tStats, true)
            STATS.STAT_SET_INT(joaat("SP2_STRENGTH"), tStats, true)
            STATS.STAT_SET_INT(joaat("SP2_LUNG_CAPACITY"), tStats, true)
            STATS.STAT_SET_INT(joaat("SP2_WHEELIE_ABILITY"), tStats, true)
            STATS.STAT_SET_INT(joaat("SP2_FLYING_ABILITY"), tStats, true)
            STATS.STAT_SET_INT(joaat("SP2_SHOOTING_ABILITY"), tStats, true)
            STATS.STAT_SET_INT(joaat("SP2_STEALTH_ABILITY"), tStats, true)
            gui.show_message('故事模式统计更新!', out)
        end
    end)
    
-- Weapons Tab

local Weapons = KAOS:add_tab("武器")

Weapons:add_button("移除所有武器", function()
        local playerID = network.get_selected_player()
        local ent = PLAYER.GET_PLAYER_PED(playerID)
        out = "成功移除了所有武器 "..PLAYER.GET_PLAYER_NAME(playerID)
        if ENTITY.DOES_ENTITY_EXIST(ent) and not ENTITY.IS_ENTITY_DEAD(ent, false) then
            for _, name in ipairs(weaponNamesString) do
                local weaponHash = MISC.GET_HASH_KEY(name)
                WEAPON.REMOVE_WEAPON_FROM_PED(ent, weaponHash)
                gui.show_message('武器', out)
                
            end
        end
end)
toolTip(Weapons, "从所选玩家中移除所有武器")
Weapons:add_sameline()
Weapons:add_button("提供所有武器", function()
        local playerID = network.get_selected_player()
        local ent = PLAYER.GET_PLAYER_PED(playerID)
        out = "成功将所有武器交给 "..PLAYER.GET_PLAYER_NAME(playerID)
        if ENTITY.DOES_ENTITY_EXIST(ent) and not ENTITY.IS_ENTITY_DEAD(ent, false) then
            for _, name in ipairs(weaponNamesString) do
                local weaponHash = MISC.GET_HASH_KEY(name)
                WEAPON.GIVE_WEAPON_TO_PED(ent, weaponHash, 9999, false, true)
                gui.show_message('武器', out)
                
            end
        end
end)
toolTip(Weapons, "将所有武器交给选定的玩家")
Weapons:add_separator()
Weapons:add_text("武器掉落")
Weapons:add_button("掉落随机武器", function()
        local weaponName = weaponNamesString[math.random(1, #weaponNamesString)]
        local money_value = 0
        local player_id = network.get_selected_player()
        local model = weaponModels[math.random(1, #weaponModels)]

        local modelHash = joaat(model)
        STREAMING.REQUEST_MODEL(modelHash)
        while STREAMING.HAS_MODEL_LOADED(modelHash) == false do
            script:yield()
        end
        if STREAMING.HAS_MODEL_LOADED(modelHash) then
            gui.show_message("武器掉落开始", "掉落 " .. weaponName .. " 上 "..PLAYER.GET_PLAYER_NAME(player_id))
            local coords = ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(player_id), true)
            local objectIdSpawned = OBJECT.CREATE_AMBIENT_PICKUP(
                joaat("PICKUP_" .. string.upper(weaponName)),
                coords.x,
                coords.y,
                coords.z + 1,
                3,
                money_value,
                modelHash,
                true,
                false
            )

            local net_id = NETWORK.OBJ_TO_NET(objectIdSpawned)
            NETWORK.SET_NETWORK_ID_EXISTS_ON_ALL_MACHINES(objectIdSpawned, true)
        end
end)
toolTip(Weapons, "将随机武器作为拾取物品掉落在所选玩家身上")
Weapons:add_separator()


-- Business Management
local Business = KAOS:add_tab("产业管理")

local agency = Business:add_tab("机构")

MPX = PI
PI = stats.get_int("MPPLY_LAST_MP_CHAR")
if PI == 0 then
    MPX = "MP0_"
else
    MPX = "MP1_"
end

local contract_id = {3, 4, 12, 28, 60, 124, 252, 508, 2044, 4095, -1}
local contract_names = {"夜总会", " 港口", "夜生活 泄漏", "乡村俱乐部", "嘉宾名单", "上流社会泄密", "戴维斯", "巴拉斯", "中南部泄漏", "工作室时间", "不要和德雷过不去"}
local selectedContractIndex = 0
local selectedContractID = contract_id[selectedContractIndex + 1]
--"The Marina" - 港口
--"Nightlife Leak" - 夜生活泄漏
--"The Country Club" - 乡村俱乐部
--"Guest List" - 客人名单
--"High Society Leak" - 上流社会泄漏
--"Davis" - 戴维斯
--"The Ballas" - 巴拉斯帮
--"The South Central Leak" - 南部中心泄漏
--"Studio Time" - 录音室时间
--"Don't Fuck With Dre" - 不要和德雷过不去
agency:add_text("Agency Contract Selection")

-- Display the listbox
local contractChanged = false

agency:add_imgui(function()
    selectedContractIndex, used = ImGui.ListBox("##ContractList", selectedContractIndex, contract_names, #contract_names) -- Display the listbox
    if used then
        selectedContractID = contract_id[selectedContractIndex + 1]
    end

    if ImGui.Button("选择产业") then
        local contractIndexToUse = selectedContractIndex + 1  -- Adjusted index for contract names
        local contractIDToUse = contract_id[contractIndexToUse]
        STATS.STAT_SET_INT(joaat(MPX .. "FIXER_STORY_BS"), contractIDToUse, true)
        gui.show_message("产业", "产业: " .. contract_names[contractIndexToUse] .. " ID: " .. contractIDToUse .. " 选择")
    end
end)
toolTip(agency, "将所选合约设置为您当前正在玩的合约")
agency:add_sameline()

agency:add_button("完成准备工作", function()
    STATS.STAT_SET_INT(joaat(MPX .. "FIXER_GENERAL_BS"), -1, true)
    STATS.STAT_SET_INT(joaat(MPX .. "FIXER_COMPLETED_BS"), -1, true)
    STATS.STAT_SET_INT(joaat(MPX .. "FIXER_STORY_COOLDOWN_POSIX"), -1, true)
end)
toolTip(agency, "完成当前合同的准备工作")
agency:add_sameline()
agency:add_button("跳过冷却时间", function()
    STATS.STAT_SET_INT(joaat(MPX .. "FIXER_STORY_COOLDOWN"), -1, true)
end)
toolTip(agency, "跳过游戏合约之间的冷却时间")
agency:add_separator()
agency:add_text("钱")
local agencySafe = agency:add_checkbox("产业安全 循环")
script.register_looped("agencyloop", function(script)
    script:yield()
    if agencySafe:is_enabled() == true then
        gui.show_message("Business Manager", "Supplying Agency Safe with money")
        STATS.STAT_SET_INT(joaat(MPX .. "FIXER_COUNT"), 500, true)
        STATS.STAT_SET_INT(joaat(MPX .. "FIXER_PASSIVE_PAY_TIME_LEFT"), -1, true)
        sleep(0.5)
    end
end)
toolTip(agency, "为您的产业提供安全的资金")
local bunker = Business:add_tab("地堡")

bunker:add_button("解锁所有射击场", function()
MPX = PI
PI = stats.get_int("MPPLY_LAST_MP_CHAR")
if PI == 0 then
    MPX = "MP0_"
else
    MPX = "MP1_"
end
    STATS.STAT_SET_INT(joaat(MPX .. "SR_HIGHSCORE_1"), 690, true)
    STATS.STAT_SET_INT(joaat(MPX .. "SR_HIGHSCORE_2"), 1860, true)
    STATS.STAT_SET_INT(joaat(MPX .. "SR_HIGHSCORE_3"), 2690, true)
    STATS.STAT_SET_INT(joaat(MPX .. "SR_HIGHSCORE_4"), 2660, true)
    STATS.STAT_SET_INT(joaat(MPX .. "SR_HIGHSCORE_5"), 2650, true)
    STATS.STAT_SET_INT(joaat(MPX .. "SR_HIGHSCORE_6"), 450, true)
    STATS.STAT_SET_INT(joaat(MPX .. "SR_TARGETS_HIT"), 269, true)
    STATS.STAT_SET_INT(joaat(MPX .. "SR_WEAPON_BIT_SET"), -1, true)
    STATS.STAT_SET_BOOL(joaat(MPX .. "SR_TIER_1_REWARD"), true, true)
    STATS.STAT_SET_BOOL(joaat(MPX .. "SR_TIER_3_REWARD"), true, true)
    STATS.STAT_SET_BOOL(joaat(MPX .. "SR_INCREASE_THROW_CAP"), true, true)
end)
toolTip(bunker, "将所有射击场任务设置为完成 @ 3 星")
local bResearch = bunker:add_checkbox("即时研究冷却时间（循环）")
MPX = PI
PI = stats.get_int("MPPLY_LAST_MP_CHAR")
if PI == 0 then
    MPX = "MP0_"
else
    MPX = "MP1_"
end
script.register_looped("bunkerResearch", function()
    if bResearch:is_enabled() == true then
        STATS.STAT_SET_INT(joaat(MPX .. "GR_RESEARCH_PRODUCTION_TIME"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "GR_RESEARCH_UPGRADE_EQUIPMENT_REDUCTION_TIME"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "GR_RESEARCH_UPGRADE_STAFF_REDUCTION_TIME"), 0, true)
        gui.show_message("地堡", "研究进展迅速，请随时离开")
        gui.show_message("地堡", "或者，您可以访问 电脑 并支付快速通道费用")
    end
end)
toolTip(bunker, "加快研究速度，切换补给，选择性地访问电脑并快速跟踪")
bunker:add_sameline()
local bSupplies = bunker:add_checkbox("补给地堡（循环）")
script.register_looped("autoGetBunkerCargo", function(script)
    script:yield()
    if bSupplies:is_enabled() == true then
        autoGetBunkerCargo = not autoGetBunkerCargo
        if autoGetBunkerCargo then
            globals.set_int(1662873 + 1 + 5, 1)
            if bResearch:is_enabled() == true then
                gui.show_message("地堡", "为您的研究补充用品")
            else
                gui.show_message("地堡", "补给您的地堡补给，请稍候...")
                sleep(0.5)
            end
        end
    end
end)
toolTip(bunker, "立即补充您的地堡补给")
local Hangar = Business:add_tab("飞机库")

hStock = Hangar:add_checkbox("补给机库货物（循环)")
script.register_looped("autoGetHangarCargo", function(script)
  MPX = PI
        PI = stats.get_int("MPPLY_LAST_MP_CHAR")
        if PI == 0 then
            MPX = "MP0_"
        else
            MPX = "MP1_"
        end
    script:yield()
    if hStock:is_enabled() == true then
        autoGetHangarCargo = not autoGetHangarCargo
        if autoGetHangarCargo then
            stats.set_bool_masked(MPX .. "DLC22022PSTAT_BOOL3", true, 9)
            gui.show_message("机库", "机库货物补货，请稍候...")
            sleep(0.5)
        end
    end
end)
toolTip(Hangar, "立即为您的机库提供随机货物")
local mcBus = Business:add_tab("摩托车俱乐部")

mcBus:add_button("摩托帮主 (开/关)", function()
    -- -1 is off, 0 is on
    playerID = PLAYER.PLAYER_ID()
    g = 1886967 + (playerID * 609) + 10
    gb1 = globals.get_int(g + 1)
    gb2 = globals.get_int(g + 430)
    if gb1 == playerID and gb2 == 1 then
        globals.set_int(g + 1, -1)
        globals.set_int(g + 430, -1)
        gui.show_message("摩托车俱乐部", "您不再是摩托帮主")
    else
        globals.set_int(g + 1, playerID)
        globals.set_int(g + 430, 1)
        gui.show_message("摩托车俱乐部", "您现在是摩托帮主")
    end
end)
toolTip(mcBus, "注册成为摩托帮会长")
mcBus:add_text("再供应商")
acidLab = mcBus:add_checkbox("补给致幻实验室（循环)")
script.register_looped("autoGetAcidCargo", function(script)
    script:yield()
    if acidLab:is_enabled() == true then
        autoGetAcidCargo = not autoGetAcidCargo
        if autoGetAcidCargo then
            globals.set_int(1662873 + 1 + 6, 1)
            gui.show_message("致幻实验室", "补充您的致幻实验室库存，请稍候...")
            sleep(0.5)
        end
    end
end)
toolTip(mcBus, "补充您的致幻实验室用品")
mcBus:add_sameline()
docForge = mcBus:add_checkbox("补给文档伪造（循环）)")
script.register_looped("autoGetDocForgeCargo", function(script)
    script:yield()
    if docForge:is_enabled() == true then
        autoGetDocForgeCargo = not autoGetDocForgeCargo
        if autoGetDocForgeCargo then
            globals.set_int(1662873 + 1 + 1, 1)
            gui.show_message("文档伪造", "重新提供您的文件伪造，请稍候...")
            sleep(0.5)
        end
    end
end)
toolTip(mcBus, "补充您的 文档伪造 耗材")
weed = mcBus:add_checkbox("补给大麻（循环）")
script.register_looped("autoGetWeedCargo", function(script)
    script:yield()
    if weed:is_enabled() == true then
        autoGetWeedCargo = not autoGetWeedCargo
        if autoGetWeedCargo then
            globals.set_int(1662873 + 1 + 2, 1)
            gui.show_message("大麻农场", "为您的杂草农场补给，请稍候...")
            sleep(0.5)
        end
    end
end)
toolTip(mcBus, "为您的大麻补给品补给")
mcBus:add_sameline()
meth = mcBus:add_checkbox("补给冰毒（循环）")
script.register_looped("autoGetMethCargo", function(script)
    script:yield()
    if meth:is_enabled() == true then
        autoGetMethCargo = not autoGetMethCargo
        if autoGetMethCargo then
            globals.set_int(1662873 + 1 + 3, 1)
            gui.show_message("冰毒实验室", "为您的冰毒实验室补给，请稍候...")
            sleep(0.5)
        end
    end
end)
toolTip(mcBus, "补充您的冰毒实验室用品")
mcBus:add_sameline()
cocaine = mcBus:add_checkbox("补给可卡因（循环)")
script.register_looped("autoGetCokeCargo", function(script)
    script:yield()
    if cocaine:is_enabled() == true then
        autoGetCokeCargo = not autoGetCokeCargo
        if autoGetCokeCargo then
            globals.set_int(1662873 + 1 + 4, 1)
            gui.show_message("可卡因锁定", "补充您的可卡因锁定，请稍候...")
            sleep(0.5)
        end
    end
end)
toolTip(mcBus, "补充您的可卡因禁闭用品")
fakeCash = mcBus:add_checkbox("补给假钞（循环）)")
script.register_looped("autoGetCashCargo", function(script)
    script:yield()
    if fakeCash:is_enabled() == true then
        autoGetCashCargo = not autoGetCashCargo
        if autoGetCashCargo then
            globals.set_int(1662873 + 1 + 0, 1)
            gui.show_message("假钞", "补货时请稍候...")
            sleep(0.5)
        end
    end
end)
toolTip(mcBus, "补充您的假钞用品")
mcBus:add_separator()
mcBus:add_button("补给全部", function()
globals.set_int(1662873 + 1 + 6, 1)
globals.set_int(1662873 + 1 + 6, 1)
globals.set_int(1662873 + 1 + 6, 1) -- Acid Lab Supplies
gui.show_message("致幻实验室", "为您的致幻实验室补给")
globals.set_int(1662873 + 1 + 5, 1)
globals.set_int(1662873 + 1 + 5, 1)
globals.set_int(1662873 + 1 + 5, 1) -- Bunker Supplies
gui.show_message("地堡", "补给你的地堡")
globals.set_int(1662873 + 1 + 1, 1)
globals.set_int(1662873 + 1 + 1, 1)
globals.set_int(1662873 + 1 + 1, 1) -- Document Forge Supplies
gui.show_message("文档伪造“、”补充您的 文档伪造")
globals.set_int(1662873 + 1 + 2, 1)
globals.set_int(1662873 + 1 + 2, 1)
globals.set_int(1662873 + 1 + 2, 1) -- Weed Farm Supplies
gui.show_message("大麻农场", "为您的大麻补给")
globals.set_int(1662873 + 1 + 3, 1)
globals.set_int(1662873 + 1 + 3, 1)
globals.set_int(1662873 + 1 + 3, 1) -- Meth Lab Suplies
gui.show_message("冰毒实验室", "为您的冰毒实验室提供补给")
globals.set_int(1662873 + 1 + 4, 1)
globals.set_int(1662873 + 1 + 4, 1)
globals.set_int(1662873 + 1 + 4, 1) -- Cocaine Lockup Supplies
gui.show_message("可卡因锁定", "补充你的可卡因锁定")
end)
toolTip(mcBus, "为所有企业补充所有物资")
mcBus:add_sameline()
mcBus:add_button("快速生产", function()
    globals.set_int(262145 + 17599, 25500) -- prod time for weed
    globals.set_int(262145 + 17600, 25500) -- prod time for meth
    globals.set_int(262145 + 17601, 25500) -- prod time for cocaine
    globals.set_int(262145 + 17602, 25500) -- prod time for document forge
    globals.set_int(262145 + 17603, 25500) -- prod time for cash
    --globals.set_int(262145 + 17632, 10000)
    gui.show_message("生产速度", "所有企业的生产速度都加快了")
    gui.show_message("生产速度", "在工人完成第一个产品之前，生产速度的提高不会开始，保持供应以填充产品条")
end)
toolTip(mcBus, "激活所有MC业务的快速生产（按下按钮后阅读右上角的信息)")
mcBus:add_sameline()
mcBus:add_button("提高销售价格", function()
    globals.set_int(262145 + 17632, 15000) -- price for weed
    globals.set_int(262145 + 17631, 60000) -- price for meth
    globals.set_int(262145 + 17630, 100000) -- price for cocaine
    globals.set_int(262145 + 17628, 20000) -- price for document forge
    globals.set_int(262145 + 17629, 30000) -- price for cash
    --globals.set_int(262145 + 17632, 10000)
    gui.show_message("产值", "所有业务的产值均有所增加")
end)
toolTip(mcBus, "将所有MC业务的销售价格提高到每个100万以上")
mcBus:add_separator()
mcBus:add_text("摩托车俱乐部更名")
local mcName = ""
mcBus:add_imgui(function()
    if is_typing then
        PAD.DISABLE_ALL_CONTROL_ACTIONS(0)
    end
    mcName, used = ImGui.InputText("摩托车俱乐部 名字", mcName, 256)
    if ImGui.IsItemActive() then
        is_typing = true
    else
        is_typing = false
    end
end)
toolTip(mcBus, "将您的 摩托车俱乐部 名称更改为您想要的任何名称")
checkBoxes = {}
labels = {"R* Verified Icon", "R* Icon", "R* Created Icon", "Lock Icon", "Copyright"}
values = {"&#166;", "&#8721;", "&#8249;", "&#937;", "&#169;"}
labels1 = {"R* 已验证的图标", "R* 图标", "R* 创建图标", "锁定图标", "版权"}
for i, label in ipairs(labels) do
    checkBox = mcBus:add_checkbox(labels1[i])
    if #labels ~= i then
        mcBus:add_sameline()
    end
    table.insert(checkBoxes, checkBox)
    toolTip(mcBus, "切换图标以与您的 摩托车俱乐部 名称一起使用")
end

mcBus:add_button("更改 摩托车俱乐部 名称", function()
    MPX = PI
    PI = stats.get_int("MPPLY_LAST_MP_CHAR")
    if PI == 0 then
        MPX = "MP0_"
    else
        MPX = "MP1_"
    end
    script.run_in_fiber(function (script)
        for i, checkBox in ipairs(checkBoxes) do
            if checkBox:is_enabled() then
                if labels[i] == "Copyright" then
                    STATS.STAT_SET_STRING(joaat(MPX .. "MC_GANG_NAME"), values[i].. " ", true)
                    STATS.STAT_SET_STRING(joaat(MPX .. "MC_GANG_NAME2"), mcName, true)
                    local MCnTwo = STATS.STAT_GET_STRING(joaat(MPX .. "MC_GANG_NAME2"), -1)
                    gui.show_message("摩托车俱乐部", "您的摩托车俱乐部名称已更改为 " .. mcName .. "，游戏返回 " .. labels[i] .. " " .. MCnTwo .. "。更改会话以应用。")
                    SessionChanger(0)
                    return
                else
                    STATS.STAT_SET_STRING(joaat(MPX .. "MC_GANG_NAME"), mcName, true)
                    STATS.STAT_SET_STRING(joaat(MPX .. "MC_GANG_NAME2"), values[i].. " ", true)
                    local MCnOne = STATS.STAT_GET_STRING(joaat(MPX .. "MC_GANG_NAME"), -1)
                    gui.show_message("摩托车俱乐部", "您的 摩托车俱乐部 名称已更改为 ".. mcName .. " 游戏返回 ".. labels[i].. " - ".. MCnOne.. ". 更改要应用的会话")
                    SessionChanger(0)
                    return
                end
            end
        end
        STATS.STAT_SET_STRING(joaat(MPX .. "MC_GANG_NAME"), "", true)
        STATS.STAT_SET_STRING(joaat(MPX .. "MC_GANG_NAME2"), mcName, true)
        local MCnTwo = STATS.STAT_GET_STRING(joaat(MPX .. "MC_GANG_NAME2"), -1)
        gui.show_message("摩托车俱乐部", "您的 摩托车俱乐部 名称已更改为 ".. mcName .. " 游戏返回 "..MCnTwo..". 更改要应用的会话")
        SessionChanger(0)
    end)
end)
toolTip(mcBus, "应用更改并切换战局.")
script.register_looped("mcNameCB", function(mcName)
    cbE = 0
    for i, checkBox in ipairs(checkBoxes) do
        if checkBox:is_enabled() then
            cbE = cbE + 1
        end
        if cbE > 1 then
            checkBox:set_enabled(false)
            gui.show_message("图标", "您只能选中一个复选框")
        end
    end
end)

local arcade = Business:add_tab("游戏厅")

MPX = PI
PI = stats.get_int("MPPLY_LAST_MP_CHAR")
if PI == 0 then
    MPX = "MP0_"
else
    MPX = "MP1_"
end

local arcadeSafe = arcade:add_checkbox("游戏厅安全循环")
script.register_looped("arcadeloop", function(script)
    script:yield()
    if arcadeSafe:is_enabled() == true then
        gui.show_message("业务经理", "向游戏厅保险柜提供资金")
        STATS.STAT_SET_INT(joaat(MPX .. "ARCADE_SAFE_CASH_VALUE"), 2000, true)
        STATS.STAT_SET_INT(joaat(MPX .. "ARCADE_PAY_TIME_LEFT"), -1, true)
        sleep(0.5)
    end
end)
toolTip(arcade, "用钱填满你的游戏厅保险箱")
-- Nightclub Loop - L7Neg
local Club = Business:add_tab("夜总会")

MPX = PI
PI = stats.get_int("MPPLY_LAST_MP_CHAR")
if PI == 0 then
    MPX = "MP0_"
else
    MPX = "MP1_"
end

nClub = Club:add_checkbox("夜总会安全循环")
script.register_looped("nightclubloop", function(script)
    script:yield()
    if nClub:is_enabled() == true then
        gui.show_message("业务经理", "向夜总会保险箱提供 50k/s")
        STATS.STAT_SET_INT(joaat(MPX .. "CLUB_POPULARITY"), 1000, true)
        STATS.STAT_SET_INT(joaat(MPX .. "CLUB_PAY_TIME_LEFT"), -1, true)
        sleep(0.5)
    end
end)
toolTip(Club, "用钱填满你的夜总会保险箱")
Club:add_separator()
Club:add_button("最大 夜总会 人气", function()
    STATS.STAT_SET_INT(joaat(MPX .. "CLUB_POPULARITY"), 1000, true)
end)
toolTip(Club, "最大限度地提高您的夜总会人气")
local CEO = Business:add_tab("CEO")

CEO:add_button("注册成为CEO", function()
    -- -1 is off, 0 is on
    playerID = PLAYER.PLAYER_ID()
    g = 1886967 + (playerID * 609) + 10
    gb1 = globals.get_int(g + 1)
    gb2 = globals.get_int(g + 430)
    if gb1 == playerID and gb2 == 0 then
        globals.set_int(g + 1, -1)
        globals.set_int(g + 430, -1)
        gui.show_message("CEO", "你不再是 CEO")
    else
        globals.set_int(g + 1, playerID)
        globals.set_int(g + 430, 0)
        gui.show_message("CEO", "你现在是一个 CEO")
    end
end)
toolTip(CEO, "注册为 CEO")
local setName = ""
CEO:add_imgui(function()
    if is_typing then
        PAD.DISABLE_ALL_CONTROL_ACTIONS(0)
    end
    setName, used = ImGui.InputText("组织名称", setName, 256)
    if ImGui.IsItemActive() then
        is_typing = true
    else
        is_typing = false
    end
end)
toolTip(CEO, "将您的 CEO 姓名更改为您想要的任何名称.")

checkBoxes = {}
labels1 = {"R* 已验证的图标", "R* 图标", "R* 创建图标", "锁定图标", "版权"}
labels = {"R* Verified Icon", "R* Icon", "R* Created Icon", "Lock Icon", "Copyright"}
values = {"&#166;", "&#8721;", "&#8249;", "&#937;", "&#169;"}

for i, label in ipairs(labels) do
    checkBox = CEO:add_checkbox(labels1[i])
    if #labels ~= i then
        CEO:add_sameline()
    end
    table.insert(checkBoxes, checkBox)
    toolTip(CEO, "切换要与您的 CEO 姓名一起使用的图标")
end

CEO:add_button("更改CEO姓名", function()
    MPX = PI
    PI = stats.get_int("MPPLY_LAST_MP_CHAR")
    if PI == 0 then
        MPX = "MP0_"
    else
        MPX = "MP1_"
    end
    script.run_in_fiber(function (script)
        for i, checkBox in ipairs(checkBoxes) do
            if checkBox:is_enabled() then
                if labels[i] == "Copyright" then
                    STATS.STAT_SET_STRING(joaat(MPX .. "GB_OFFICE_NAME"), values[i].. " ", true)
                    STATS.STAT_SET_STRING(joaat(MPX .. "GB_OFFICE_NAME2"), setName, true)
                    local MCnTwo = STATS.STAT_GET_STRING(joaat(MPX .. "GB_OFFICE_NAME2"), -1)
                    gui.show_message("摩托车俱乐部", "您的 CEO 姓名已更改为 ".. setName .. " 游戏返回 ".. labels[i].. " ".. MCnTwo.. ". 更改要应用的会话")
                    SessionChanger(0)
                    return
                else
                    STATS.STAT_SET_STRING(joaat(MPX .. "GB_OFFICE_NAME"), setName, true)
                    STATS.STAT_SET_STRING(joaat(MPX .. "GB_OFFICE_NAME2"), values[i].. " ", true)
                    local MCnOne = STATS.STAT_GET_STRING(joaat(MPX .. "GB_OFFICE_NAME"), -1)
                    gui.show_message("CEO", "您的 CEO 姓名已更改为 ".. setName .. " 游戏返回 ".. labels[i].. " - ".. MCnOne.. ". 更改要应用的会话")
                    SessionChanger(0)
                    return
                end
            end
        end
        STATS.STAT_SET_STRING(joaat(MPX .. "GB_OFFICE_NAME"), "", true)
        STATS.STAT_SET_STRING(joaat(MPX .. "GB_OFFICE_NAME2"), setName, true)
        local MCnTwo = STATS.STAT_GET_STRING(joaat(MPX .. "GB_OFFICE_NAME2"), -1)
        gui.show_message("CEO", "您的 CEO 姓名已更改为 ".. setName .. " 游戏返回 "..MCnTwo..". 更改要应用的会话")
        SessionChanger(0)
    end)
end)
toolTip(CEO, "应用更改并切换战局")
-- YimCEO -- Alestarov_Menu
local yimCEO = CEO:add_tab("Yim CEO")

cratevalue = 10000
yimCEO:add_imgui(function()
    cratevalue, used = ImGui.SliderInt("板条箱价值", cratevalue, 10000, 5000000)
    if used then
        globals.set_int(262145 + 15991, cratevalue)
    end
end)
toolTip(yimCEO, "设置所需的板条箱值")
yCEO = yimCEO:add_checkbox("Enable YimCeo")
toolTip(yimCEO, "设置值，启用yimCEO，然后单击显示计算机并转到特殊货物>出售")
yimCEO:add_button("显示电脑", function()
    SCRIPT.REQUEST_SCRIPT("apparcadebusinesshub")
    SYSTEM.START_NEW_SCRIPT("apparcadebusinesshub", 8344)
end)
toolTip(yimCEO, "点击显示主电脑（可能需要点击两次)")
script.register_looped("yimceoloop", function(script)
    cratevalue = globals.get_int(262145 + 15991)
    globals.set_int(262145 + 15756, 0)
    globals.set_int(262145 + 15757, 0)
    script:yield()

    while true do
        script:sleep(1000)  -- Adjust the sleep duration as needed

        if yCEO:is_enabled() == true then
        gui.show_message("已启用 YimCEO!", "享受银行存款!")
            if locals.get_int("appsecuroserv", 2) == 1 then
                script:sleep(500)
                locals.set_int("appsecuroserv", 740, 1)
                script:sleep(200)
                locals.set_int("appsecuroserv", 739, 1)
                script:sleep(200)
                locals.set_int("appsecuroserv", 558, 3012)
                script:sleep(1000)
            end 
            if locals.get_int("gb_contraband_sell", 2) == 1 then
                locals.set_int("gb_contraband_sell", 543 + 595, 1)
                locals.set_int("gb_contraband_sell", 543 + 55, 0)
                locals.set_int("gb_contraband_sell", 543 + 584, 0)
                locals.set_int("gb_contraband_sell", 543 + 7, 7)
                script:sleep(500)
                locals.set_int("gb_contraband_sell", 543 + 1, 99999)
            end
            if locals.get_int("gb_contraband_buy", 2) == 1 then
                locals.set_int("gb_contraband_buy", 601 + 5, 1)
                locals.set_int("gb_contraband_buy", 601 + 191, 6)
                locals.set_int("gb_contraband_buy", 601 + 192, 4)
                gui.show_message("Warehouse full!")
            end
        end
    end
end)

yimCEO:add_separator()
yimCEO:add_text("快速 CEO yimCEO（如何)")
yimCEO:add_separator()
yimCEO:add_text("使用前切换为仅限邀请的大厅！")
yimCEO:add_text("1) 点击'启用YimCeo'")
yimCEO:add_text("2) 选择所需的板条箱值（10k 至 5m)")
yimCEO:add_text("3) 点击“显示电脑”，选择“特殊货物”，点击“出售货物”并等待")
yimCEO:add_text("4) 使用“统计信息”选项卡重置您的统计信息并更改要应用的会话")
yimCEO:add_text("如果它告诉您您的仓库是空的，请关闭板条箱中的 1 件商品，然后在之后再次运行.")
yimCEO:add_separator()
yimCEO:add_text("您每次都需要手动点击特价/出售货物.")
yimCEO:add_text("有时你也可能得到超过500m的5k.")

--Required Stats--

FMC2020 = "fm_mission_controller_2020"
HIP = "heist_island_planning"

-- Editor Stuff // Mashup Scripts L7Neg/Alestarov
local heistEditor = KAOS:add_tab("抢劫编辑器")
    MPX = PI
    PI = stats.get_int("MPPLY_LAST_MP_CHAR")
    if PI == 0 then
        MPX = "MP0_"
    else
        MPX = "MP1_"
    end

heistTab = heistEditor:add_tab("公寓抢劫")

player = PLAYER.PLAYER_PED_ID()
coords = ENTITY.GET_ENTITY_COORDS(player, true)

heistIndex = 0

function tp(x, y, z, pitch, yaw, roll)
    player = PLAYER.PLAYER_PED_ID()
    ENTITY.SET_ENTITY_COORDS(player, x, y, z - 1, true, false, false, false)
    ENTITY.SET_ENTITY_ROTATION(player, pitch, yaw, roll, 0, true)
end

function MPX()
    return "MP" .. stats.get_int("MPPLY_LAST_MP_CHAR") .. "_"
end

function cuts(cut)
    script.run_in_fiber(function(cuts)
        control = 2
        enter = 201 --enter
        cancel = 202 --cancel
        globals.set_int(1928233 + 1 + 1, 100 - (cut * 4))
        globals.set_int(1928233 + 1 + 2, cut)
        globals.set_int(1928233 + 1 + 3, cut)
        globals.set_int(1928233 + 1 + 4, cut)
        PAD.SET_CONTROL_VALUE_NEXT_FRAME(control, enter, 1)
        cuts:sleep(1000)
        PAD.SET_CONTROL_VALUE_NEXT_FRAME(control, cancel, 1)
        cuts:sleep(1000)
        globals.set_int(1930201 + 3008 + 1, cut)
    end)
end

function fleecaCut()
    script.run_in_fiber(function(fleecaCuts)
        control = 2
        enter = 201 --enter
        cancel = 202 --cancel
        globals.set_int(1928233 + 1 + 1, 100 - (7453 * 2))
        globals.set_int(1928233 + 1 + 2, 7453)
        PAD.SET_CONTROL_VALUE_NEXT_FRAME(control, enter, 1)
        fleecaCuts:sleep(1000)
        PAD.SET_CONTROL_VALUE_NEXT_FRAME(control, cancel, 1)
        fleecaCuts:sleep(1000)
        globals.set_int(1930201 + 3008 + 1, 7453)
    end)
end

function bringTeam()
    script.run_in_fiber(function(bringteam)
        for i = 1, 3 do
            if (ENTITY.DOES_ENTITY_EXIST(PLAYER.GET_PLAYER_PED(i)) and calcDistance(player, PLAYER.GET_PLAYER_PED(i)) >= 20 and PLAYER.GET_PLAYER_TEAM(i) == PLAYER.GET_PLAYER_TEAM(PLAYER.PLAYER_ID())) then
                command.call( "bring", {i})
                bringteam:yield()
            end
        end
    end)
end

function calcDistance(player, target)
    pos = ENTITY.GET_ENTITY_COORDS(player, true)
    tarpos = ENTITY.GET_ENTITY_COORDS(target, true)
    local dx = pos.x - tarpos.x
    local dy = pos.y - tarpos.y
    local dz = pos.z - tarpos.z
    local distance = math.sqrt(dx*dx + dy*dy + dz*dz)
    return distance
end

function calcDistanceFromCoords(player, target)
    pos = ENTITY.GET_ENTITY_COORDS(player, true)
    local dx = pos.x - target[1]
    local dy = pos.y - target[2]
    local dz = pos.z - target[3]
    local distance = math.sqrt(dx*dx + dy*dy + dz*dz)
    return distance
end

function calcDistanceFromTwoCoords(pos, tarpos)
    local dx = pos.x - tarpos.x
    local dy = pos.y - tarpos.y
    local dz = pos.z - tarpos.z
    local distance = math.sqrt(dx*dx + dy*dy + dz*dz)
    return distance
end

unlockHeist = heistTab:add_checkbox("玩不可用的抢劫")
toolTip(heistTab, "让您在公寓规划屏幕上播放灰色的抢劫案")

heistTab:add_imgui(function()
    if unlockHeist:is_enabled() then
        ImGui.Text("抢劫仍将显示为灰色，但您现在可以玩它")
    end
end)

heistTab:add_button("完成所有设置", function()
    stats.set_int(MPX .. "HEIST_PLANNING_STAGE", -1)
end)
toolTip(heistTab, "当前抢劫的完整设置")

heistTab:add_button("带来团队", function()
    bringTeam()
end)
toolTip(heistTab, "把你团队中的每一位球员都带到你身边")

heistTab:add_sameline()

heistTab:add_button("带上所有人", function()
    script.run_in_fiber(function(bringall)
        for i = 0, 3 do
            gui.show_message("距离", tostring(calcDistance(player, PLAYER.GET_PLAYER_PED(i))))
            if (ENTITY.DOES_ENTITY_EXIST(PLAYER.GET_PLAYER_PED(i)) and calcDistance(player, PLAYER.GET_PLAYER_PED(i)) >= 50) then
                command.call( "bring", {i})
                bringall:yield()
            end
        end
    end)
end)
toolTip(heistTab, "把大家带到你身边")

heistTab:add_button("生成Tailgater", function()
    script.run_in_fiber(function(script)
        player = PLAYER.PLAYER_PED_ID()
        coords = ENTITY.GET_ENTITY_COORDS(player, true)
        while not STREAMING.HAS_MODEL_LOADED(joaat("tailgater")) do
            STREAMING.REQUEST_MODEL(joaat("tailgater"))
            script:yield()
        end
        vehicle = VEHICLE.CREATE_VEHICLE(joaat("tailgater"), coords.x, coords.y, coords.z, ENTITY.GET_ENTITY_HEADING(player), true, false, false)
        PED.SET_PED_INTO_VEHICLE(player ,vehicle, -1)
    end)
end)
toolTip(heistTab, "生成tailgater（4门）")

heistTab:add_sameline()

heistTab:add_button("TP到目标", function()
    command.call("objectivetp", {})
end)
toolTip(heistTab, "将自己传送到当前目标")

heistTab:add_button("生命值 +5", function()
    if SCRIPT.GET_NUMBER_OF_THREADS_RUNNING_THE_SCRIPT_WITH_THIS_HASH(joaat("fm_mission_controller_2020")) ~= 0 then 
        network.force_script_host("fm_mission_controller_2020")
        c_tlives_v = locals.get_int("fm_mission_controller_2020", 55004 + 873 + 1)
        locals.set_int("fm_mission_controller_2020", 55004 + 873 + 1, c_tlives_v + 5)
    end
    if SCRIPT.GET_NUMBER_OF_THREADS_RUNNING_THE_SCRIPT_WITH_THIS_HASH(joaat("fm_mission_controller")) ~= 0 then 
        network.force_script_host("fm_mission_controller")
        globals.set_int(4718592 + 3318 + 1 + 38, 1)
        c_tlives_v = locals.get_int("fm_mission_controller", 26154 + 1325 + 1)
        locals.set_int("fm_mission_controller", 26154 + 1325 + 1, c_tlives_v + 5)
    end
end)
toolTip(heistTab, "生命值增加 5")

shootEnemies = heistTab:add_checkbox("杀死敌人")
toolTip(heistTab, "射击 150 米内的所有敌人")

heistTab:add_imgui(function()
    --PAD.DISABLE_ALL_CONTROL_ACTIONS(2)
    PAD.DISABLE_CONTROL_ACTION(2, 237, true)

    objectiveText = globals.get_string(1574764 + 16)
    tpdValk = false
    tpdParkingLot = false
    heistIndex = ImGui.Combo("抢劫", heistIndex, {"全福银行", "越狱", "人道实验室", "A轮融资", "太平洋标准"}, 5, 5)
    toolTip("", "您要编辑的抢劫案")
    if heistIndex == 0 then -- fleeca
        ImGui.Text("最快的黑客")
        if (ImGui.Button("1500 万次分红")) then
            fleecaCut()
        end
        toolTip("", "将每个玩家切入设置为 1500 万\n在点击之前必须将鼠标悬停在您的切入上")
        if ImGui.Button("绕过黑客") then
            locals.set_int("fm_mission_controller", 11776 + 24, 7)
        end
        toolTip("", "立即完成黑客攻击")
        if ImGui.Button("绕过或破解钻机") then
            locals.set_float("fm_mission_controller", 10067 + 11, 100)
        end
        toolTip("", "立即完成钻孔")
    end
    if heistIndex == 1 then -- prison break
        ImGui.Text("作为监狱官员最快")
        if (ImGui.Button("1500 万")) then
            cuts(2142)
        end
        toolTip("", "将每个玩家切入设置为 1500 万\n在点击之前必须将鼠标悬停在您的切入上")
        if (ImGui.Button("TP Prison Bus")) then
            script.run_in_fiber(function(pbus)
                for i, vehicle in ipairs(entities.get_all_vehicles_as_handles()) do
                    player = PLAYER.PLAYER_PED_ID()
                    blip = HUD.GET_BLIP_FROM_ENTITY(vehicle)
                    if (ENTITY.GET_ENTITY_MODEL(vehicle) == joaat("pbus") and blip == 133955592) then
                        PED.SET_PED_INTO_VEHICLE(player, vehicle, -1)
                        pbus:sleep(100)
                        PED.SET_PED_COORDS_KEEP_VEHICLE(player, -774.57, 288.42, 85.79)
                    end
                end
            end)
        end
        toolTip("", "将监狱巴士传送到日食塔公寓前")
    end
    if heistIndex == 2 then -- humane labs
        ImGui.Text("作为地面团队最快的")
        if ImGui.Button("15 百万") then
            cuts(1587)
        end
        toolTip("", "将每个玩家切入设置为 1500 万\n在点击之前必须将鼠标悬停在您的切入上")
        if ImGui.Button("TP 到 Valkeryie(直升机)") then
            for i, vehicle in ipairs(entities.get_all_vehicles_as_handles()) do
                if (ENTITY.GET_ENTITY_MODEL(vehicle) == joaat("valkyrie")) then
                    player = PLAYER.PLAYER_PED_ID()
                    PED.SET_PED_INTO_VEHICLE(player, vehicle, 2)
                    PED.SET_PED_COORDS_KEEP_VEHICLE(player, -774.57, 288.42, 85.79)
                end
            end
        end
        toolTip("", "将女武神传送到日食塔公寓前")
        if ImGui.Button("隧道") then
            player = PLAYER.PLAYER_PED_ID()
            ENTITY.SET_ENTITY_COORDS_NO_OFFSET(player, 3521.90, 3724.84, -9.47, true, false, false)
        end
    end
    if heistIndex == 3 then -- series a funding
        if ImGui.Button("15 百万 ") then
            cuts(2121)
        end
        toolTip("", "将每个玩家切入设置为 1500 万\n在点击之前必须将鼠标悬停在您的切入上")
    end
    if heistIndex == 4 then -- pacific standard
        if (ImGui.Button("15 百万")) then
            cuts(1000)
        end
        toolTip("", "将每个玩家切入设置为 1500 万\n在点击之前必须将鼠标悬停在您的切入上")
    end
end)

heistTab:add_imgui(function()
    if (ImGui.TreeNode("自述 - 重要!")) then
        ImGui.Text("用于完成设置")
        ImGui.Text("如果您在过场动画后进入计划屏幕")
        ImGui.Text("您可以单击它，然后向上、向下、向左或向右滚动")
        ImGui.Text("它应该将您踢出屏幕并完成设置")
        ImGui.Separator()
        ImGui.Text("1500 万分红")
        ImGui.Text("将鼠标悬停在剪切上，然后单击按钮")
    end
    toolTip("", "使用此脚本的重要信息")
end)

script.register_looped("heistTabLoop", function(heistTabScript)
    if unlockHeist:is_enabled() then
        globals.set_int(1933381 + 420, 31)
    end

    if  shootEnemies:is_enabled() then
        local pedtable = entities.get_all_peds_as_handles()
        for _, peds in pairs(pedtable) do
            local selfpos = ENTITY.GET_ENTITY_COORDS(PLAYER.PLAYER_PED_ID(), true)
            local ped_pos = ENTITY.GET_ENTITY_COORDS(peds, false)
            if (PED.GET_RELATIONSHIP_BETWEEN_PEDS(peds, PLAYER.PLAYER_PED_ID()) == 4 or PED.GET_RELATIONSHIP_BETWEEN_PEDS(peds, PLAYER.PLAYER_PED_ID()) == 5 or HUD.GET_BLIP_COLOUR(HUD.GET_BLIP_FROM_ENTITY(peds)) == 1 or HUD.GET_BLIP_COLOUR(HUD.GET_BLIP_FROM_ENTITY(peds)) == 49 or ENTITY.GET_ENTITY_MODEL(peds) == joaat("S_M_Y_Swat_01") or ENTITY.GET_ENTITY_MODEL(peds) == joaat("S_M_Y_Cop_01") or ENTITY.GET_ENTITY_MODEL(peds) == joaat("S_F_Y_Cop_01") or ENTITY.GET_ENTITY_MODEL(peds) == joaat("S_M_Y_Sheriff_01") or ENTITY.GET_ENTITY_MODEL(peds) == joaat("S_F_Y_Sheriff_01")) and peds ~= PLAYER.PLAYER_PED_ID() and not PED.IS_PED_DEAD_OR_DYING(peds,true)  and PED.IS_PED_A_PLAYER(peds) ~= 1 and calcDistance(PLAYER.PLAYER_PED_ID(), peds) <= 100 then 
                if PED.IS_PED_IN_ANY_VEHICLE(peds, true) then
                    request_control(peds)
                    TASK.CLEAR_PED_TASKS_IMMEDIATELY(peds)
                    ped_pos = ENTITY.GET_ENTITY_COORDS(peds, false)
                    MISC.SHOOT_SINGLE_BULLET_BETWEEN_COORDS(ped_pos.x, ped_pos.y, ped_pos.z + 1, ped_pos.x, ped_pos.y, ped_pos.z, 1000, true, 2526821735, PLAYER.PLAYER_PED_ID(), false, true, 1.0)
                else
                    MISC.SHOOT_SINGLE_BULLET_BETWEEN_COORDS(ped_pos.x, ped_pos.y, ped_pos.z + 1, ped_pos.x, ped_pos.y, ped_pos.z, 1000, true, 2526821735, PLAYER.PLAYER_PED_ID(), false, true, 1.0)
                end
            end
        end
    end


end)

local casinoHeist = heistEditor:add_tab("赌场抢劫编辑器")
casinoHeist:add_text("赌场抢劫设置")

casinoHeist:add_button("隐迹潜综", function()
    STATS.STAT_SET_INT(joaat(MPX .. "H3OPT_APPROACH"), 1, true)
    STATS.STAT_SET_INT(joaat(MPX .. "H3_LAST_APPROACH"), 3, true)
    STATS.STAT_SET_INT(joaat(MPX .. "H3OPT_TARGET"), 3, true)
    STATS.STAT_SET_INT(joaat(MPX .. "H3OPT_BITSET1"), 127, true)
    STATS.STAT_SET_INT(joaat(MPX .. "H3OPT_DISRUPTSHIP"), 3, true)
    STATS.STAT_SET_INT(joaat(MPX .. "H3OPT_KEYLEVELS"), 2, true)
    STATS.STAT_SET_INT(joaat(MPX .. "H3OPT_CREWWEAP"), 4, true)
    STATS.STAT_SET_INT(joaat(MPX .. "H3OPT_CREWDRIVER"), 5, true)
    STATS.STAT_SET_INT(joaat(MPX .. "H3OPT_CREWHACKER"), 5, true)
    STATS.STAT_SET_INT(joaat(MPX .. "H3OPT_VEHS"), 2, true)
    STATS.STAT_SET_INT(joaat(MPX .. "H3OPT_WEAPS"), 1, true)
    STATS.STAT_SET_INT(joaat(MPX .. "H3OPT_BITSET0"), 262399, true)
    STATS.STAT_SET_INT(joaat(MPX .. "H3OPT_MASKS"), 2, true)
    gui.show_message("赌场抢劫", "设置隐迹潜综应用")
end)
casinoHeist:add_sameline()
casinoHeist:add_button("兵不厌诈", function()
    STATS.STAT_SET_INT(joaat(MPX .. "H3OPT_APPROACH"), 2, true)
    STATS.STAT_SET_INT(joaat(MPX .. "H3_LAST_APPROACH"), 3, true)
    STATS.STAT_SET_INT(joaat(MPX .. "H3OPT_TARGET"), 3, true)
    STATS.STAT_SET_INT(joaat(MPX .. "H3OPT_BITSET1"), 799, true)
    STATS.STAT_SET_INT(joaat(MPX .. "H3OPT_DISRUPTSHIP"), 3, true)
    STATS.STAT_SET_INT(joaat(MPX .. "H3OPT_KEYLEVELS"), 2, true)
    STATS.STAT_SET_INT(joaat(MPX .. "H3OPT_CREWWEAP"), 4, true)
    STATS.STAT_SET_INT(joaat(MPX .. "H3OPT_CREWDRIVER"), 5, true)
    STATS.STAT_SET_INT(joaat(MPX .. "H3OPT_CREWHACKER"), 5, true)
    STATS.STAT_SET_INT(joaat(MPX .. "H3OPT_VEHS"), 2, true)
    STATS.STAT_SET_INT(joaat(MPX .. "H3OPT_WEAPS"), 0, true)
    STATS.STAT_SET_INT(joaat(MPX .. "H3OPT_BITSET0"), 913623, true)
    STATS.STAT_SET_INT(joaat(MPX .. "H3OPT_MASKS"), 2, true)
    gui.show_message("赌场抢劫", "设置 兵不厌诈 已应用")
    gui.show_message("赌场抢劫", "兵不厌诈 可能不起作用，使用 隐迹潜综 或 气势汹汹 设置.")
end)
casinoHeist:add_sameline()
casinoHeist:add_button("气势汹汹", function()
    STATS.STAT_SET_INT(joaat(MPX .. "H3OPT_APPROACH"), 3, true)
    STATS.STAT_SET_INT(joaat(MPX .. "H3_LAST_APPROACH"), 1, true)
    STATS.STAT_SET_INT(joaat(MPX .. "H3OPT_TARGET"), 3, true)
    STATS.STAT_SET_INT(joaat(MPX .. "H3OPT_BITSET1"), 799, true)
    STATS.STAT_SET_INT(joaat(MPX .. "H3OPT_DISRUPTSHIP"), 3, true)
    STATS.STAT_SET_INT(joaat(MPX .. "H3OPT_KEYLEVELS"), 2, true)
    STATS.STAT_SET_INT(joaat(MPX .. "H3OPT_CREWWEAP"), 4, true)
    STATS.STAT_SET_INT(joaat(MPX .. "H3OPT_CREWDRIVER"), 5, true)
    STATS.STAT_SET_INT(joaat(MPX .. "H3OPT_CREWHACKER"), 5, true)
    STATS.STAT_SET_INT(joaat(MPX .. "H3OPT_VEHS"), 2, true)
    STATS.STAT_SET_INT(joaat(MPX .. "H3OPT_WEAPS"), 1, true)
    STATS.STAT_SET_INT(joaat(MPX .. "H3OPT_BITSET0"), 1835223, true)
    STATS.STAT_SET_INT(joaat(MPX .. "H3OPT_MASKS"), 2, true)
    gui.show_message("赌场抢劫", "设置气势汹汹应用")
end)

casinoHeist:add_separator()

casinoHeist:add_button("完成准备工作", function()
    STATS.STAT_SET_INT(joaat(MPX .. "H3OPT_DISRUPTSHIP"), 3, true)
    STATS.STAT_SET_INT(joaat(MPX .. "H3OPT_KEYLEVELS"), 2, true)
    STATS.STAT_SET_INT(joaat(MPX .. "H3OPT_VEHS"), 3, true)
    STATS.STAT_SET_INT(joaat(MPX .. "H3OPT_WEAPS"), 0, true)
    STATS.STAT_SET_INT(joaat(MPX .. "H3OPT_BITSET0"), -1, true)
    STATS.STAT_SET_INT(joaat(MPX .. "H3OPT_BITSET1"), -1, true)
    STATS.STAT_SET_INT(joaat(MPX .. "H3OPT_COMPLETEDPOSIX"), -1, true)
    gui.show_message("赌场抢劫", "准备工作已完成!")
end)

casinoHeist:add_sameline()
casinoHeist:add_button("跳过冷却时间", function()
    STATS.STAT_SET_INT(joaat(MPX .. "H3_COMPLETEDPOSIX"), -1, true)
    STATS.STAT_SET_INT(joaat(MPX .. "MPPLY_H3_COOLDOWN"), -1, true)
end)
local deleteNPCs = casinoHeist:add_checkbox("删除任务NPC的")
    script.register_looped("deleteNPCsLoopScript", function(script)
        if deleteNPCs:is_enabled() then
            for index, ped in ipairs(entities.get_all_peds_as_handles()) do 
                ENTITY.SET_ENTITY_AS_MISSION_ENTITY(ped, true, true)
                PED.DELETE_PED(ped)
                sleep(0.1)
                PED.DELETE_PED(ped)
                sleep(0.1)
                PED.DELETE_PED(ped)
                sleep(0.1)
                PED.DELETE_PED(ped)
                sleep(0.1)
                gui.show_message("赌场抢劫", "从任务中删除所有NPC.")
            end
        end
    end)
casinoHeist:add_separator()
casinoHeist:add_text("怎么去使用:")
casinoHeist:add_text("点击跳过冷却时间（如果适用），然后支付 25k")
casinoHeist:add_text("之后，退出电路板并按下预设值.")

-- Cayo Heist Editor - converted from L7Negs Ultimate Menu for Kiddions and some features like remove CCTV from Alestarov.
local cayoHeist = heistEditor:add_tab("佩里科岛编辑器")

cayoHeist:add_text("非合法预设")

cayoHeist:add_button("黑豹/黄金（非法困难）", function()
    MPX = PI
    PI = stats.get_int("MPPLY_LAST_MP_CHAR")
    if PI == 0 then
        MPX = "MP0_"
    else
        MPX = "MP1_"
    end
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_BS_GEN"), 131071, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_BS_ENTR"), 63, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_BS_ABIL"), 63, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_WEAPONS"), 5, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_WEP_DISRP"), 3, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_ARM_DISRP"), 3, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_HEL_DISRP"), 3, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_TARGET"), 5, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_TROJAN"), 2, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_APPROACH"), -1, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_CASH_I"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_CASH_C"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_WEED_I"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_WEED_C"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_COKE_I"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_COKE_C"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_CASH_I"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_GOLD_I"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_GOLD_C"), -1, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_PAINT"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4_PROGRESS"), 131055, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_CASH_I_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_CASH_C_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_WEED_I_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_WEED_C_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_COKE_I_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_COKE_C_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_GOLD_I_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_GOLD_C_SCOPED"), -1, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_GOLD_V"), 1191817, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_PAINT_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4_MISSIONS"), 65535, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4_PLAYTHROUGH_STATUS"), 32, true)
    
    gui.show_message("抢劫岛", "黑豹困难模式已设置!")
    gui.show_message("抢劫岛", "重置主板以查看更改")
end)
cayoHeist:add_sameline()
cayoHeist:add_button("钻石/黄金（非法困难）", function()
    MPX = PI
PI = stats.get_int("MPPLY_LAST_MP_CHAR")
if PI == 0 then
    MPX = "MP0_"
else
    MPX = "MP1_"
end
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_BS_GEN"), 131071, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_BS_ENTR"), 63, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_BS_ABIL"), 63, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_WEAPONS"), 5, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_WEP_DISRP"), 3, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_ARM_DISRP"), 3, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_HEL_DISRP"), 3, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_TARGET"), 3, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_TROJAN"), 2, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_APPROACH"), -1, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_CASH_I"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_CASH_C"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_WEED_I"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_WEED_C"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_COKE_I"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_COKE_C"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_CASH_I"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_GOLD_I"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_GOLD_C"), -1, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_PAINT"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4_PROGRESS"), 131055, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_CASH_I_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_CASH_C_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_WEED_I_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_WEED_C_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_COKE_I_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_COKE_C_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_GOLD_I_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_GOLD_C_SCOPED"), -1, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_GOLD_V"), 1191817, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_PAINT_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4_MISSIONS"), 65535, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4_PLAYTHROUGH_STATUS"), 32, true)
    
    gui.show_message("抢劫岛", "钻石困难模式已设置！")
    gui.show_message("抢劫岛", "重置主板以查看更改")
end)

cayoHeist:add_sameline()
cayoHeist:add_button("债券/黄金（非法困难）", function()
    MPX = PI
PI = stats.get_int("MPPLY_LAST_MP_CHAR")
if PI == 0 then
    MPX = "MP0_"
else
    MPX = "MP1_"
end
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_BS_GEN"), 131071, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_BS_ENTR"), 63, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_BS_ABIL"), 63, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_WEAPONS"), 5, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_WEP_DISRP"), 3, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_ARM_DISRP"), 3, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_HEL_DISRP"), 3, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_TARGET"), 2, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_TROJAN"), 2, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_APPROACH"), -1, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_CASH_I"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_CASH_C"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_WEED_I"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_WEED_C"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_COKE_I"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_COKE_C"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_CASH_I"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_GOLD_I"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_GOLD_C"), -1, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_PAINT"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4_PROGRESS"), 131055, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_CASH_I_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_CASH_C_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_WEED_I_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_WEED_C_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_COKE_I_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_COKE_C_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_GOLD_I_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_GOLD_C_SCOPED"), -1, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_GOLD_V"), 1191817, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_PAINT_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4_MISSIONS"), 65535, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4_PLAYTHROUGH_STATUS"), 32, true)
    
    gui.show_message("抢劫岛", "债券困难模式已设置！")
    gui.show_message("抢劫岛", "重置主板以查看更改")
end)

cayoHeist:add_sameline()
cayoHeist:add_button("项链/金（非法困难）", function()
    MPX = PI
PI = stats.get_int("MPPLY_LAST_MP_CHAR")
if PI == 0 then
    MPX = "MP0_"
else
    MPX = "MP1_"
end
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_BS_GEN"), 131071, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_BS_ENTR"), 63, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_BS_ABIL"), 63, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_WEAPONS"), 5, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_WEP_DISRP"), 3, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_ARM_DISRP"), 3, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_HEL_DISRP"), 3, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_TARGET"), 1, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_TROJAN"), 2, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_APPROACH"), -1, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_CASH_I"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_CASH_C"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_WEED_I"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_WEED_C"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_COKE_I"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_COKE_C"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_CASH_I"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_GOLD_I"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_GOLD_C"), -1, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_PAINT"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4_PROGRESS"), 131055, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_CASH_I_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_CASH_C_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_WEED_I_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_WEED_C_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_COKE_I_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_COKE_C_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_GOLD_I_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_GOLD_C_SCOPED"), -1, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_GOLD_V"), 1191817, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_PAINT_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4_MISSIONS"), 65535, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4_PLAYTHROUGH_STATUS"), 32, true)
    
    gui.show_message("抢劫岛", "项链困难模式已设置！")
    gui.show_message("抢劫岛", "重置主板以查看更改")
end)

cayoHeist:add_sameline()
cayoHeist:add_button("龙舌兰酒/黄金（非法困难）", function()
    MPX = PI
PI = stats.get_int("MPPLY_LAST_MP_CHAR")
if PI == 0 then
    MPX = "MP0_"
else
    MPX = "MP1_"
end
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_BS_GEN"), 131071, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_BS_ENTR"), 63, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_BS_ABIL"), 63, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_WEAPONS"), 5, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_WEP_DISRP"), 3, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_ARM_DISRP"), 3, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_HEL_DISRP"), 3, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_TARGET"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_TROJAN"), 2, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_APPROACH"), -1, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_CASH_I"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_CASH_C"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_WEED_I"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_WEED_C"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_COKE_I"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_COKE_C"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_CASH_I"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_GOLD_I"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_GOLD_C"), -1, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_PAINT"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4_PROGRESS"), 131055, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_CASH_I_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_CASH_C_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_WEED_I_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_WEED_C_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_COKE_I_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_COKE_C_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_GOLD_I_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_GOLD_C_SCOPED"), -1, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_GOLD_V"), 1191817, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_PAINT_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4_MISSIONS"), 65535, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4_PLAYTHROUGH_STATUS"), 32, true)
    
    gui.show_message("抢劫岛", "龙舌兰酒困难模式已设置!")
    gui.show_message("抢劫岛", "重置主板以查看更改")
end)
cayoHeist:add_separator()
cayoHeist:add_text("合法预设")

cayoHeist:add_button("黑豹/金色（合法困难） ", function()
    MPX = PI
PI = stats.get_int("MPPLY_LAST_MP_CHAR")
if PI == 0 then
    MPX = "MP0_"
else
    MPX = "MP1_"
end
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_BS_GEN"), 131071, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_BS_ENTR"), 63, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_BS_ABIL"), 63, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_WEAPONS"), 5, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_WEP_DISRP"), 3, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_ARM_DISRP"), 3, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_HEL_DISRP"), 3, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_TARGET"), 5, true) --Primary Target Values: 0. Tequila, 1. Necklace, 2. Bonds, 3. Diamond, 4. Medrazo Files, 5. Panther
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_TROJAN"), 2, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_APPROACH"), -1, true)
        -- Island Loot // -1 shows all, 0 shows none
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_CASH_I"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_WEED_I"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_COKE_I"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_GOLD_I"), 0, true)
        
        -- Compound Loot // -1 shows all, 0 shows none
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_CASH_C"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_WEED_C"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_COKE_C"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_GOLD_C"), -1, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_PAINT"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4_PROGRESS"), 131055, true) -- 131055 // Hard Mode  -  130667 // Solo Normal??
        
        -- These are what is set when you find loot throughout the island/compound
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_CASH_I_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_CASH_C_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_WEED_I_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_WEED_C_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_COKE_I_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_COKE_C_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_GOLD_I_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_GOLD_C_SCOPED"), -1, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_PAINT_SCOPED"), 0, true)
        
        -- Payout Values // Set to "Normal" values.  Each value is multiplied by 8, bc there are 8 locations for them.
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_GOLD_V"), 45375, true)
        --STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_CASH_V"), 10406, true)
        --STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_WEED_V"), 16875, true)
        --STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_COKE_V"), 25312, true)
        --STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_PAINT_V"), 22500, true)
        globals.set_int(262145 + 30264, 1900000) -- Panther Value -- 1900000 shows as 2,090,000 in-game on the board. 190,000 difference.
        --globals.set_int(262145 + 30262, 1300000) -- Diamond Value  -- 1300000 shows as 1,430,000 in-game. 130,000 difference.
        --globals.set_int(262145 + 30261, 770000) -- Bonds Value -- 770000 shows as 847,000 in-game.  77,000 difference.
        --globals.set_int(262145 + 30260, 700000) -- Necklace Value -- 700000 shows as 770,000 in-game. 70,000 difference.
        --globals.set_int(262145 + 30259, 693000) -- Tequila Value -- 630000 shows as 693,000. 63,000 difference.
        
        STATS.STAT_SET_INT(joaat(MPX .. "H4_MISSIONS"), 65535, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4_PLAYTHROUGH_STATUS"), 32, true)
    
    gui.show_message("抢劫岛", "黑豹困难模式（合法）已经设置好了！")
    gui.show_message("抢劫岛", "重置主板以查看更改")
end)

cayoHeist:add_sameline()

cayoHeist:add_button("钻石/黄金（合法困难）", function()
    MPX = PI
PI = stats.get_int("MPPLY_LAST_MP_CHAR")
if PI == 0 then
    MPX = "MP0_"
else
    MPX = "MP1_"
end
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_BS_GEN"), 131071, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_BS_ENTR"), 63, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_BS_ABIL"), 63, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_WEAPONS"), 5, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_WEP_DISRP"), 3, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_ARM_DISRP"), 3, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_HEL_DISRP"), 3, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_TARGET"), 3, true) --Primary Target Values: 0. Tequila, 1. Necklace, 2. Bonds, 3. Diamond, 4. Medrazo Files, 5. Panther
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_TROJAN"), 2, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_APPROACH"), -1, true)
        -- Island Loot // -1 shows all, 0 shows none
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_CASH_I"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_WEED_I"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_COKE_I"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_GOLD_I"), 0, true)
        
        -- Compound Loot // -1 shows all, 0 shows none
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_CASH_C"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_WEED_C"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_COKE_C"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_GOLD_C"), -1, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_PAINT"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4_PROGRESS"), 131055, true) -- 131055 // Hard Mode  -  130667 // Solo Normal??
        
        -- These are what is set when you find loot throughout the island/compound
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_CASH_I_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_CASH_C_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_WEED_I_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_WEED_C_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_COKE_I_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_COKE_C_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_GOLD_I_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_GOLD_C_SCOPED"), -1, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_PAINT_SCOPED"), 0, true)
        
        -- Payout Values // Set to "Normal" values.  Each value is multiplied by 8, bc there are 8 locations for them.
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_GOLD_V"), 45375, true)
        --STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_CASH_V"), 10406, true)
        --STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_WEED_V"), 16875, true)
        --STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_COKE_V"), 25312, true)
        --STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_PAINT_V"), 22500, true)
        --globals.set_int(262145 + 30264, 1900000) -- Panther Value -- 1900000 shows as 2,090,000 in-game on the board. 190,000 difference.
        globals.set_int(262145 + 30262, 1300000) -- Diamond Value  -- 1300000 shows as 1,430,000 in-game. 130,000 difference.
        --globals.set_int(262145 + 30261, 770000) -- Bonds Value -- 770000 shows as 847,000 in-game.  77,000 difference.
        --globals.set_int(262145 + 30260, 700000) -- Necklace Value -- 700000 shows as 770,000 in-game. 70,000 difference.
        --globals.set_int(262145 + 30259, 693000) -- Tequila Value -- 630000 shows as 693,000. 63,000 difference.
        
        STATS.STAT_SET_INT(joaat(MPX .. "H4_MISSIONS"), 65535, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4_PLAYTHROUGH_STATUS"), 32, true)
    
    gui.show_message("抢劫岛", "钻石困难模式（合法）已设置！")
    gui.show_message("抢劫岛", "重置主板以查看更改")
end)

cayoHeist:add_sameline()

cayoHeist:add_button("债券/黄金（合法困难）", function()
    MPX = PI
PI = stats.get_int("MPPLY_LAST_MP_CHAR")
if PI == 0 then
    MPX = "MP0_"
else
    MPX = "MP1_"
end
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_BS_GEN"), 131071, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_BS_ENTR"), 63, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_BS_ABIL"), 63, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_WEAPONS"), 5, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_WEP_DISRP"), 3, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_ARM_DISRP"), 3, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_HEL_DISRP"), 3, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_TARGET"), 2, true) --Primary Target Values: 0. Tequila, 1. Necklace, 2. Bonds, 3. Diamond, 4. Medrazo Files, 5. Panther
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_TROJAN"), 2, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_APPROACH"), -1, true)
        -- Island Loot // -1 shows all, 0 shows none
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_CASH_I"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_WEED_I"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_COKE_I"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_GOLD_I"), 0, true)
        
        -- Compound Loot // -1 shows all, 0 shows none
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_CASH_C"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_WEED_C"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_COKE_C"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_GOLD_C"), -1, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_PAINT"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4_PROGRESS"), 131055, true) -- 131055 // Hard Mode  -  130667 // Solo Normal??
        
        -- These are what is set when you find loot throughout the island/compound
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_CASH_I_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_CASH_C_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_WEED_I_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_WEED_C_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_COKE_I_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_COKE_C_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_GOLD_I_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_GOLD_C_SCOPED"), -1, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_PAINT_SCOPED"), 0, true)
        
        -- Payout Values // Set to "Normal" values.  Each value is multiplied by 8, bc there are 8 locations for them.
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_GOLD_V"), 45375, true)
        --STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_CASH_V"), 10406, true)
        --STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_WEED_V"), 16875, true)
        --STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_COKE_V"), 25312, true)
        --STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_PAINT_V"), 22500, true)
        --globals.set_int(262145 + 30264, 1900000) -- Panther Value -- 1900000 shows as 2,090,000 in-game on the board. 190,000 difference.
        --globals.set_int(262145 + 30262, 1300000) -- Diamond Value  -- 1300000 shows as 1,430,000 in-game. 130,000 difference.
        globals.set_int(262145 + 30261, 770000) -- Bonds Value -- 770000 shows as 847,000 in-game.  77,000 difference.
        --globals.set_int(262145 + 30260, 700000) -- Necklace Value -- 700000 shows as 770,000 in-game. 70,000 difference.
        --globals.set_int(262145 + 30259, 693000) -- Tequila Value -- 630000 shows as 693,000. 63,000 difference.
        
        STATS.STAT_SET_INT(joaat(MPX .. "H4_MISSIONS"), 65535, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4_PLAYTHROUGH_STATUS"), 32, true)
    
    gui.show_message("抢劫岛", "已设置债券困难模式（合法）!")
    gui.show_message("抢劫岛", "重置主板以查看更改")
end)

cayoHeist:add_sameline()

cayoHeist:add_button("项链/黄金（合法困难）", function()
    MPX = PI
PI = stats.get_int("MPPLY_LAST_MP_CHAR")
if PI == 0 then
    MPX = "MP0_"
else
    MPX = "MP1_"
end
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_BS_GEN"), 131071, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_BS_ENTR"), 63, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_BS_ABIL"), 63, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_WEAPONS"), 5, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_WEP_DISRP"), 3, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_ARM_DISRP"), 3, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_HEL_DISRP"), 3, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_TARGET"), 1, true) --Primary Target Values: 0. Tequila, 1. Necklace, 2. Bonds, 3. Diamond, 4. Medrazo Files, 5. Panther
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_TROJAN"), 2, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_APPROACH"), -1, true)
        -- Island Loot // -1 shows all, 0 shows none
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_CASH_I"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_WEED_I"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_COKE_I"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_GOLD_I"), 0, true)
        
        -- Compound Loot // -1 shows all, 0 shows none
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_CASH_C"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_WEED_C"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_COKE_C"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_GOLD_C"), -1, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_PAINT"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4_PROGRESS"), 131055, true) -- 131055 // Hard Mode  -  130667 // Solo Normal??
        
        -- These are what is set when you find loot throughout the island/compound
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_CASH_I_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_CASH_C_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_WEED_I_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_WEED_C_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_COKE_I_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_COKE_C_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_GOLD_I_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_GOLD_C_SCOPED"), -1, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_PAINT_SCOPED"), 0, true)
        
        -- Payout Values // Set to "Normal" values.  Each value is multiplied by 8, bc there are 8 locations for them.
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_GOLD_V"), 45375, true)
        --STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_CASH_V"), 10406, true)
        --STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_WEED_V"), 16875, true)
        --STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_COKE_V"), 25312, true)
        --STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_PAINT_V"), 22500, true)
        --globals.set_int(262145 + 30264, 1900000) -- Panther Value -- 1900000 shows as 2,090,000 in-game on the board. 190,000 difference.
        --globals.set_int(262145 + 30262, 1300000) -- Diamond Value  -- 1300000 shows as 1,430,000 in-game. 130,000 difference.
        --globals.set_int(262145 + 30261, 770000) -- Bonds Value -- 770000 shows as 847,000 in-game.  77,000 difference.
        globals.set_int(262145 + 30260, 700000) -- Necklace Value -- 700000 shows as 770,000 in-game. 70,000 difference.
        --globals.set_int(262145 + 30259, 693000) -- Tequila Value -- 630000 shows as 693,000. 63,000 difference.
        
        STATS.STAT_SET_INT(joaat(MPX .. "H4_MISSIONS"), 65535, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4_PLAYTHROUGH_STATUS"), 32, true)
    
    gui.show_message("抢劫岛", "项链困难模式（合法）已设置!")
    gui.show_message("抢劫岛", "重置主板以查看更改")
end)

cayoHeist:add_sameline()

cayoHeist:add_button("龙舌兰酒/黄金（合法困难）", function()
    MPX = PI
PI = stats.get_int("MPPLY_LAST_MP_CHAR")
if PI == 0 then
    MPX = "MP0_"
else
    MPX = "MP1_"
end
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_BS_GEN"), 131071, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_BS_ENTR"), 63, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_BS_ABIL"), 63, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_WEAPONS"), 5, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_WEP_DISRP"), 3, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_ARM_DISRP"), 3, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_HEL_DISRP"), 3, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_TARGET"), 0, true) --Primary Target Values: 0. Tequila, 1. Necklace, 2. Bonds, 3. Diamond, 4. Medrazo Files, 5. Panther
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_TROJAN"), 2, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4CNF_APPROACH"), -1, true)
        -- Island Loot // -1 shows all, 0 shows none
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_CASH_I"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_WEED_I"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_COKE_I"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_GOLD_I"), 0, true)
        
        -- Compound Loot // -1 shows all, 0 shows none
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_CASH_C"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_WEED_C"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_COKE_C"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_GOLD_C"), -1, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_PAINT"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4_PROGRESS"), 131055, true) -- 131055 // Hard Mode  -  130667 // Solo Normal??
        
        -- These are what is set when you find loot throughout the island/compound
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_CASH_I_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_CASH_C_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_WEED_I_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_WEED_C_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_COKE_I_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_COKE_C_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_GOLD_I_SCOPED"), 0, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_GOLD_C_SCOPED"), -1, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_PAINT_SCOPED"), 0, true)
        
        -- Payout Values // Set to "Normal" values.  Each value is multiplied by 8, bc there are 8 locations for them.
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_GOLD_V"), 45375, true)
        --STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_CASH_V"), 10406, true)
        --STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_WEED_V"), 16875, true)
        --STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_COKE_V"), 25312, true)
        --STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_PAINT_V"), 22500, true)
        --globals.set_int(262145 + 30264, 1900000) -- Panther Value -- 1900000 shows as 2,090,000 in-game on the board. 190,000 difference.
        --globals.set_int(262145 + 30262, 1300000) -- Diamond Value  -- 1300000 shows as 1,430,000 in-game. 130,000 difference.
        --globals.set_int(262145 + 30261, 770000) -- Bonds Value -- 770000 shows as 847,000 in-game.  77,000 difference.
        --globals.set_int(262145 + 30260, 700000) -- Necklace Value -- 700000 shows as 770,000 in-game. 70,000 difference.
        globals.set_int(262145 + 30259, 693000) -- Tequila Value -- 630000 shows as 693,000. 63,000 difference.
        
        STATS.STAT_SET_INT(joaat(MPX .. "H4_MISSIONS"), 65535, true)
        STATS.STAT_SET_INT(joaat(MPX .. "H4_PLAYTHROUGH_STATUS"), 32, true)
    
    gui.show_message("Cayo Heist", "龙舌兰酒困难模式（合法）已经设置！")
    gui.show_message("Cayo Heist", "重置主板以查看更改")
end)

cayoHeist:add_separator()
cayoHeist:add_text("单击上述预设之一后按此键")
cayoHeist:add_button("重置 虎鲸 面板", function()
        locals.set_int(HIP, 1544, 2)
        gui.show_message("Cayo Heist", "规划板已重置!")
end)

cayoHeist:add_separator()
cayoHeist:add_text("抢劫期间")
cayoHeist:add_button("跳过排水切口", function()
    locals.set_int(FMC2020, 29118, 6)
    gui.show_message("Cayo Heist", "旁路排水切口")
end)

cayoHeist:add_sameline()
cayoHeist:add_button("跳过指纹扫描仪", function()
   locals.set_int(FMC2020, 24333, 5)
   gui.show_message("Cayo Heist", "绕过指纹扫描仪")
end)

cayoHeist:add_sameline()
cayoHeist:add_button("跳过玻璃切割", function()
    locals.set_float(FMC2020, 30357 + 3, 100.0)
    gui.show_message("Cayo Heist", "跳过玻璃切割机")
end)

cayoHeist:add_sameline()
cayoHeist:add_button("移除所有监控", function()
    for _, ent in pairs(entities.get_all_objects_as_handles()) do
        for __, cam in pairs(CamList) do
            if ENTITY.GET_ENTITY_MODEL(ent) == cam then
                ENTITY.SET_ENTITY_AS_MISSION_ENTITY(ent, true, true)
                ENTITY.DELETE_ENTITY(ent)
                gui.show_message("Cayo Heist", "删除了所有任务摄像机")
            end
        end
    end
end)
CamList = {
    joaat("prop_cctv_cam_01a"), joaat("prop_cctv_cam_01b"), joaat("prop_cctv_cam_02a"), joaat("prop_cctv_cam_03a"),
    joaat("prop_cctv_cam_04a"), joaat("prop_cctv_cam_04c"), joaat("prop_cctv_cam_05a"), joaat("prop_cctv_cam_06a"),
    joaat("prop_cctv_cam_07a"), joaat("prop_cs_cctv"), joaat("p_cctv_s"), joaat("hei_prop_bank_cctv_01"),
    joaat("hei_prop_bank_cctv_02"), joaat("ch_prop_ch_cctv_cam_02a"), joaat("xm_prop_x17_server_farm_cctv_01"),
}

cayoHeist:add_sameline()
cayoHeist:add_button("删除任务NPC", function() -- Thanks to RazorGamerX for the help on this
    for index, ped in ipairs(entities.get_all_peds_as_handles()) do 
        local model = ENTITY.GET_ENTITY_MODEL(ped)
        if model == 0x7ED5AD78 or model == 0x6C8C08E5 or model == 0x995B3F9F or model == 0xB881AEE then 
                ENTITY.SET_ENTITY_AS_MISSION_ENTITY(ped, true, true)
                PED.DELETE_PED(ped)
                gui.show_message("抢劫岛", "删除了所有任务NPC。 这将导致钥匙卡不会掉落，站在次要战利品室附近时使用金币传送绕过.")
        end
    end
end)
        
cayoHeist:add_separator()
cayoHeist:add_text("抢劫佩岛后")
cayoHeist:add_button("跳过冷却时间", function()
    MPX = PI
PI = stats.get_int("MPPLY_LAST_MP_CHAR")
if PI == 0 then
    MPX = "MP0_"
else
    MPX = "MP1_"
end
    -- Solo Skip
    STATS.STAT_SET_INT(joaat(MPX .. "H4_TARGET_POSIX"), 1659643454, true)
    STATS.STAT_SET_INT(joaat(MPX .. "H4_COOLDOWN"), 0, true)
    STATS.STAT_SET_INT(joaat(MPX .. "H4_COOLDOWN_HARD"), 0, true)
    -- Multiplayer Skip
    STATS.STAT_SET_INT(joaat(MPX .. "H4_TARGET_POSIX"), 1659429119, true)
    STATS.STAT_SET_INT(joaat(MPX .. "H4_COOLDOWN"), 0, true)
    STATS.STAT_SET_INT(joaat(MPX .. "H4_COOLDOWN_HARD"), 0, true)
    
    gui.show_message("抢劫岛", "跳过了所有角色的 佩里科岛 冷却时间")
end)

local properties = {
    {name = "排水", id = 768}, {name = "金", id = 618}, {name = "指纹扫描仪", id = 619}, {name = "正门", id = 770}, {name = "排水口", id = 760},
    -- Add more properties as needed
    -- Cayo Drainage = 768
}

-- Function to create buttons dynamically
local function createCayoButtons(cayoHeist)
    local buttonsPerRow = 5
    local buttonCount = 0
    for _, property in ipairs(properties) do
        cayoHeist:add_button(property.name, function()
            local ped = PLAYER.PLAYER_PED_ID()
            local blip_info = HUD.GET_FIRST_BLIP_INFO_ID(property.id)
            local coords = HUD.GET_BLIP_COORDS(blip_info)
            
            if HUD.DOES_BLIP_EXIST(blip_info) then
                if property.id == 740 then
                    PED.SET_PED_COORDS_KEEP_VEHICLE(ped, coords.x + 5, coords.y - 5, coords.z)
                else 
                    PED.SET_PED_COORDS_KEEP_VEHICLE(ped, coords.x, coords.y, coords.z)
                end
            end
        end)
        buttonCount = buttonCount + 1
        if buttonCount < buttonsPerRow and _ < #properties then
            cayoHeist:add_sameline() -- Add next button on the same line if there are more buttons and haven't reached the limit per row
        else
            buttonCount = 0 -- Reset button count for the new row
        end
    end
end
cayoHeist:add_separator()
cayoHeist:add_text("传送")
createCayoButtons(cayoHeist)
cayoHeist:add_separator()
cayoHeist:add_text("如何设置或绕过冷却时间:")
cayoHeist:add_text("确保您已经完成了抢劫，并且您站在计划屏幕前")
cayoHeist:add_text("单击跳过冷却时间，然后单击您的预设并单击重置 排水 板")

-- Cayo Bag Size & Value Editor
local cayoSizeEditor = cayoHeist:add_tab("大小/值编辑器")
cayoSizeEditor:add_text("袋子尺寸编辑器")
bagSizeVal = 1800
cayoSizeEditor:add_imgui(function()
bagSizeVal, used = ImGui.SliderInt("袋子尺寸", bagSizeVal, 1800, 7200) -- 7200 = 4 players, this works if you want more money solo and it adjusts so you can always have full bags
    out = "重置电路板以查看更改"
    
    if used then
        globals.set_int(262145 + 30009, bagSizeVal)
        gui.show_message('袋子尺寸修改!', out)
    end
end)

cayoSizeEditor:add_separator()
cayoSizeEditor:add_text("主要目标编辑者")
pantherSizeVal = 1900000
cayoSizeEditor:add_imgui(function()
pantherSizeVal, used = ImGui.SliderInt("黑豹价值", pantherSizeVal, 1900000, 3800000) -- Double the original price
    out = "重置电路板以查看更改"
    
    if used then
        globals.set_int(262145 + 30264, pantherSizeVal)
        gui.show_message('黑豹值已修改！', out)
    end
end)

diamondSizeVal = 1300000
cayoSizeEditor:add_imgui(function()
diamondSizeVal, used = ImGui.SliderInt("钻石价值", diamondSizeVal, 1300000, 2600000) -- Double the original price
    out = "重置电路板以查看更改"
    
    if used then
        globals.set_int(262145 + 30262, diamondSizeVal)
        gui.show_message('钻石价值修改!', out)
    end
end)

bondSizeVal = 770000
cayoSizeEditor:add_imgui(function()
bondSizeVal, used = ImGui.SliderInt("债券价值", bondSizeVal, 770000, 1540000) -- Double the original price
    out = "重置电路板以查看更改"
    
    if used then
        globals.set_int(262145 + 30261, bondSizeVal)
        gui.show_message('修正后的债券价值!', out)
    end
end)

necklaceSizeVal = 700000
cayoSizeEditor:add_imgui(function()
necklaceSizeVal, used = ImGui.SliderInt("项链价值", necklaceSizeVal, 700000, 1400000) -- Double the original price
    out = "重置电路板以查看更改"
    
    if used then
        globals.set_int(262145 + 30260, necklaceSizeVal)
        gui.show_message('项链值已修改!', out)
    end
end)

tequilaSizeVal = 693000
cayoSizeEditor:add_imgui(function()
tequilaSizeVal, used = ImGui.SliderInt("龙舌兰酒价值", tequilaSizeVal, 693000, 1400000) -- Double the original price
    out = "重置电路板以查看更改"
    
    if used then
        globals.set_int(262145 + 30259, tequilaSizeVal)
        gui.show_message('龙舌兰酒价值修改!', out)
    end
end)

cayoSizeEditor:add_separator()
cayoSizeEditor:add_text("辅助目标编辑器")

goldSizeVal = 45375
cayoSizeEditor:add_imgui(function()
goldSizeVal, used = ImGui.SliderInt("黄金价值", goldSizeVal, 45375, 181500) -- Quadruple the original price
    out = "重置电路板以查看更改"
    
    if used then
        MPX = PI
PI = stats.get_int("MPPLY_LAST_MP_CHAR")
if PI == 0 then
    MPX = "MP0_"
else
    MPX = "MP1_"
end
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_GOLD_V"), goldSizeVal, true)
        gui.show_message('修改后的黄金价值!', out)
    end
end)

cokeSizeVal = 25312
cayoSizeEditor:add_imgui(function()
cokeSizeVal, used = ImGui.SliderInt("Coke 价值", cokeSizeVal, 25312, 101248) -- Quadruple the original price
    out = "重置电路板以查看更改"
    
    if used then
        MPX = PI
PI = stats.get_int("MPPLY_LAST_MP_CHAR")
if PI == 0 then
    MPX = "MP0_"
else
    MPX = "MP1_"
end
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_COKE_V"), cokeSizeVal, true)
        gui.show_message('Coke 值已修改!', out)
    end
end)

paintSizeVal = 22500
cayoSizeEditor:add_imgui(function()
paintSizeVal, used = ImGui.SliderInt("绘画价值", paintSizeVal, 22500, 90000) -- Quadruple the original price
    out = "重置电路板以查看更改"
    
    if used then
        MPX = PI
PI = stats.get_int("MPPLY_LAST_MP_CHAR")
if PI == 0 then
    MPX = "MP0_"
else
    MPX = "MP1_"
end
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_PAINT_V"), paintSizeVal, true)
        gui.show_message('绘画价值修改!', out)
    end
end)

weedSizeVal = 16875
cayoSizeEditor:add_imgui(function()
weedSizeVal, used = ImGui.SliderInt("大麻价值", weedSizeVal, 16875, 67500) -- Quadruple the original price
    out = "重置电路板以查看更改"
    
    if used then
        MPX = PI
PI = stats.get_int("MPPLY_LAST_MP_CHAR")
if PI == 0 then
    MPX = "MP0_"
else
    MPX = "MP1_"
end
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_WEED_V"), weedSizeVal, true)
        gui.show_message('大麻值修改!', out)
    end
end)

cashSizeVal = 10406
cayoSizeEditor:add_imgui(function()
cashSizeVal, used = ImGui.SliderInt("现金价值", cashSizeVal, 10406, 41624) -- Quadruple the original price
    out = "重置电路板以查看更改"
    
    if used then
        MPX = PI
PI = stats.get_int("MPPLY_LAST_MP_CHAR")
if PI == 0 then
    MPX = "MP0_"
else
    MPX = "MP1_"
end
        STATS.STAT_SET_INT(joaat(MPX .. "H4LOOT_WEED_V"), cashSizeVal, true)
        gui.show_message('修改后的现金价值!', out)
    end
end)
cayoSizeEditor:add_text("这些值似乎不正确，但游戏可以正确读取它们.")
cayoSizeEditor:add_text("最小值是所有目标的精确默认值.")
cayoSizeEditor:add_separator()
cayoSizeEditor:add_text("设置值后按此键.")
cayoSizeEditor:add_button("重置 虎鲸 面板", function()
        locals.set_int(HIP, 1544, 2)
        gui.show_message("抢劫岛", "规划板已重置!")
end)

-- Doomsday Heist Editor

local DP = heistEditor:add_tab("末日任务编辑器")
MPX = PI
PI = stats.get_int("MPPLY_LAST_MP_CHAR")
if PI == 0 then
    MPX = "MP0_"
else
    MPX = "MP1_"
end

a48 = 1

local contract_id = {0, 2, 3, 4} -- Assuming these are the IDs for "Select", "Data Breaches", "Bogdan Problem", "Doomsday Scenario"
local contract_names = {"选择", "数据泄露", "波格丹问题", "末日最终场景"}
local selectedContractIndex = 0
local selectedContractID = contract_id[selectedContractIndex + 1]

DP:add_text("世界末日选择")

local function DoomsdayActSetter(progress, status)
    STATS.STAT_SET_INT(joaat(MPX .. "GANGOPS_FLOW_MISSION_PROG"), progress, true)
    STATS.STAT_SET_INT(joaat(MPX .. "GANGOPS_HEIST_STATUS"), status, true)
   STATS.STAT_SET_INT(joaat(MPX .. "GANGOPS_FLOW_NOTIFICATIONS"), 1557, true)
end

DP:add_imgui(function()
    selectedContractIndex, used = ImGui.ListBox("##DoomsdayActList", selectedContractIndex, contract_names, #contract_names) -- Display the listbox
    if used then
        selectedContractID = contract_id[selectedContractIndex + 1]
    end

    if ImGui.Button("选择 行动 ") then
        if selectedContractID == 2 then
            DoomsdayActSetter(503, 229383)
        elseif selectedContractID == 3 then
            DoomsdayActSetter(240, 229378)
        elseif selectedContractID == 4 then
            DoomsdayActSetter(16368, 229380)
        end
    end
end)

DP:add_sameline()
DP:add_button("完成准备工作", function() STATS.STAT_SET_INT(MPX() .. "GANGOPS_FM_MISSION_PROG", -1, true) end)
DP:add_sameline()
DP:add_button("重置准备工作", function() DoomsdayActSetter(240, 0) end)

DP:add_text("完成所有选择并按完成准备")
DP:add_text("离开您的设施并返回内部")

local valEdit = DP:add_tab("提现编辑器")

local h2_d1_awd = valEdit:add_input_int("数据泄露")
local h2_d2_awd = valEdit:add_input_int("波格丹问题")
local h2_d3_awd = valEdit:add_input_int("末日3")

valEdit:add_button("检索付款", function()
    h2_d1_awd:set_value(tunables.get_int("GANGOPS_THE_IAA_JOB_CASH_REWARD"))
    h2_d2_awd:set_value(tunables.get_int("GANGOPS_THE_SUBMARINE_JOB_CASH_REWARD"))
    h2_d3_awd:set_value(tunables.get_int("GANGOPS_THE_MISSILE_SILO_JOB_CASH_REWARD"))
end)
valEdit:add_sameline()

h2_awd_lock = valEdit:add_checkbox("应用提现")

 if  h2_awd_lock:is_enabled() then
        if h2_d1_awd:get_value() > 2500000 or h2_d1_awd:get_value() <= 0 or h2_d2_awd:get_value() > 2500000 or h2_d2_awd:get_value() <= 0 or h2_d3_awd:get_value() > 2500000 or h2_d3_awd:get_value() <= 0 then
            gui.show_message("错误", "最终章节收入不得超过 2.500.000，并且必须大于 0")
            h2_awd_lock:set_enabled(false)
           return
       end
       tunables.set_int("GANGOPS_THE_IAA_JOB_CASH_REWARD", h2_d1_awd:get_value())   
       tunables.set_int("GANGOPS_THE_SUBMARINE_JOB_CASH_REWARD", h2_d2_awd:get_value())   
       tunables.set_int("GANGOPS_THE_MISSILE_SILO_JOB_CASH_REWARD", h2_d3_awd:get_value())   
    end
    
-- Magnet/Forcefield
local xmen = Fun:add_tab("磁铁/力场")
xmen:add_text("磁场吸引所有 peds/车辆")
local blackHoleLoopCheckbox = xmen:add_checkbox("磁铁")
local blackHoleRadius = 2.0
local blackHoleMarkerVisible = false
local magnitude = 1.0 -- Initialize the magnitude variable

xmen:add_imgui(function()
    blackHoleRadius, used = ImGui.SliderFloat("磁铁半径", blackHoleRadius, 0.0, 100.0)
    out = "半径设置为 " .. tostring(blackHoleRadius)
    if used then
        gui.show_message('磁铁半径修改!', out)
    end
    
    magnitude, used = ImGui.SliderFloat("大小", magnitude, 0.0, 50.0) -- Add the magnitude slider
    out = "量级设置为 " .. tostring(magnitude)
    if used then
        gui.show_message('修改后的幅度!', out)
    end
    
    blackHoleMarkerVisible = blackHoleLoopCheckbox:is_enabled()
    
    -- Draw black hole marker
    if blackHoleMarkerVisible then
        local playerPed = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(PLAYER.PLAYER_ID())
        local playerCoords = ENTITY.GET_ENTITY_COORDS(playerPed, true)
        GRAPHICS.DRAW_MARKER_SPHERE(playerCoords.x, playerCoords.y, playerCoords.z, blackHoleRadius, 255, 0, 0, 0.3)
    end
end)

local function applyBlackHole(playerCoords, blackHoleRadius, magnitude) -- Include magnitude parameter
    local vehicles = entities.get_all_vehicles_as_handles()
    local peds = entities.get_all_peds_as_handles()
    local blackHoleRadiusSquared = blackHoleRadius * blackHoleRadius
    for _, entity in ipairs(vehicles) do
        if PED.IS_PED_A_PLAYER(entity) == false then
            if entities.take_control_of(entity) then
                local entityCoord = ENTITY.GET_ENTITY_COORDS(entity, false)
                local distanceSquared = V3_DISTANCE_SQUARED(playerCoords, entityCoord)
                if distanceSquared <= blackHoleRadiusSquared then
                    local forceX = (playerCoords.x - entityCoord.x) * magnitude -- Apply magnitude
                    local forceY = (playerCoords.y - entityCoord.y) * magnitude
                    local forceZ = (playerCoords.z - entityCoord.z) * magnitude
                    RequestControl(entity)
                    ENTITY.APPLY_FORCE_TO_ENTITY(entity, 2, forceX, forceY, forceZ, 0.0, 0.0, 0.0, 0, false, true, true, false, false)
                end
            end
        end
    end
    
    for _, entity in ipairs(peds) do
        if PED.IS_PED_A_PLAYER(entity) == false then
            if entities.take_control_of(entity) then
                local entityCoord = ENTITY.GET_ENTITY_COORDS(entity, false)
                local distanceSquared = V3_DISTANCE_SQUARED(playerCoords, entityCoord)
                if distanceSquared <= blackHoleRadiusSquared then
                    local forceX = (playerCoords.x - entityCoord.x) * magnitude -- Apply magnitude
                    local forceY = (playerCoords.y - entityCoord.y) * magnitude
                    local forceZ = (playerCoords.z - entityCoord.z) * magnitude
                    RequestControl(entity)
                    ENTITY.APPLY_FORCE_TO_ENTITY(entity, 2, forceX, forceY, forceZ, 0.0, 0.0, 0.0, 0, false, true, true, false, false)
                end
            end
        end
    end
end

script.register_looped("blackHoleLoopScript", function(script)
    script:yield()
    if blackHoleLoopCheckbox:is_enabled() == true then
        local player = PLAYER.PLAYER_ID()
        local playerPed = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(player)
        local playerCoords = ENTITY.GET_ENTITY_COORDS(playerPed, true)
        applyBlackHole(playerCoords, blackHoleRadius, magnitude) -- Pass magnitude
    end
end)

function V3_DISTANCE_SQUARED(v1, v2)
    local dx = v1.x - v2.x
    local dy = v1.y - v2.y
    local dz = v1.z - v2.z
    return dx * dx + dy * dy + dz * dz
end

xmen:add_text("力场将玩家包围在屏障中.")
xmen:add_text("与磁铁配合使用，形成车辆/脚踏障碍物")
local forceFieldLoopCheckbox = xmen:add_checkbox("力场")
local forceFieldRadius = 5.0
local forceFieldMagnitude = 10.0
local forceFieldMarkerVisible = false

xmen:add_imgui(function()
    forceFieldRadius, used = ImGui.SliderFloat("力场半径", forceFieldRadius, 0.0, 100.0)
    out = "半径设置为 " .. tostring(forceFieldRadius)
    if used then
        gui.show_message('修改后的力场半径!', out)
    end
    
    forceFieldMagnitude, used = ImGui.SliderFloat("力场大小.", forceFieldMagnitude, 0.0, 100.0)
    out = "量级设置为 " .. tostring(forceFieldMagnitude)
    if used then
        gui.show_message('力场幅度修改!', out)
    end
    
    forceFieldMarkerVisible = forceFieldLoopCheckbox:is_enabled()
    
    -- Draw force field marker
    if forceFieldMarkerVisible then
        local playerPed = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(PLAYER.PLAYER_ID())
        local playerCoords = ENTITY.GET_ENTITY_COORDS(playerPed, true)
        GRAPHICS.DRAW_MARKER_SPHERE(playerCoords.x, playerCoords.y, playerCoords.z, forceFieldRadius, 0, 255, 0, 0.3)
    end
end)

local function applyForceField(playerCoords, forceFieldRadius, forceMagnitude)
    local vehicles = entities.get_all_vehicles_as_handles()
    local peds = entities.get_all_peds_as_handles()
    local forceFieldRadiusSquared = forceFieldRadius * forceFieldRadius

    -- Apply forces to vehicles
    for _, entity in ipairs(vehicles) do
        if PED.IS_PED_A_PLAYER(entity) == false then
            if entities.take_control_of(entity) then
                local entityCoord = ENTITY.GET_ENTITY_COORDS(entity, false)
                local distanceSquared = V3_DISTANCE_SQUARED(playerCoords, entityCoord)
                if distanceSquared <= forceFieldRadiusSquared then
                    local forceX = (entityCoord.x - playerCoords.x) * forceMagnitude -- Invert the direction of force
                    local forceY = (entityCoord.y - playerCoords.y) * forceMagnitude -- Invert the direction of force
                    local forceZ = (entityCoord.z - playerCoords.z) * forceMagnitude -- Invert the direction of force
                    RequestControl(entity)
                    ENTITY.APPLY_FORCE_TO_ENTITY(entity, 2, forceX, forceY, forceZ, 0.0, 0.0, 0.0, 0, false, true, true, false, false)
                end
            end
        end
    end

    -- Comment below to unapply to peds
    for _, entity in ipairs(peds) do
        if PED.IS_PED_A_PLAYER(entity) == false then
            if entities.take_control_of(entity) then
                local entityCoord = ENTITY.GET_ENTITY_COORDS(entity, false)
                local distanceSquared = V3_DISTANCE_SQUARED(playerCoords, entityCoord)
                if distanceSquared <= forceFieldRadiusSquared then
                    local forceX = (entityCoord.x - playerCoords.x) * forceMagnitude -- Invert the direction of force
                    local forceY = (entityCoord.y - playerCoords.y) * forceMagnitude -- Invert the direction of force
                    local forceZ = (entityCoord.z - playerCoords.z) * forceMagnitude -- Invert the direction of force
                    RequestControl(entity)
                    ENTITY.APPLY_FORCE_TO_ENTITY(entity, 2, forceX, forceY, forceZ, 0.0, 0.0, 0.0, 0, false, true, true, false, false)
                end
            end
        end
    end
end

script.register_looped("forceFieldLoopScript", function(script)
    script:yield()
    if forceFieldLoopCheckbox:is_enabled() == true then
        local playerPed = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(PLAYER.PLAYER_ID())
        local playerCoords = ENTITY.GET_ENTITY_COORDS(playerPed, true)
        applyForceField(playerCoords, forceFieldRadius, forceFieldMagnitude)
    end
end)

function V3_DISTANCE_SQUARED(v1, v2)
    local dx = v1.x - v2.x
    local dy = v1.y - v2.y
    local dz = v1.z - v2.z
    return dx * dx + dy * dy + dz * dz
end

-- USBMenus (Contributor) Additions

raceTab = KAOS:add_tab("比赛编辑器")
raceTab:add_imgui(function()
    if (ImGui.TreeNode("漂移比赛")) then
        ImGui.SetNextItemWidth(250)
        maxMultiplier, maxMp = ImGui.InputFloat("最大乘数", globals.get_float(262145 + 25983), 0.1, 1, "%.1f")
        toolTip("", "漂移乘数将达到的最大值")
        ImGui.SetNextItemWidth(250)
        timeDrifting, timeDr = ImGui.InputInt("乘数增加的时间漂移 （ms)", globals.get_int(262145 + 25982), 100, 1000)
        toolTip("", "漂移时乘数增加所需的时间（以毫秒为单位）")
        ImGui.SetNextItemWidth(250)
        driftMultiplier, driftMp = ImGui.InputFloat("乘数增加率", globals.get_float(262145 + 25981), 0.1, 1, "%.1f")
        toolTip("", "乘数将增加多少")
        ImGui.SetNextItemWidth(250)
        precisionDrift, precisionDr = ImGui.InputInt("精密漂移量", globals.get_int(262145 + 25984), 100, 1000)
        toolTip("", "进行精确漂移的奖励积分数量")
        ImGui.SetNextItemWidth(250)
        respawnPenalty, respawnPn = ImGui.InputInt("重生惩罚", globals.get_int(262145 + 25995), 100, 1000)
        toolTip("", "重生时获得的点数")

        if maxMp then
            globals.set_float(262145 + 25983, maxMultiplier)
        end
        if timeDr then
            globals.set_int(262145 + 25982, timeDrifting)
        end
        if driftMp then
            globals.set_float(262145 + 25981, driftMultiplier)
        end
        if precisionDr then
            globals.set_int(262145 + 25984, precisionDrift)
        end
        if respawnPn then
            globals.set_int(262145 + 25995, respawnPenalty)
        end
    end
end)

--Chat Options
local chatOpt = KAOS:add_tab("聊天选项")

chatOpt:add_text("发送未经过滤的邮件")
local chatBox = ""
chatOpt:add_imgui(function()
    if is_typing then
        PAD.DISABLE_ALL_CONTROL_ACTIONS(0)
    end
    chatBox, used = ImGui.InputText("消息", chatBox, 256)
    if ImGui.IsItemActive() then
        is_typing = true
    else
        is_typing = false
    end
end)
chatOpt:add_sameline()
local isTeam = chatOpt:add_checkbox("仅限团队")
chatOpt:add_button("发送短言", function()
    if isTeam:is_enabled() == false then
        if chatBox ~= "" then
            network.send_chat_message(chatBox, false)
        end
    else
        if chatBox ~= "" then
            network.send_chat_message(chatBox, true)
        end
    end
end)

chatOpt:add_separator()
-- Discord Name Sender, easily send your discord name
chatOpt:add_text("Discord 广告")
local discordBox = ""
chatOpt:add_imgui(function()
    if is_typing then
        PAD.DISABLE_ALL_CONTROL_ACTIONS(0)
    end
    discordBox, used = ImGui.InputText("Discord 用户名", discordBox, 64)
    if ImGui.IsItemActive() then
        is_typing = true
    else
        is_typing = false
    end
end)

chatOpt:add_button("发送", function()
    if discordBox ~= "" then
        network.send_chat_message("[add My Discord]: "..discordBox, false)
    end
end)

chatOpt:add_separator()
chatOpt:add_text("这些会在公屏中发布脚本信息 如果你愿意宣传它")
chatOpt:add_button("插件信息", function()
        local ainfo = "YimMenu 的附加插件 v"..addonVersion..", 在 Github 上免费找到它 @ https://github.com/Deadlineem/Extras-Addon-for-YimMenu!"
        network.send_chat_message("[Lua 脚本]: "..ainfo, false)
end)
chatOpt:add_sameline()
chatOpt:add_button("菜单信息", function()
        local binfo = "YimMenu 版本 1.68，在 Github 上免费找到它 @ https://github.com/YimMenu/YimMenu!"
        network.send_chat_message("[菜单]: "..binfo, false)
end)

griefPlayerTab:add_text("Extras Addon v"..addonVersion.." - 玩家 选项")
griefPlayerTab:add_separator()

griefPlayerTab:add_text("切换单独的窗口?")
extraGrief = griefPlayerTab:add_checkbox("不友好选项")
extraGrief:set_enabled(true)
griefPlayerTab:add_imgui(function()
    if extraGrief:is_enabled() then
    local parentWindow = gui.get_tab("") -- Assuming this retrieves the parent window
        local parentX, parentY = ImGui.GetWindowPos() -- Get the position of the parent window
        local parentWidth, parentHeight = ImGui.GetWindowSize(parentWindow) -- Get the size of the parent window
        local childWidth, childHeight = 200, 150 -- Size of your child window
        local offset = 10 -- Offset between parent and child windows

        local x = parentX + parentWidth + offset -- Position the child window to the right of the parent window
        local y = parentY -- Align the child window vertically with the parent window

        ImGui.SetNextWindowPos(x, y)
            if ImGui.Begin("不友好选项 ".. PLAYER.GET_PLAYER_NAME(network.get_selected_player())) then
            -- Sets a new window for the options below, theres a wrapper for ImGui.End() at the bottom of the options.
            
        end
    end
end)

local balls = {
"p_ld_soc_ball_01",
"p_ld_am_ball_01",
"prop_bowling_ball",
"prop_beach_volball01",
"prop_beach_volball02",
"prop_beachball_02",
"v_ilev_exball_blue"
}

griefPlayerTab:add_text("恶作剧")
npcDrive = griefPlayerTab:add_checkbox("NPC开车到这个玩家")
toolTip(griefPlayerTab, "让所有 NPC 的驱动器都交给这个玩家")

griefPlayerTab:add_sameline()
dildos = griefPlayerTab:add_checkbox("假阳具")
toolTip(griefPlayerTab, "在玩家身上生成振动器")

griefPlayerTab:add_sameline()
dropBalls = griefPlayerTab:add_checkbox("排球")
toolTip(griefPlayerTab, "在玩家身上生成排球")

vehicleSpin = griefPlayerTab:add_checkbox("旋转车")
toolTip(griefPlayerTab, "无法控制地旋转玩家的车辆.")

griefPlayerTab:add_sameline()
local trollLoop = false
trollLoop = griefPlayerTab:add_checkbox("传送恶作剧")

script.register_looped("trollLoop", function(script)
    script:yield()
    if trollLoop:is_enabled() == true then
        local localPlayer = PLAYER.PLAYER_ID()
        local player = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(network.get_selected_player())
        coords = ENTITY.GET_ENTITY_COORDS(player, true)
        gui.show_message("传送恶作剧", "随机传送 "..PLAYER.GET_PLAYER_NAME(network.get_selected_player()))
        PLAYER.START_PLAYER_TELEPORT(localPlayer, coords.x + math.random(-5, 5), coords.y + math.random(-5, 5), coords.z, 0, true, true, true)
        sleep(0.1)
    end
end)
toolTip(griefPlayerTab, "将你随机传送到选定的玩家周围，如果你在其中，当你激活它时，它会摧毁车辆")

griefPlayerTab:add_button("生成克隆", function()
    script.run_in_fiber(function(spawnClone)
        local player = PLAYER.GET_PLAYER_PED(network.get_selected_player())
        local coords = ENTITY.GET_ENTITY_COORDS(player, true)
        
        -- Create a pedestrian clone
        local ped = PED.CREATE_PED(26, ENTITY.GET_ENTITY_MODEL(player), coords.x, coords.y + 1, coords.z, ENTITY.GET_ENTITY_HEADING(player), true, false, false)
        if ped ~= 0 then
            -- Clone the pedestrian's behavior to target the player
            PED.CLONE_PED_TO_TARGET(player, ped)
            
            -- Make the pedestrian aggressive
            TASK.TASK_COMBAT_PED(ped, player, 0, 16)
            
            -- Equip the pedestrian with a knife
            WEAPON.GIVE_WEAPON_TO_PED(ped, 1672152130, 1, false, true) -- -1716189206 is the hash for the knife weapon
            
            -- Set combat attributes
            PED.SET_PED_COMBAT_ABILITY(ped, 100)
            PED.SET_PED_COMBAT_ATTRIBUTES(ped, 46, true) 
            PED.SET_PED_COMBAT_ATTRIBUTES(ped, 2, true) -- Can do Driveby's     
            PED.SET_PED_COMBAT_ATTRIBUTES(ped, 5, true) -- Always Fight
            PED.SET_PED_COMBAT_ATTRIBUTES(ped, 13, true) -- Aggressive
            PED.SET_PED_COMBAT_ATTRIBUTES(ped, 17, false) -- always flee /false
            PED.SET_PED_COMBAT_ATTRIBUTES(ped, 21, true) -- Can chase on foot
            PED.SET_PED_COMBAT_ATTRIBUTES(ped, 27, true) -- Perfect Accuracy
            ENTITY.SET_ENTITY_MAX_HEALTH(ped, 1000);
            ENTITY.SET_ENTITY_HEALTH(ped, 1000, 0);
            PED.SET_PED_CAN_RAGDOLL(ped, false)
            PED.SET_PED_COMBAT_ATTRIBUTES(ped, 58, true) -- Disable Flee from combat
            PED.SET_PED_COMBAT_ATTRIBUTES(ped, 38, true) -- Disable Bullet Reactions
            PED.SET_PED_COMBAT_ATTRIBUTES(ped, 31, true) -- Maintain Min target distance
            PED.SET_PED_COMBAT_ATTRIBUTES(ped, 1, true) -- Can use vehicles
        else
            gui.show_error("失败", "无法创建 ped")
        end
    end)
end)
toolTip(griefPlayerTab, "生成一个带有寻的发射器的玩家克隆体来杀死他们.")

griefPlayerTab:add_sameline()
griefPlayerTab:add_button("小丑攻击", function()
    script.run_in_fiber(function (clownAttack)
        local player = PLAYER.GET_PLAYER_PED(network.get_selected_player())
        local coords = ENTITY.GET_ENTITY_COORDS(player, true)
        local heading = ENTITY.GET_ENTITY_HEADING(player)
        local spawnDistance = 50.0 * math.sin(math.rad(heading))
        local isRoad, roadCoords = PATHFIND.GET_NTH_CLOSEST_VEHICLE_NODE_WITH_HEADING(coords.x + spawnDistance, coords.y + spawnDistance, coords.z, 1, coords, heading, 0, 9, 3.0, 2.5)
        local clown = joaat("s_m_y_clown_01")
        local van = joaat("speedo2")
        local weapon = -1121678507
        STREAMING.REQUEST_MODEL(clown)
        STREAMING.REQUEST_MODEL(van)
        STREAMING.REQUEST_MODEL(weapon)
        while not STREAMING.HAS_MODEL_LOADED(clown) or not STREAMING.HAS_MODEL_LOADED(van) do    
            STREAMING.REQUEST_MODEL(clown)
            STREAMING.REQUEST_MODEL(van)
            clownAttack:yield()
        end
        vehicle = VEHICLE.CREATE_VEHICLE(van, roadCoords.x, roadCoords.y, roadCoords.z, ENTITY.GET_ENTITY_HEADING(player), true, false, false)
        if vehicle ~= 0 then
            for seat = -1, 2 do
                --vehiclePed = PED.CREATE_PED_INSIDE_VEHICLE(vehicle, 0, clown, seat, true, false)
                local ped = PED.CREATE_PED(0, clown, roadCoords.x, roadCoords.y + 2, roadCoords.z, ENTITY.GET_ENTITY_HEADING(player), true, true)
                if ped ~= 0 then
                    local group = joaat("HATES_PLAYER")
                    PED.ADD_RELATIONSHIP_GROUP("clowns", group)
                    PED.SET_PED_RELATIONSHIP_GROUP_HASH(ped, group)
                    ENTITY.SET_ENTITY_CAN_BE_DAMAGED_BY_RELATIONSHIP_GROUP(ped, false, group)
                    PED.SET_PED_CAN_BE_TARGETTED_BY_TEAM(ped, group, false)
                    PED.SET_CAN_ATTACK_FRIENDLY(ped, false, false)
                    PED.SET_PED_CAN_BE_TARGETTED(ped, false)
                    WEAPON.GIVE_WEAPON_TO_PED(ped, weapon, 999999, false, true)
                    PED.SET_PED_INTO_VEHICLE(ped, vehicle, seat)
                    PED.SET_PED_COMBAT_ABILITY(ped, 100)
                    PED.SET_PED_COMBAT_ATTRIBUTES(ped, 46, true) 
                    PED.SET_PED_COMBAT_ATTRIBUTES(ped, 2, true) -- Can do Driveby's     
                    PED.SET_PED_COMBAT_ATTRIBUTES(ped, 5, true) -- Always Fight
                    PED.SET_PED_COMBAT_ATTRIBUTES(ped, 13, true) -- Aggressive
                    PED.SET_PED_COMBAT_ATTRIBUTES(ped, 17, false) -- always flee /false
                    PED.SET_PED_COMBAT_ATTRIBUTES(ped, 21, true) -- Can chase on foot
                    PED.SET_PED_COMBAT_ATTRIBUTES(ped, 27, true) -- Perfect Accuracy
                    ENTITY.SET_ENTITY_MAX_HEALTH(ped, 1000);
                    ENTITY.SET_ENTITY_HEALTH(ped, 1000, 0);
                    PED.SET_PED_CAN_RAGDOLL(ped, false)
                    PED.SET_PED_COMBAT_ATTRIBUTES(ped, 58, true) -- Disable Flee from combat
                    PED.SET_PED_COMBAT_ATTRIBUTES(ped, 38, true) -- Disable Bullet Reactions
                    PED.SET_PED_COMBAT_ATTRIBUTES(ped, 31, true) -- Maintain Min target distance
                    PED.SET_PED_COMBAT_ATTRIBUTES(ped, 1, true) -- Can use vehicles
                    TASK.TASK_COMBAT_PED(ped, player, 0, 16)
                    TASK.TASK_DRIVE_BY(ped, player, vehicle, coords.x, coords.y, coords.z, 50, 100, false, joaat("FIRING_PATTERN_FULL_AUTO"))
                    
                    ENTITY.SET_ENTITY_AS_NO_LONGER_NEEDED(ped)
                else
                    gui.show_error("失败", "无法创建 ped")
                end
            end
        else
            gui.show_error("失败", "无法创建车辆")
        end
        
        if ped == 0 then 
            gui.show_error("失败", "无法创建小丑")
        else
            gui.show_message("成功", "成功生成攻击小丑")
        end
    end)
end)
toolTip(griefPlayerTab, "生成一辆装满小丑的小丑车来追逐/射杀玩家.")

griefPlayerTab:add_sameline()
griefPlayerTab:add_button("小丑喷气式攻击", function()
    script.run_in_fiber(function (clownJetsTwo)
        local player = PLAYER.GET_PLAYER_PED(network.get_selected_player())
        local playerName = PLAYER.GET_PLAYER_NAME(network.get_selected_player())
        local coords = ENTITY.GET_ENTITY_COORDS(player, true)
        local heading = ENTITY.GET_ENTITY_HEADING(player)
        local spawnDistance = 250.0 * math.sin(math.rad(heading))
        local spawnHeight = 10.0 -- Adjust this value to set the height at which the jet spawns
        local isRoad, roadCoords = PATHFIND.GET_NTH_CLOSEST_VEHICLE_NODE_WITH_HEADING(coords.x + spawnDistance, coords.y + spawnDistance, coords.z, 1, coords, heading, 0, 9, 3.0, 2.5)
        local clown = joaat("s_m_y_clown_01")
        local jet = joaat("Lazer")
        local weapon = -1121678507

        STREAMING.REQUEST_MODEL(clown)
        STREAMING.REQUEST_MODEL(jet)
        STREAMING.REQUEST_MODEL(weapon)

        while not STREAMING.HAS_MODEL_LOADED(clown) or not STREAMING.HAS_MODEL_LOADED(jet) do    
            STREAMING.REQUEST_MODEL(clown)
            STREAMING.REQUEST_MODEL(jet)
            clownJetsTwo:yield()
        end

        -- Calculate the spawn position for the jet in the air
        local jetSpawnX = coords.x + math.random(-1000, 1000)
        local jetSpawnY = coords.y + math.random(-1000, 1000)
        local jetSpawnZ = coords.z + math.random(100, 1200)
        
        local colors = {27, 28, 29, 150, 30, 31, 32, 33, 34, 143, 35, 135, 137, 136, 36, 38, 138, 99, 90, 88, 89, 91, 49, 50, 51, 52, 53, 54, 92, 141, 61, 62, 63, 64, 65, 66, 67, 68, 69, 73, 70, 74, 96, 101, 95, 94, 97, 103, 104, 98, 100, 102, 99, 105, 106, 71, 72, 142, 145, 107, 111, 112,}
        local jetVehicle = VEHICLE.CREATE_VEHICLE(jet, jetSpawnX, jetSpawnY, jetSpawnZ, heading, true, false, false)
        
        if jetVehicle ~= 0 then
            local primaryColor = colors[math.random(#colors)]
            local secondaryColor = colors[math.random(#colors)]

            -- Set vehicle colors
            VEHICLE.SET_VEHICLE_COLOURS(jetVehicle, primaryColor, secondaryColor)
            -- Spawn clowns inside the jet
            for seat = -1, -1 do
                local ped = PED.CREATE_PED(0, clown, jetSpawnX, jetSpawnY, jetSpawnZ, heading, true, true)
                
                if ped ~= 0 then
                    local group = joaat("HATES_PLAYER")
                    PED.ADD_RELATIONSHIP_GROUP("clowns", group)
                    ENTITY.SET_ENTITY_CAN_BE_DAMAGED_BY_RELATIONSHIP_GROUP(ped, false, group)
                    PED.SET_PED_CAN_BE_TARGETTED(ped, false)
                    WEAPON.GIVE_WEAPON_TO_PED(ped, weapon, 999999, false, true)
                    PED.SET_PED_COMBAT_ATTRIBUTES(ped, 5, true)
                    PED.SET_PED_COMBAT_ATTRIBUTES(ped, 13, true)
                    PED.SET_PED_COMBAT_ATTRIBUTES(ped, 31, true)
                    PED.SET_PED_COMBAT_ATTRIBUTES(ped, 17, false)
                    PED.SET_PED_COMBAT_ATTRIBUTES(ped, 1, true)
                    PED.SET_PED_COMBAT_ATTRIBUTES(ped, 46, true)
                    PED.SET_PED_COMBAT_ATTRIBUTES(ped, 0, false)
                    PED.SET_PED_INTO_VEHICLE(ped, jetVehicle, seat)
                    TASK.TASK_COMBAT_PED(ped, player, 0, 16)
                    ENTITY.SET_ENTITY_MAX_HEALTH(ped, 1000)
                    ENTITY.SET_ENTITY_HEALTH(ped, 1000, 0)
                    ENTITY.SET_ENTITY_MAX_HEALTH(jetVehicle, 1000)
                    ENTITY.SET_ENTITY_HEALTH(jetVehicle, 1000, 0)
                    PED.SET_AI_WEAPON_DAMAGE_MODIFIER(10000)
                    WEAPON.SET_WEAPON_DAMAGE_MODIFIER(1060309761, 10000)
                else
                    gui.show_error("失败", "无法创建 ped")
                end
            end
        else
            gui.show_error("失败", "无法创建 jet")
        end
        
        if jetVehicle == 0 then 
            gui.show_error("失败", "无法创建 Jet")
        else
            gui.show_message("grief 玩家标签", "小丑拉泽斯诞生了！ 锁定已获得！目标: "..playerName)
        end

        -- Release the resources associated with the spawned entities
        ENTITY.SET_ENTITY_AS_NO_LONGER_NEEDED(jetVehicle)
        ENTITY.SET_ENTITY_AS_NO_LONGER_NEEDED(ped)

    end)
end)
toolTip(griefPlayerTab, "生成随机颜色的喷气式飞机，小丑作为飞行员来攻击选定的玩家.")

function request_model(model)
    script.run_in_fiber(function(script)
        while not STREAMING.HAS_MODEL_LOADED(model) do
            STREAMING.REQUEST_MODEL(model)
            script:yield()
        end
    end)
end

---@param entity Entity
---@param minDistance number
---@param maxDistance number
---@return v3
function get_random_offset_from_entity(entity, minDistance, maxDistance)
    local pos = ENTITY.GET_ENTITY_COORDS(entity, false)
    return get_random_offset_in_range(pos, minDistance, maxDistance)
end


---@param coords v3
---@param minDistance number
---@param maxDistance number
---@return v3
function get_random_offset_in_range(coords, minDistance, maxDistance)
    local radius = random_float(minDistance, maxDistance)
    local angle = random_float(0, 2 * math.pi)
    local delta = vec3.new(math.cos(angle), math.sin(angle), 0.0)
    local offsetX = delta.x * radius
    local offsetY = delta.y * radius
    local offsetZ = delta.z * radius
    local newX = coords.x + offsetX
    local newY = coords.y + offsetY
    local newZ = coords.z + offsetZ
    return vec3.new(newX, newY, newZ)
end

---@param min number
---@param max number
---@return number
function random_float(min, max)
    return min + math.random() * (max - min)
end

function request_fx_asset(asset)
    script.run_in_fiber(function(script)
        STREAMING.REQUEST_NAMED_PTFX_ASSET(asset)
        while not STREAMING.HAS_NAMED_PTFX_ASSET_LOADED(asset) do script:yield() end
    end)
end

---@param entity Entity
---@return boolean
function request_control_once(entity)
    if not NETWORK.NETWORK_IS_IN_SESSION() then
        return true
    end
    local netId = NETWORK.NETWORK_GET_NETWORK_ID_FROM_ENTITY(entity)
    NETWORK.SET_NETWORK_ID_CAN_MIGRATE(netId, true)
    return NETWORK.NETWORK_REQUEST_CONTROL_OF_ENTITY(entity)
end

function atan2(y, x)
    return math.atan(y / x)
end

function set_entity_face_entity(entity, target, usePitch)
    local pos1 = ENTITY.GET_ENTITY_COORDS(entity, false)
    local pos2 = ENTITY.GET_ENTITY_COORDS(target, false)
    local relX = pos2.x - pos1.x
    local relY = pos2.y - pos1.y
    local relZ = pos2.z - pos1.z

    local heading = atan2(relY, relX) * 180.0 / math.pi
    if heading < 0 then
        heading = heading + 360.0
    end

    ENTITY.SET_ENTITY_HEADING(entity, heading)

    if usePitch then
        local distXY = math.sqrt(relX * relX + relY * relY)
        local pitch = math.atan2(-relZ, distXY) * 180.0 / math.pi
        ENTITY.SET_ENTITY_ROTATION(entity, pitch, 0, heading, 2, false)
    end
end


griefPlayerTab:add_button("小丑轰炸机", function()
    script.run_in_fiber(function(script)
        local hash = joaat("s_m_y_clown_01")
        local asset = "scr_rcbarry2"
        local explosion = "scr_exp_clown"
        local appears = "scr_clown_appears"
        request_model(hash)
        local player = PLAYER.GET_PLAYER_PED(network.get_selected_player())
        local playerpos = ENTITY.GET_ENTITY_COORDS(player, false)
        local coord = get_random_offset_from_entity(player, 5.0, 8.0)
        coord.z = coord.z - 1.0
        local ped = PED.CREATE_PED(0, hash, coord.x, coord.y, coord.z, 0.0, true, false)
        if ped == 0 then gui.show_error("小丑轰炸机", "无法创建 Ped\n很可能模型未加载\n重试.") else gui.show_message("小丑轰炸机", "生成为 ".. tostring(ped)) end

        request_fx_asset(asset)
        GRAPHICS.USE_PARTICLE_FX_ASSET(asset)
        GRAPHICS.START_NETWORKED_PARTICLE_FX_NON_LOOPED_ON_ENTITY(
            appears,
            ped,
            0.0, 0.0, -1.0,
            0.0, 0.0, 0.0,
            0.5, false, false, false
        )
        set_entity_face_entity(ped, player, false)
        PED.SET_BLOCKING_OF_NON_TEMPORARY_EVENTS(ped, true)
        TASK.TASK_GO_TO_COORD_ANY_MEANS(ped, playerpos.x, playerpos.y, playerpos.z, 5.0, 0, false, 0, 0.0)
        local dest = playerpos
        PED.SET_PED_KEEP_TASK(ped, true)
        AUDIO.STOP_PED_SPEAKING(ped, true)
        while not PED.IS_PED_FATALLY_INJURED(ped) and ENTITY.DOES_ENTITY_EXIST(ped) do
            local pos = ENTITY.GET_ENTITY_COORDS(ped, true)
            local targetPos = ENTITY.GET_ENTITY_COORDS(player, true)
            if not ENTITY.DOES_ENTITY_EXIST(ped) or PED.IS_PED_FATALLY_INJURED(ped) then
                return false
            elseif calcDistanceFromTwoCoords(pos, targetPos) > 150 and request_control(ped) then
                ENTITY.DELETE_ENTITY(ped)
                return false
            elseif calcDistanceFromTwoCoords(pos, targetPos) < 3.0 and request_control(ped) then
                request_fx_asset(asset)
                GRAPHICS.USE_PARTICLE_FX_ASSET(asset)
                GRAPHICS.START_NETWORKED_PARTICLE_FX_NON_LOOPED_AT_COORD(
                    explosion,
                    pos.x, pos.y, pos.z,
                    0.0, 0.0, 0.0,
                    1.0,
                    false, false, false, false
                )
                FIRE.ADD_EXPLOSION(pos.x, pos.y, pos.z, 0, 1.0, true, true, 1.0, false)
                ENTITY.SET_ENTITY_VISIBLE(ped, false, false)
                ENTITY.DELETE_ENTITY(ped)
                return false
            elseif calcDistanceFromTwoCoords(targetPos, dest) > 3.0 and request_control_once(ped) then
                dest = targetPos
                TASK.TASK_GO_TO_COORD_ANY_MEANS(ped, targetPos.x, targetPos.y, targetPos.z, 5.0, 0, false, 0, 0.0)
            end
            script:yield()
        end
        ENTITY.DELETE_ENTITY(ped)
    end)
end)
toolTip(griefPlayerTab, "生成一个神风敢死队小丑来杀死玩家")

griefPlayerTab:add_separator()
griefPlayerTab:add_text("恶搞玩家")
hydrantCB = griefPlayerTab:add_checkbox("消火栓")
toolTip(griefPlayerTab, "生成消防栓喷雾以布娃娃玩家")

griefPlayerTab:add_sameline()
steamCB = griefPlayerTab:add_checkbox("蒸汽")
toolTip(griefPlayerTab, "生成蒸汽以燃烧玩家")

griefPlayerTab:add_sameline()
extinguisherCB = griefPlayerTab:add_checkbox("灭火器")
toolTip(griefPlayerTab, "在玩家身上生成灭火器喷雾")

explodeCB = griefPlayerTab:add_checkbox("爆炸")
griefPlayerTab:add_sameline()
toolTip(griefPlayerTab, "猛烈地爆炸玩家并摇晃他们的屏幕.")

noDamageExplode = griefPlayerTab:add_checkbox("屏幕抖动")
toolTip(griefPlayerTab, "造成无伤害爆炸，震动玩家屏幕.")

script.register_looped("extrasAddonLooped", function(script)
    if npcDrive:is_enabled() then
        local vehtable = entities.get_all_vehicles_as_handles()
        for _, vehs in pairs(vehtable) do
            local selfpos = ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED(network.get_selected_player()), true)
            local ped = VEHICLE.GET_PED_IN_VEHICLE_SEAT(vehs, -1, false)
            local player = false
            for playerId = 0, 31 do
                if PLAYER.GET_PLAYER_PED(playerId) == ped then 
                    player = true
                end
            end
            if ped ~= 0 and player == false then
                request_control(vehs)
                request_control(ped)
                TASK.TASK_VEHICLE_DRIVE_TO_COORD(ped, vehs, selfpos.x, selfpos.y, selfpos.z, 70.0, 1, vehs, 16777216, 0.0, 1)
                --gui.show_message("Success", "Peds Driving To Player")
            else
                --gui.show_message("Failed", "Ped Seat is: ".. ped)
            end
        end
    end
    if dildos:is_enabled() then
        local selectedItem = "prop_cs_dildo_01"
        local coords = ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED(network.get_selected_player()), false)
        while not STREAMING.HAS_MODEL_LOADED(joaat(selectedItem)) do
            STREAMING.REQUEST_MODEL(joaat(selectedItem))
            script:yield()
        end   
        OBJECT.CREATE_AMBIENT_PICKUP(738282662, coords.x, coords.y, coords.z + 1.5, 0, 1, joaat(selectedItem), false, true)
    end

    if dropBalls:is_enabled() then
        local randomIndex = math.random(1, #balls)
        local selectedItem = balls[randomIndex]
        local coords = ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED(network.get_selected_player()), false)
        while not STREAMING.HAS_MODEL_LOADED(joaat(selectedItem)) do
            STREAMING.REQUEST_MODEL(joaat(selectedItem))
            script:yield()
        end
        OBJECT.CREATE_AMBIENT_PICKUP(738282662, coords.x, coords.y, coords.z + 2, 0, 1, joaat(selectedItem), false, true)
    end
    if vehicleSpin:is_enabled() then
        if not PED.IS_PED_IN_ANY_VEHICLE(PLAYER.GET_PLAYER_PED(network.get_selected_player()),true) then
            gui.show_error("旋转车","玩家不在车内")
        else
            veh = PED.GET_VEHICLE_PED_IS_IN(PLAYER.GET_PLAYER_PED(network.get_selected_player()), true)
            local time = os.time()
            local request = false
            while not request do
                if os.time() - time >= 5 then
                    gui.show_error("旋转车","无法控制车辆")
                    break
                end
                request = request_control(veh)
                script:yield()
            end
            gui.show_message("旋转车","纺纱车")
            ENTITY.APPLY_FORCE_TO_ENTITY(veh, 5, 0, 0, 150.0, 0, 0, 0, 0, true, false, true, false, true)
        end
    end
    if extinguisherCB:is_enabled() then
        player = PLAYER.GET_PLAYER_PED(network.get_selected_player())
        coords = ENTITY.GET_ENTITY_COORDS(player, true)
        FIRE.ADD_OWNED_EXPLOSION(player, coords.x, coords.y, coords.z - 2.0, 24, 1, true, false, 0)
    end

    if steamCB:is_enabled() then
        player = PLAYER.GET_PLAYER_PED(network.get_selected_player())
        coords = ENTITY.GET_ENTITY_COORDS(player, true)
        FIRE.ADD_OWNED_EXPLOSION(player, coords.x, coords.y, coords.z - 2.0, 11, 1, true, false, 0)
    end

    if hydrantCB:is_enabled() then
        player = PLAYER.GET_PLAYER_PED(network.get_selected_player())
        coords = ENTITY.GET_ENTITY_COORDS(player, true)
        FIRE.ADD_OWNED_EXPLOSION(player, coords.x, coords.y, coords.z - 2.0, 13, 1, true, false, 0)
    end
    
    if explodeCB:is_enabled() then
        player = PLAYER.GET_PLAYER_PED(network.get_selected_player())
        coords = ENTITY.GET_ENTITY_COORDS(player, true)
        FIRE.ADD_OWNED_EXPLOSION(player, coords.x, coords.y, coords.z - 2.0, 1, 100, true, false, 2147483647)
    end

    if noDamageExplode:is_enabled() then
        player = PLAYER.GET_PLAYER_PED(network.get_selected_player())
        coords = ENTITY.GET_ENTITY_COORDS(player, true)
        FIRE.ADD_OWNED_EXPLOSION(player, coords.x, coords.y, coords.z - 2.0, 1, 0, true, false, 2147483647)
    end
end)

-- Grief Burn Player
griefPlayerTab:add_sameline()
local burnLoop = false
burnLoop = griefPlayerTab:add_checkbox("烧")

script.register_looped("burnLoop", function()
    if burnLoop:is_enabled() == true then
        local player_id = network.get_selected_player()
        local coords = ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(player_id), true)
        local fxType = 3
        local ptfxAsset = "scr_bike_adversary"
        local particle = "scr_adversary_foot_flames"
        
        FIRE.ADD_EXPLOSION(coords.x, coords.y, coords.z, fxType, 100000.0, false, false, 0, false)
        GRAPHICS.USE_PARTICLE_FX_ASSET(ptfxAsset)
        GRAPHICS.START_PARTICLE_FX_NON_LOOPED_AT_COORD(particle, coords.x, coords.y, coords.z, 0.0, 0.0, 0.0, 1.0, false, true, false)
        
        gui.show_message("恶搞“玩家”选项卡", "灼烧痛 "..PLAYER.GET_PLAYER_NAME(player_id).." 反复")

        -- Optionally, you can play a fire sound here using AUDIO.PLAY_SOUND_FROM_COORD

        sleep(0.4)  -- Sets the timer in seconds for how long this should pause before burning another player
    end
end)
toolTip(griefPlayerTab, "使用燃烧弹反复烧毁选定的球员")
-- Griefing Options

local ramLoopz = griefPlayerTab:add_checkbox("车辆夹层（开/关）")

script.register_looped("ramLoopz", function()
    if ramLoopz:is_enabled() then
        local player_id = network.get_selected_player()
        if NETWORK.NETWORK_IS_PLAYER_ACTIVE(player_id) then
                        local coords = ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(player_id), true)

                        -- Get a random vehicle model from the list (make sure 'vehicleModels' is defined)
                        local randomModel = vehicleModels[math.random(1, #vehicleModels)]

                        -- Convert the string vehicle model to its hash value
                        local modelHash = MISC.GET_HASH_KEY(randomModel)

                        -- Create the vehicle without the last boolean argument (keepTrying)
                        local vehicle = VEHICLE.CREATE_VEHICLE(modelHash, coords.x, coords.y, coords.z + 20, 0.0, true, true, false)
                        -- Set vehicle orientation
                        ENTITY.SET_ENTITY_ROTATION(vehicle, 0, 0, 0, 2, true)
                        local networkId = NETWORK.VEH_TO_NET(vehicle)
                        if NETWORK.NETWORK_GET_ENTITY_IS_NETWORKED(vehicle) then
                            NETWORK.SET_NETWORK_ID_EXISTS_ON_ALL_MACHINES(networkId, true)
                        end

                        if vehicle then
                            -- Set the falling velocity (adjust the value as needed)
                            ENTITY.SET_ENTITY_VELOCITY(vehicle, 0, 0, -100000000)
                            -- Optionally, you can play a sound or customize the ramming effect here
                            VEHICLE.SET_ALLOW_VEHICLE_EXPLODES_ON_CONTACT(vehicle, true)
                        end
                        
                        local vehicle2 = VEHICLE.CREATE_VEHICLE(modelHash, coords.x, coords.y, coords.z - 20, 0.0, true, true, false)
                        -- Set vehicle orientation
                        ENTITY.SET_ENTITY_ROTATION(vehicle2, 0, 0, 0, 2, true)
                        local networkId = NETWORK.VEH_TO_NET(vehicle2)
                        if NETWORK.NETWORK_GET_ENTITY_IS_NETWORKED(vehicle2) then
                            NETWORK.SET_NETWORK_ID_EXISTS_ON_ALL_MACHINES(networkId, true)
                        end

                        if vehicle2 then
                            -- Set the falling velocity (adjust the value as needed)
                            ENTITY.SET_ENTITY_VELOCITY(vehicle2, 0, 0, 100000000)
                            -- Optionally, you can play a sound or customize the ramming effect here
                            VEHICLE.SET_ALLOW_VEHICLE_EXPLODES_ON_CONTACT(vehicle2, true)
                        end

                        gui.show_message("恶搞 玩家选项卡", "撞击 " .. PLAYER.GET_PLAYER_NAME(player_id) .. " 与车辆")

                        -- Use these lines to delete the vehicle after spawning. 
                        -- Needs some type of delay between spawning and deleting to function properly
                        
                        ENTITY.SET_ENTITY_AS_NO_LONGER_NEEDED(vehicle)
                        ENTITY.SET_ENTITY_AS_NO_LONGER_NEEDED(vehicle2)
        end

        -- Sets the timer in seconds for how long this should pause before ramming another player
        --sleep(0.2)
    end
end)
toolTip(griefPlayerTab, "将选定的玩家高速夹在 2 辆战车之间")

-- griefPlayerTabing Explode Player 2
griefPlayerTab:add_sameline()
local explodeLoop = false
explodeLoop = griefPlayerTab:add_checkbox("爆炸")

script.register_looped("explodeLoop", function()
    if explodeLoop:is_enabled() == true then
        local explosionType = 1  -- Adjust this according to the explosion type you want (1 = GRENADE, 2 = MOLOTOV, etc.)
        local explosionFx = "explosion_barrel"

                local player_id = network.get_selected_player()
                local coords = ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(player_id), true)
                
                FIRE.ADD_EXPLOSION(coords.x, coords.y, coords.z, explosionType, 100000.0, true, false, 0, false)
                GRAPHICS.USE_PARTICLE_FX_ASSET(explosionFx)
                GRAPHICS.START_PARTICLE_FX_NON_LOOPED_AT_COORD("explosion_barrel", coords.x, coords.y, coords.z, 0.0, 0.0, 0.0, 1.0, false, true, false)
                
                gui.show_message("恶搞 玩家选项卡", "爆炸 "..PLAYER.GET_PLAYER_NAME(player_id).." 反复")
                -- Optionally, you can play an explosion sound here using AUDIO.PLAY_SOUND_FROM_COORD

        sleep(0.4)  -- Sets the timer in seconds for how long this should pause before exploding another player
    end
end)
toolTip(griefPlayerTab, "使用桶爆炸反复爆炸选定的玩家.")

-- Crash Options
griefPlayerTab:add_separator()
griefPlayerTab:add_text("崩溃选项")
local prCrash = false
prCrash = griefPlayerTab:add_checkbox("PR 崩溃（开/关）)")

script.register_looped("prCrash", function()
    if prCrash:is_enabled() == true then

        local model = joaat("vw_prop_vw_colle_prbubble")
        local pickup = joaat("PICKUP_CUSTOM_SCRIPT")
        local player_id = network.get_selected_player()
        local money_value = 1000000

        STREAMING.REQUEST_MODEL(model)

        if STREAMING.HAS_MODEL_LOADED(model) then
        gui.show_message("公关崩溃", "崩溃的玩家")
            local coords = ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(player_id), true)
            local objectIdSpawned = OBJECT.CREATE_AMBIENT_PICKUP(
                pickup,
                coords.x,
                coords.y,
                coords.z + 0.5,
                3,
                money_value,
                model,
                true,
                false
            )

            local net_id = NETWORK.OBJ_TO_NET(objectIdSpawned)
            NETWORK.SET_NETWORK_ID_EXISTS_ON_ALL_MACHINES(objectIdSpawned, true)
        end
        sleep(0.1) -- Sets the timer in seconds for how long this should pause before sending another figure
    end
end)
toolTip(griefPlayerTab, "生成价值 1,000,000 美元的王子机器人小雕像，导致玩家崩溃（对模组制作者不是很有效)")
-- SCH-Lua
griefPlayerTab:add_sameline()
griefPlayerTab:add_button("片段崩溃", function()
    script.run_in_fiber(function (fragcrash)
        if PLAYER.GET_PLAYER_PED(network.get_selected_player()) == PLAYER.PLAYER_PED_ID() then
            gui.show_message("攻击已停止“，”已检测到目标已离开或目标已是他自己")
            return
        end
        fraghash = joaat("prop_fragtest_cnst_04")
        STREAMING.REQUEST_MODEL(fraghash)
        local TargetCrds = ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED(network.get_selected_player()), false)
        local crashstaff1 = OBJECT.CREATE_OBJECT(fraghash, TargetCrds.x, TargetCrds.y, TargetCrds.z, true, false, false)
            OBJECT.BREAK_OBJECT_FRAGMENT_CHILD(crashstaff1, 1, false)
        local crashstaff2 = OBJECT.CREATE_OBJECT(fraghash, TargetCrds.x, TargetCrds.y, TargetCrds.z, true, false, false)
            OBJECT.BREAK_OBJECT_FRAGMENT_CHILD(crashstaff2, 1, false)
        local crashstaff3 = OBJECT.CREATE_OBJECT(fraghash, TargetCrds.x, TargetCrds.y, TargetCrds.z, true, false, false)
            OBJECT.BREAK_OBJECT_FRAGMENT_CHILD(crashstaff3, 1, false)
        local crashstaff4 = OBJECT.CREATE_OBJECT(fraghash, TargetCrds.x, TargetCrds.y, TargetCrds.z, true, false, false)
            OBJECT.BREAK_OBJECT_FRAGMENT_CHILD(crashstaff4, 1, false)
        for i = 0, 100 do 
            if PLAYER.GET_PLAYER_PED(network.get_selected_player()) == PLAYER.PLAYER_PED_ID() then
                gui.show_message("攻击已停止“，”已检测到目标已离开或目标已是他自己")
                return
            end    
            local TargetPlayerPos = ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED(network.get_selected_player()), false)
            ENTITY.SET_ENTITY_COORDS_NO_OFFSET(crashstaff1, TargetPlayerPos.x, TargetPlayerPos.y, TargetPlayerPos.z, false, true, true)
            ENTITY.SET_ENTITY_COORDS_NO_OFFSET(crashstaff2, TargetPlayerPos.x, TargetPlayerPos.y, TargetPlayerPos.z, false, true, true)
            ENTITY.SET_ENTITY_COORDS_NO_OFFSET(crashstaff3, TargetPlayerPos.x, TargetPlayerPos.y, TargetPlayerPos.z, false, true, true)
            ENTITY.SET_ENTITY_COORDS_NO_OFFSET(crashstaff4, TargetPlayerPos.x, TargetPlayerPos.y, TargetPlayerPos.z, false, true, true)
            fragcrash:sleep(10)
            delete_entity(crashstaff1)
            delete_entity(crashstaff2)
            delete_entity(crashstaff3)
            delete_entity(crashstaff4)
        end
    end)
    script.run_in_fiber(function (fragcrash2)
        local TargetCrds = ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED(network.get_selected_player()), false)
        fraghash = joaat("prop_fragtest_cnst_04")
        STREAMING.REQUEST_MODEL(fraghash)
        for i=1,10 do
            if PLAYER.GET_PLAYER_PED(network.get_selected_player()) == PLAYER.PLAYER_PED_ID() then
                gui.show_message("攻击已停止","检测到目标已经离开或目标就是他自己")
                return
            end    
            local object = OBJECT.CREATE_OBJECT(fraghash, TargetCrds.x, TargetCrds.y, TargetCrds.z, true, false, false)
            OBJECT.BREAK_OBJECT_FRAGMENT_CHILD(object, 1, false)
            delete_entity(object)
            local object = OBJECT.CREATE_OBJECT(fraghash, TargetCrds.x, TargetCrds.y, TargetCrds.z, true, false, false)
            OBJECT.BREAK_OBJECT_FRAGMENT_CHILD(object, 1, false)
            delete_entity(object)
            local object = OBJECT.CREATE_OBJECT(fraghash, TargetCrds.x, TargetCrds.y, TargetCrds.z, true, false, false)
            OBJECT.BREAK_OBJECT_FRAGMENT_CHILD(object, 1, false)
            delete_entity(object)
            local object = OBJECT.CREATE_OBJECT(fraghash, TargetCrds.x, TargetCrds.y, TargetCrds.z, true, false, false)
            OBJECT.BREAK_OBJECT_FRAGMENT_CHILD(object, 1, false)
            delete_entity(object)
            local object = OBJECT.CREATE_OBJECT(fraghash, TargetCrds.x, TargetCrds.y, TargetCrds.z, true, false, false)
            OBJECT.BREAK_OBJECT_FRAGMENT_CHILD(object, 1, false)
            delete_entity(object)
            local object = OBJECT.CREATE_OBJECT(fraghash, TargetCrds.x, TargetCrds.y, TargetCrds.z, true, false, false)
            OBJECT.BREAK_OBJECT_FRAGMENT_CHILD(object, 1, false)
            delete_entity(object)
            local object = OBJECT.CREATE_OBJECT(fraghash, TargetCrds.x, TargetCrds.y, TargetCrds.z, true, false, false)
            OBJECT.BREAK_OBJECT_FRAGMENT_CHILD(object, 1, false)
            delete_entity(object)
            local object = OBJECT.CREATE_OBJECT(fraghash, TargetCrds.x, TargetCrds.y, TargetCrds.z, true, false, false)
            OBJECT.BREAK_OBJECT_FRAGMENT_CHILD(object, 1, false)
            delete_entity(object)
            local object = OBJECT.CREATE_OBJECT(fraghash, TargetCrds.x, TargetCrds.y, TargetCrds.z, true, false, false)
            OBJECT.BREAK_OBJECT_FRAGMENT_CHILD(object, 1, false)
            delete_entity(object)
            local object = OBJECT.CREATE_OBJECT(fraghash, TargetCrds.x, TargetCrds.y, TargetCrds.z, true, false, false)
            OBJECT.BREAK_OBJECT_FRAGMENT_CHILD(object, 1, false)
            fragcrash2:sleep(100)
            delete_entity(object)
        end
    end)
end)
toolTip(griefPlayerTab, "在选定的玩家上生成一堆物体并将它们分解成碎片，导致它们崩溃")

griefPlayerTab:add_sameline()
griefPlayerTab:add_button("破坏 HUD", function()
    local pid = network.get_selected_player()
    network.trigger_script_event(1 << pid, {1450115979, pid, 1})
    gui.show_message("HUD 破坏", "你已经坏了 "..PLAYER.GET_PLAYER_NAME(pid).."'HUD和标签.")
    gui.show_message("HUD 破坏", "这导致他们没有HUD，也看不到内部入口点，他们也无法暂停或切换武器.")
end)
toolTip(griefPlayerTab, "移除并破坏所选玩家的 HUD，这会导致他们无法暂停、进入公寓并破坏他们的自由模式任务")

-- Grief Sound Spam Targetable
griefPlayerTab:add_separator()
griefPlayerTab:add_text("声音垃圾邮件")
local soundIndex = 0
local isPlaying = false

local searchQuery = ""
local filteredSoundNames = {}
local selectedFilteredSoundIndex = 0

local function updateFilteredSoundNames()
    filteredSoundNames = {}
    for _, sound in ipairs(sounds) do
        if string.find(string.lower(sound.SoundName), string.lower(searchQuery)) then
            table.insert(filteredSoundNames, sound.SoundName)
        end
    end
end

local function displaySoundNamesList()
    updateFilteredSoundNames()
    if selectedFilteredSoundIndex > #filteredSoundNames then
        selectedFilteredSoundIndex = 0
    end
    selectedFilteredSoundIndex, _ = ImGui.Combo("选择声音", selectedFilteredSoundIndex, filteredSoundNames, #filteredSoundNames)
end

griefPlayerTab:add_imgui(function()
    if is_typing then
        PAD.DISABLE_ALL_CONTROL_ACTIONS(0)
    end
    searchQuery, _ = ImGui.InputText("搜索声音", searchQuery, 128)
    if ImGui.IsItemActive() then
        is_typing = true
    else
        is_typing = false
    end

    local soundNames = {}
    for _, sound in ipairs(sounds) do
        table.insert(soundNames, sound.SoundName)
    end

    displaySoundNamesList()

    if ImGui.Button("播放") then
        local selectedSoundName = filteredSoundNames[selectedFilteredSoundIndex + 1]
        local targetPlayer = network.get_selected_player()
            script.run_in_fiber(function()
                -- Play the selected sound
                local selectedSound
                for _, sound in ipairs(sounds) do
                    if sound.SoundName == selectedSoundName then
                        selectedSound = sound
                        break
                    end
                end
                soundId = AUDIO.PLAY_SOUND_FROM_ENTITY(-1, selectedSound.AudioName, PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(targetPlayer), selectedSound.AudioRef, true, 999999999)
                soundId = AUDIO.GET_SOUND_ID()
                gui.show_message("声音垃圾", "播放 "..selectedSound.SoundName.." 上 "..PLAYER.GET_PLAYER_NAME(targetPlayer))
                gui.show_message("声音 ID", soundId)
            end)    
    end
end)
toolTip(griefPlayerTab, "播放下拉列表中的选定声音.")

griefPlayerTab:add_sameline()
local stopSounds = false
stopSounds = griefPlayerTab:add_checkbox("停止本地声音")
    script.register_looped("stopSounds", function(script)
        if stopSounds:is_enabled() == true then     
            --soundId = AUDIO.GET_SOUND_ID()
            --gui.show_message("Sound ID", "Stopped "..soundId)
            --AUDIO.STOP_SOUND(soundId)
            --AUDIO.RELEASE_SOUND_ID(soundId)
            for i = -1, 25 do
                AUDIO.STOP_SOUND(i)
                AUDIO.RELEASE_SOUND_ID(i)
            end
        end
    end)

toolTip(griefPlayerTab, "停止所有声音.")

griefPlayerTab:add_imgui(function()
    -- Ends the ImGui wrapper, new additions should be added above this.
    ImGui.End()
end)



dropsPlayerTab:add_sameline()
Drops = dropsPlayerTab:add_checkbox("友好选项")
Drops:set_enabled(true)
dropsPlayerTab:add_imgui(function()
    if Drops:is_enabled() then
    local parentWindow = gui.get_tab("") -- Assuming this retrieves the parent window
        local parentX, parentY = ImGui.GetWindowPos() -- Get the position of the parent window
        local parentWidth, parentHeight = ImGui.GetWindowSize(parentWindow) -- Get the size of the parent window
        local childWidth, childHeight = 200, 150 -- Size of your child window
        local offset = 10 -- Offset between parent and child windows

        local x = parentX + parentWidth + offset -- Position the child window to the right of the parent window
        local y = parentY + 30-- Align the child window vertically with the parent window

        ImGui.SetNextWindowPos(x, y)
            if ImGui.Begin("友好选项 - ".. PLAYER.GET_PLAYER_NAME(network.get_selected_player())) then
        end
    end
end)

local princessBubblegumLoop = false
dropsPlayerTab:add_text("给玩家手办")
dropsPlayerTab:add_button("公主机器人泡泡糖 （开/关）", function()
    princessBubblegumLoop = not princessBubblegumLoop

    script.register_looped("princessbubblegumLoop", function(script)
        local model = joaat("vw_prop_vw_colle_prbubble")
        local pickup = joaat("PICKUP_CUSTOM_SCRIPT")
        local player_id = network.get_selected_player()
        local money_value = 0

        STREAMING.REQUEST_MODEL(model)
        while STREAMING.HAS_MODEL_LOADED(model) == false do
            script:yield()
        end

        if STREAMING.HAS_MODEL_LOADED(model) then
        gui.show_message("RP/现金投放开始", "掉落公主机器人小雕像 "..PLAYER.GET_PLAYER_NAME(player_id))
            local coords = ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(player_id), true)
            local objectIdSpawned = OBJECT.CREATE_AMBIENT_PICKUP(
                pickup,
                coords.x,
                coords.y,
                coords.z + 1,
                3,
                money_value,
                model,
                false,
                false
            )

            local net_id = NETWORK.OBJ_TO_NET(objectIdSpawned)
            NETWORK.SET_NETWORK_ID_EXISTS_ON_ALL_MACHINES(objectIdSpawned, true)
            
            ENTITY.SET_ENTITY_AS_NO_LONGER_NEEDED(objectIdSpawned)
        end
        ENTITY.SET_ENTITY_NO_COLLISION_ENTITY(objectIdSpawned, player_id, false)
        sleep(0.1) -- Sets the timer in seconds for how long this should pause before sending another figure
        if not princessBubblegumLoop then
            script.unregister_script("princessbubblegumLoop")
        end
    end)
end)
toolTip(dropsPlayerTab, "将公主机器人雕像掉落在选定的玩家身上。")
dropsPlayerTab:add_sameline()
dropsPlayerTab:add_button("外星人（开/关）", function()
   alienfigurineLoop = not alienfigurineLoop

    script.register_looped("alienfigurineLoop", function(script)
        local model = joaat("vw_prop_vw_colle_alien")
        local pickup = joaat("PICKUP_CUSTOM_SCRIPT")
        local player_id = network.get_selected_player()
        local money_value = 0

        STREAMING.REQUEST_MODEL(model)
        while STREAMING.HAS_MODEL_LOADED(model) == false do
            script:yield()
        end

        if STREAMING.HAS_MODEL_LOADED(model) then
        gui.show_message("RP/现金投放开始", "掉落外星人雕像 "..PLAYER.GET_PLAYER_NAME(player_id))
            local coords = ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(player_id), true)
            local objectIdSpawned = OBJECT.CREATE_AMBIENT_PICKUP(
                pickup,
                coords.x,
                coords.y,
                coords.z + 1,
                3,
                money_value,
                model,
                false,
                false
            )

            local net_id = NETWORK.OBJ_TO_NET(objectIdSpawned)
            NETWORK.SET_NETWORK_ID_EXISTS_ON_ALL_MACHINES(objectIdSpawned, true)
            
            ENTITY.SET_ENTITY_AS_NO_LONGER_NEEDED(objectIdSpawned)
        end
        ENTITY.SET_ENTITY_NO_COLLISION_ENTITY(objectIdSpawned, player_id, false)
        sleep(0.1) -- Sets the timer in seconds for how long this should pause before sending another figure
        if not alienfigurineLoop then
            script.unregister_script("alienfigurineLoop")
        end
    end)
end)
toolTip(dropsPlayerTab, "将外星雕像掉落在选定的玩家身上.")
dropsPlayerTab:add_sameline()
dropsPlayerTab:add_button("赌场扑克牌（开/关）", function()
   casinocardsLoop = not casinocardsLoop

    script.register_looped("casinocardsLoop", function(script)
        local model = joaat("vw_prop_vw_lux_card_01a")
        local pickup = joaat("PICKUP_CUSTOM_SCRIPT")
        local player_id = network.get_selected_player()
        local money_value = 0

        STREAMING.REQUEST_MODEL(model)
        while STREAMING.HAS_MODEL_LOADED(model) == false do
            script:yield()
        end

        if STREAMING.HAS_MODEL_LOADED(model) then
        gui.show_message("RP/现金投放开始", "放下赌场卡 "..PLAYER.GET_PLAYER_NAME(player_id))
            local coords = ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(player_id), true)
            local objectIdSpawned = OBJECT.CREATE_AMBIENT_PICKUP(
                pickup,
                coords.x,
                coords.y,
                coords.z + 1,
                3,
                money_value,
                model,
                false,
                false
            )
        
            local net_id = NETWORK.OBJ_TO_NET(objectIdSpawned)
            NETWORK.SET_NETWORK_ID_EXISTS_ON_ALL_MACHINES(objectIdSpawned, true)
            
            ENTITY.SET_ENTITY_AS_NO_LONGER_NEEDED(objectIdSpawned)
        end
        ENTITY.SET_ENTITY_NO_COLLISION_ENTITY(objectIdSpawned, player_id, false)
        sleep(0.1) -- Sets the timer in seconds for how long this should pause before sending another figure
        if not casinocardsLoop then
            script.unregister_script("casinocardsLoop")
        end
    end)
end)
toolTip(dropsPlayerTab, "将赌场卡掉落在选定的玩家身上.")
dropsPlayerTab:add_separator()
dropsPlayerTab:add_button("给出 25k & 随机 RP", function()
    script.run_in_fiber(function(tse)
        pid = network.get_selected_player()
        for i = 0, 9 do
            for v = 0, 20 do
                network.trigger_script_event(1 << pid, {968269233, pid, 0, i, v, v, v})
                for n = 0, 16 do
                    network.trigger_script_event(1 << pid, {968269233, pid, n, i, v, v, v})
                end
            end
            network.trigger_script_event(1 << pid, {968269233, pid, 1, i, 1, 1, 1})
            network.trigger_script_event(1 << pid, {968269233, pid, 3, i, 1, 1, 1})
            network.trigger_script_event(1 << pid, {968269233, pid, 10, i, 1, 1, 1})
            network.trigger_script_event(1 << pid, {968269233, pid, 0, i, 1, 1, 1})
            tse:yield()
            
            gui.show_message("祝福RP", "祝福 "..PLAYER.GET_PLAYER_NAME(pid).." 25k RP （1 次）")
        end
    end)
end)
toolTip(dropsPlayerTab, "给被选中的玩家一些金钱和RP")
dropsPlayerTab:add_sameline()
local tseTest = dropsPlayerTab:add_checkbox("超快RP")
script.register_looped("tseTest", function()
    if tseTest:is_enabled() == true then
        pid = network.get_selected_player()
        for i = 0, 24 do 
            network.trigger_script_event(1 << pid, {968269233 , pid, 1, 4, i, 1, 1, 1, 1})
        end
    end
end)
toolTip(dropsPlayerTab, "用 RP 远程淹没所选玩家（约 1 级/秒）")
dropsPlayerTab:add_sameline()
local ezMoney = dropsPlayerTab:add_checkbox("钱 （$225k）")
    script.register_looped("ezMoney", function()
        if ezMoney:is_enabled() == true then
            local pid = network.get_selected_player()
            for n = 0, 10 do
                for l = -10, 10 do
                    network.trigger_script_event(1 << pid, {968269233 , pid, 1, l, l, n, 1, 1, 1})
                end
            end
        end
    end)
toolTip(dropsPlayerTab, "有时有效，有时无效。 高达 225k")

dropsPlayerTab:add_imgui(function()
    -- Ends the ImGui wrapper, new additions should be added above this.
    ImGui.End()
end)

----------Config--------------------
saveConfig = false

function presistEntry(tableEntry, value)
    configTable[tableEntry] = value
end

function setEntry(tableEntry, value)
    if value ~= configTable[tableEntry] then
        configTable[tableEntry] = value
        saveConfig = true
    end
end

local persisted_config = io.open("Extras-Addon.json", "r")
if persisted_config == nil then
    configTable = {}
    --Add entries here
    presistEntry("tireParticles", tirePTFX:is_enabled()) --param0 is the entry in the config table, param1 is the value to set the entry in the table(this will be the current value of the component)  
    --End Entires
    local new_file = io.open("Extras-Addon.json", "w+")
    new_file:write(json.encode(configTable))
    new_file:flush()
    new_file:close()
else
    configTable = json.decode(persisted_config:read("*all"))
    --add entries, they need to be set to the values in the config
    tirePTFX:set_enabled(configTable["tireParticles"]) --sets the value of the component to the value from the config
    --end entries
    persisted_config:close()
end

script.register_looped("Extras Addon Config", function(script)
    if gui.is_open() then
        saveConfig = false
        --Each entry should look like this
        setEntry("tireParticles", tirePTFX:is_enabled()) --param0 is the entry in the config table, param1 is the value to set the entry in the table(this will be the current value of the component)
        --End Entries
        if saveConfig then
            gui.show_message("Config", "Saving")
            local json_file = io.open("Extras-Addon.json", "w")
            json_file:write(json.encode(configTable))
            json_file:flush()
            json_file:close()
        end
    end
    script:yield()
end)
